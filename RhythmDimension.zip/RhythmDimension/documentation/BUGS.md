# Registro de bugs

## Encontrados por testes e corrigidos (Python de referencia)
| ID | Sistema | Descricao | Causa | Correcao | Teste de confirmacao |
|---|---|---|---|---|---|
| BUG-001 | Simulacao | IndexError no fim da fase | tabelas de passo sem margem para a busca em blocos de 4 | margem de 12 passos | F01-F13, matriz |
| BUG-002 | Analise | BPM em oitava errada (90->180, 174->87) | comb filter favorece o dobro/metade | normaliza 80-160 e refaz a fase da grade; expoe alternativas | A080-A174 |
| BUG-003 | Analise | pad ambiente: confianca 0,54 e 452 onsets falsos | normalizacao por percentil amplificava ruido | piso absoluto de escala/onset e confianca por clareza | A101, A104 |
| BUG-004 | Analise | energia por compasso ~0,45 nos trechos fortes | normalizado pelo p90 de picos de transiente | normaliza pelo nivel dos compassos | zonas de velocidade e formas voltaram a ocorrer; O02 |
| BUG-005 | Gerador notas | densidade acima do limite (pico 5 vs 3,6) | janela com limite aberto e acorde contado uma vez | janela fechada e acorde conta 2 | N4, V11 |
| BUG-006 | Gerador notas | intervalo por pista ignorado apos hold/slide | usava inicio, nao fim da nota | pista livre = fim da nota | N3, V12 |
| BUG-007 | Gerador notas | duplo 80 ms apos fim de hold (dedo inalcancavel) | sem folga de deslocamento | folga de 250 ms | N6, V13, matriz |
| BUG-008 | Corretor | repetia a mesma correcao rejeitada 30x | sem metrica de progresso nem corte | severidade + corte apos 3 rejeicoes com nota "edicao manual" | X03, X04, X05 |
| BUG-009 | Music Dash | padroes longos invadiam o trecho de notas | olhava so 1 compasso a frente | rejeita padrao cuja cauda cruza o inicio do trecho | C4, matriz music_dash |
| BUG-010 | Music Dash | fase sem trecho de notas em musicas curtas | planejamento dependente de seed | planejamento com reserva de compassos | S8, matriz |
| BUG-011 | Gerador | folga final < 1,0 s | limite de 0,8 s | limite 1,1 s + estrategia T4 no corretor | T4, matriz |
| BUG-012 | Endless | reprovado contra limites de "beginner" | dificuldade do mapa nao refletia a rampa | `tier_by_bar` + dificuldade por instante | E01 |

## Correcoes de testes (expectativa errada, nao bug de produto)
F09 (espinhos pequenos sao perdoaveis: o negativo correto e parede cheia), V07 (injecao fora de ordem), V08 (aglomerado de espinhos conta como 1 grupo), X05 (a nota de "edicao manual" contava como iteracao).

## Em aberto
| ID | Descricao |
|---|---|
| OPEN-001 | Todo o GDScript e nao executado: erros de sintaxe/API/execucao sao esperados (gravidade ALTA, bloqueia entrega). |
| OPEN-002 | Sem APK/teste em Android (importacao de arquivo, audio, toque, desempenho). |
| OPEN-003 | Analise de BPM nao testada com musica real. |
| OPEN-004 | Endless nao e infinito (12 blocos). |
| OPEN-005 | Tempo da validacao em GDScript no celular desconhecido. |
| OPEN-006 | Replay de notas sem reproducao visual. |
