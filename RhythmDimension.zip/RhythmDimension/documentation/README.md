# Rhythm Dimension (versao de DESENVOLVIMENTO)

Jogo mobile de ritmo e plataforma em **Godot 4 (GDScript)**: plataforma musical (Geometry Run), notas (Magic Rhythm), hibrido (Music Dash),
Endless, Free Play com musicas do proprio celular e fases geradas proceduralmente (seed reprodutivel) com validacao automatica.
Mecanicas inspiradas, identidade propria: fases, padroes, musicas e efeitos sao originais (as 5 musicas oficiais foram sintetizadas para o projeto).

## STATUS HONESTO (leia primeiro)

| Parte | Estado |
|---|---|
| Algoritmos (analise de audio, geracao, fisica, validacao, correcao) em **Python de referencia** (`tools/rdtools`) | **Implementados e testados de verdade**: 73/73 testes passam (`documentation/TEST_REPORT.md`) |
| 5 fases oficiais + musicas originais OGG + trilha do Endless | **Geradas, validadas e READY** (`data/levels/`, `assets/music/`) |
| Projeto **Godot/GDScript** (41 arquivos, ~5.800 linhas: menus, 4 modos, editor, importacao, analise, geracao, validador, corretor, salvamento, replay, config) | **Escrito, mas NUNCA aberto nem executado** (o ambiente de desenvolvimento nao tinha Godot). Passou so em lint estatico basico. **Espere erros de sintaxe/API/execucao na primeira abertura.** |
| Android / APK | **Nao gerado** (sem Android SDK/JDK/templates). `export_presets.cfg` e so um ponto de partida. |

Veja `LIMITATIONS.md` e `BUGS.md`. Nada aqui deve ser tratado como "pronto para publicar".

## Como usar

### 1) Ferramentas Python (testadas)
Requisitos: Python 3.10+, numpy, scipy, ffmpeg.
```
python3 tools/run_tests.py --group Fisica,Analise,Padroes,Persistencia,Validador,Corretor   # testes rapidos
python3 tools/run_tests.py --matrix geometry_run      # matriz de geracao (repita para magic_rhythm e music_dash)
python3 tools/run_tests.py --group Geracao,Oficiais,Endless,Performance
python3 tools/run_tests.py --report                   # regenera documentation/TEST_REPORT.md
python3 tools/validate_patterns.py                    # valida cada padrao (simulacao) -> data/pattern_compat.json (retomavel)
python3 tools/build_official.py                       # (re)constroi as 5 fases oficiais e as musicas
python3 tools/gdscript_lint.py                        # lint estatico basico dos .gd (NAO e o parser do Godot)
```

### 2) Godot (nao testado)
1. Instale o **Godot 4.3+** (recomendado a versao estavel mais recente).
2. Abra a pasta como projeto. Na primeira abertura o editor importa os `.ogg`; **corrija os erros que aparecerem no painel de saida/depurador** (esperados).
3. Rode a cena principal. Para testar a logica no motor: `godot --headless --path . -s tests/test_runner.gd`.

### 3) Exportar para Android (nao testado)
Editor > Gerenciar templates de exportacao; configure Android SDK, JDK 17 e keystore (Editor > Configuracoes do Editor > Exportar > Android);
Projeto > Exportar > Android. Teste em aparelho real: orientacao, toque, latencia e importacao de arquivos.

## Estrutura
```
project.godot, export_presets.cfg, scenes/main.tscn
scripts/core        rd.gd (dados), rng.gd, rhythm_map.gd, physics_model.gd, rhythm_clock.gd, score_manager.gd, replay_manager.gd,
                    game_manager.gd (autoload), save_manager.gd (autoload), game_settings.gd (autoload)
scripts/audio       audio_manager.gd (autoload, relogio de audio), music_importer.gd
scripts/analysis    beat_analyzer.gd, analysis_job.gd
scripts/generation  level_generator.gd, generation_job.gd
scripts/validation  level_validator.gd, test_manager.gd (ciclo de correcao)
scripts/gameplay    geometry_run.gd (Geometry Run/Music Dash/Endless), magic_rhythm.gd, player_controller.gd, note_controller.gd,
                    obstacle_controller.gd, pause_menu.gd
scripts/editor      editor_controller.gd, editor_screen.gd
scripts/ui          main.gd, ui.gd, menus/telas
data/               physics.json, difficulty.json, patterns.json, pattern_compat.json, levels/ (5 oficiais)
assets/music        5 musicas originais + endless_loop.ogg
tools/              rdtools (Python de referencia), run_tests.py, build_official.py, validate_patterns.py, gdscript_lint.py
tests/              test_runner.gd (para o Godot)
documentation/      README, ARCHITECTURE, LIMITATIONS, BUGS, TEST_REPORT
```
