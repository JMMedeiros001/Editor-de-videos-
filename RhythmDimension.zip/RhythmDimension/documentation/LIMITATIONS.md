# Limitacoes e riscos conhecidos (nada disto foi omitido)

## O que NAO foi executado/verificado
- **Nenhum GDScript foi executado** (sem Godot). Todo o projeto Godot e codigo escrito, nao validado. Provavelmente ha erros de sintaxe, de tipo, de API ou de execucao.
  Ha apenas um lint estatico basico (`tools/gdscript_lint.py`) que NAO substitui o parser.
- Nenhum APK foi gerado; nada foi testado em Android (toque, orientacao, audio, latencia, permissoes, desempenho, FPS, memoria).
- Todos os botoes/telas/editor/replay/pratica nao foram exercitados.
- A busca de alcancabilidade em GDScript pode ser **lenta** em celular (fases de ~80 s; Endless ~190 s); ha barra de progresso real e thread, mas o tempo nao foi medido.
- Igualdade Python x GDScript (mesma seed => mesmo mapa) e **pretendida e nao verificada**.

## Riscos de API do Godot (a confirmar na primeira execucao)
- Seletor de arquivos: `FileDialog.use_native_dialog` no Android depende da versao do Godot; URIs `content://` (SAF) podem nao ser legiveis por `FileAccess`. Plano B: copiar o arquivo para `user://` antes de ler.
- Decodificacao de MP3/OGG para analise usa `AudioStreamPlayback.mix_audio` se existir; senao cai em captura em tempo real (`AudioEffectCapture`), que demora a duracao da musica. Nenhum dos dois foi testado.
- `AudioStreamOggVorbis.load_from_buffer` / `AudioStreamMP3.data` para arquivos do usuario nao testados. **FLAC nao e suportado nativamente.**
- Deteccao de fone desconectado nao e feita (so perda de foco/pausa do app).
- O Godot nao fornece timestamp do evento de toque: o acerto usa o relogio de audio no inicio do frame (pode adicionar ate 1 frame de erro).

## Limitacoes de funcionalidade
- **Endless** gera 12 blocos de 8 compassos (~3 min) com dificuldade crescente e entao termina (nao e infinito/encadeado ainda). A musica faz loop manual.
- Replay: geometria reproduz as entradas (fisica deterministica); para notas so os julgamentos sao gravados (sem reproducao visual).
- Music Dash: trechos de notas com 3 linhas e tipos tap/hold/double (sem slide).
- A previa so cobre um trecho inicial validado (~24 s) e nunca vira fase oficial.
- A "dificuldade estimada" e uma **heuristica** calibrada no gerador; nao mede dificuldade humana.
- Biblioteca de padroes pequena (16 padroes). Variedade vem de combinacao, ancoragem na musica, espacamento e forma.
- Customizacao: troca de forma/tema/cor guarda a preferencia; temas visuais alem da cor de destaque ainda nao alteram o cenario.
- Conquistas "Combo 50/100", "Primeiro Perfect", etc. existem; desbloqueios sao simples.

## Limites do que foi provado (Python)
- Simulacao: "existe trajetoria" com entradas a 30 Hz; nao prova que a fase e justa/divertida nem que um humano a conclui.
- Analise de BPM: verificada so com audio **sintetico** de BPM conhecido (10 andamentos, oitava aceita). Musica real (voz, ritmo variavel, swing) nao foi testada.
- Fases oficiais: validadas pela fisica de referencia; o "feeling" real depende de jogar no aparelho.
