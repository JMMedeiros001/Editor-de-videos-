# Relatorio de testes - Rhythm Dimension

Gerado automaticamente por `tools/run_tests.py` em 2026-11-05. **Todos os resultados abaixo foram executados de verdade** nas ferramentas de referencia em Python (`tools/rdtools`), que implementam o mesmo algoritmo do jogo. **Nada foi executado no Godot nem em Android** (ambiente sem Godot/Android SDK/rede) - veja a secao 'Nao executados'.

## Resumo

| Total | Aprovados | Reprovados |
|---|---|---|
| 73 | 73 | 0 |

| Grupo | Testes | Aprovados | Reprovados |
|---|---|---|---|
| Fisica | 13 | 13 | 0 |
| Analise | 14 | 14 | 0 |
| Padroes | 2 | 2 | 0 |
| Geracao | 12 | 12 | 0 |
| Validador | 18 | 18 | 0 |
| Corretor | 6 | 6 | 0 |
| Oficiais | 2 | 2 | 0 |
| Endless | 2 | 2 | 0 |
| Persistencia | 1 | 1 | 0 |
| Performance | 3 | 3 | 0 |

## Fases oficiais (revalidadas do zero a partir do arquivo salvo)

| ID | Nome | Modo | Dif. | BPM | Duracao | Obj/Notas | Padroes | Status | Resultado | Testes (ok/aviso/falha/nao verif.) | Dif. estimada | Seed | Correcoes |
|---|---|---|---|---|---|---|---|---|---|---|---|---|---|
| official_01_first_pulse | FIRST PULSE | geometry_run | beginner | 100.0 | 69s | 25/0 | 16 | READY | Aprovada | 23/0/0/0 | 1.22 | 1 | 0 |
| official_02_neon_circuit | NEON CIRCUIT | geometry_run | normal | 120.0 | 77s | 82/0 | 20 | READY | Aprovada | 23/0/0/0 | 2.95 | 2 | 0 |
| official_03_gravity_shift | GRAVITY SHIFT | geometry_run | normal | 110.0 | 76s | 58/0 | 13 | READY | Aprovada | 23/0/0/0 | 2.41 | 1 | 0 |
| official_04_beat_reactor | BEAT REACTOR | geometry_run | hard | 140.0 | 80s | 228/0 | 28 | READY | Aprovada | 23/0/0/0 | 4.75 | 1 | 0 |
| official_05_final_frequency | FINAL FREQUENCY | music_dash | expert | 150.0 | 81s | 26/120 | 8 | READY | Aprovada | 31/0/0/0 | 6.33 | 1 | 0 |

## Matriz de geracao (modo x dificuldade x musica x seed)

| Modo | Dificuldade | Fases | READY direto | READY apos correcao | Nao READY |
|---|---|---|---|---|---|
| geometry_run | beginner | 6 | 6 | 0 | 0 |
| geometry_run | normal | 6 | 6 | 0 | 0 |
| geometry_run | hard | 6 | 6 | 0 | 0 |
| geometry_run | expert | 6 | 6 | 0 | 0 |
| geometry_run | insane | 6 | 6 | 0 | 0 |
| magic_rhythm | beginner | 6 | 6 | 0 | 0 |
| magic_rhythm | normal | 6 | 6 | 0 | 0 |
| magic_rhythm | hard | 6 | 6 | 0 | 0 |
| magic_rhythm | expert | 6 | 6 | 0 | 0 |
| magic_rhythm | insane | 6 | 6 | 0 | 0 |
| music_dash | beginner | 6 | 6 | 0 | 0 |
| music_dash | normal | 6 | 6 | 0 | 0 |
| music_dash | hard | 6 | 6 | 0 | 0 |
| music_dash | expert | 6 | 6 | 0 | 0 |
| music_dash | insane | 6 | 6 | 0 | 0 |

Fases que NAO ficaram READY: nenhuma

## Todos os testes

| ID | Grupo | Teste | Resultado | Detalhe |
|---|---|---|---|---|
| F01 | Fisica | fase vazia e concluivel | pass |  |
| F02 | Fisica | 1 espinho e concluivel (pulo do cubo) | pass |  |
| F03 | Fisica | parede de 3 blocos e IMPOSSIVEL para o cubo (busca exaustiva) | pass | {'ok': False, 't_fail': 2.8, 'truncated': False, 'max_frontier': 13} |
| F04 | Fisica | bloco de altura 1 e concluivel | pass |  |
| F05 | Fisica | 8 espinhos adjacentes sao IMPOSSIVEIS (> distancia do salto) | pass |  |
| F06 | Fisica | 3 espinhos adjacentes sao concluiveis | pass |  |
| F07 | Fisica | cubo NAO consegue passar bloco de altura 2; robo (pulo longo) consegue | pass | cubo=False robo=True |
| F08 | Fisica | nave: corredor largo concluivel, corredor de 0.5 bloco IMPOSSIVEL | pass | largo=True estreito=False |
| F09 | Fisica | bola: espinhos alternados piso/teto exigem inverter e sao concluiveis; parede cheia (piso a teto) e impossivel | pass | alternado=True parede_cheia_impossivel=True |
| F10 | Fisica | aranha: troca instantanea de superficie conclui espinhos proximos | pass |  |
| F11 | Fisica | onda: corredor em zigue-zague concluivel | pass |  |
| F12 | Fisica | simulacao e deterministica (2 execucoes identicas) | pass |  |
| F13 | Fisica | posicao horizontal vem do relogio de audio: x(t) integra a velocidade por trechos | pass |  |
| A080 | Analise | BPM 80 (offset 0.20s): detectado com equivalencia de oitava e fase < 40 ms | pass | detectado 160.00 (oitava) erro de fase -7 ms |
| A090 | Analise | BPM 90 (offset 0.37s): detectado com equivalencia de oitava e fase < 40 ms | pass | detectado 90.00 (exato) erro de fase -5 ms |
| A100 | Analise | BPM 100 (offset 0.12s): detectado com equivalencia de oitava e fase < 40 ms | pass | detectado 100.00 (exato) erro de fase -8 ms |
| A110 | Analise | BPM 110 (offset 0.30s): detectado com equivalencia de oitava e fase < 40 ms | pass | detectado 110.00 (exato) erro de fase -10 ms |
| A120 | Analise | BPM 120 (offset 0.37s): detectado com equivalencia de oitava e fase < 40 ms | pass | detectado 120.00 (exato) erro de fase -3 ms |
| A128 | Analise | BPM 128 (offset 0.21s): detectado com equivalencia de oitava e fase < 40 ms | pass | detectado 128.00 (exato) erro de fase -5 ms |
| A140 | Analise | BPM 140 (offset 0.05s): detectado com equivalencia de oitava e fase < 40 ms | pass | detectado 140.00 (exato) erro de fase -10 ms |
| A150 | Analise | BPM 150 (offset 0.30s): detectado com equivalencia de oitava e fase < 40 ms | pass | detectado 150.00 (exato) erro de fase -6 ms |
| A160 | Analise | BPM 160 (offset 0.20s): detectado com equivalencia de oitava e fase < 40 ms | pass | detectado 160.00 (exato) erro de fase -7 ms |
| A174 | Analise | BPM 174 (offset 0.11s): detectado com equivalencia de oitava e fase < 40 ms | pass | detectado 87.00 (oitava) erro de fase -2 ms |
| A101 | Analise | pad ambiente (sem percussao): confianca baixa e sem onsets falsos | pass | conf=0.087 onsets=0 |
| A102 | Analise | silencio total: sem onsets, confianca 0, sem excecao | pass |  |
| A103 | Analise | arquivo invalido/corrompido gera erro tratavel (nao trava) | pass |  |
| A104 | Analise | musica fraca em percussao nao e tratada como batida confiavel (vocal/sustentado) | pass | conf=0.002 |
| P01 | Padroes | biblioteca: todos os padroes tem campos obrigatorios (id, modo, tier, entrada/saida, duracao) | pass | faltando [] |
| P02 | Padroes | cada padrao geometrico foi validado isoladamente e tem >=1 combinacao (dificuldade x BPM) aprovada | pass | sem combinacao aprovada: [] |
| G01 | Geracao | mesma seed => mapa identico (reprodutivel); id de geracao presente | pass |  |
| G02 | Geracao | seeds diferentes => mapas diferentes (8 seeds, >=7 distintos) | pass | 8 distintos |
| G03 | Geracao | variedade de padroes: >=9 padroes distintos em 20 fases (hard) | pass | 14 padroes: ['Pattern_Block_03', 'Pattern_Finale_16', 'Pattern_Gravity_12', 'Pattern_Gravity_13', 'Pattern_Hop2_07', 'Pattern_Jump_01', 'Pattern_Jump_02', 'Patt |
| G04 | Geracao | o final nao e sempre igual: >=3 finais distintos em 12 seeds | pass | 5 finais |
| G05 | Geracao | recorte de trecho: tempos reancorados em 0 e fim = duracao do trecho | pass | end_t=29.6 start=10.0 |
| G06 | Geracao | os 7 estilos geram fases validas (geometria, normal) | pass | falharam: [] |
| G07 | Geracao | dificuldade Custom (parametros proprios) gera e valida | pass | Aprovada |
| G08 | Geracao | Magic Rhythm: 3, 4, 5 e 6 pistas geram e validam | pass | falharam: [] |
| G09 | Geracao | Magic Rhythm: aparecem tipos tap/hold/double/slide/fast/special conforme dificuldade | pass | tipos: ['double', 'fast', 'hold', 'slide', 'special', 'tap'] |
| G10 | Geracao | Music Dash: alterna corrida e notas com portais de transicao fechados | pass | segmentos de notas=4 notas=51 Aprovada |
| G20 | Geracao | MATRIZ: modo x dificuldade x musica x seed (90 fases) - nenhuma fase READY com teste reprovado | pass | invariante violada: [] |
| G21 | Geracao | MATRIZ: taxa de fases READY (apos correcao) >= 90% | pass | 100.0% READY |
| V00 | Validador | fase base (gerada+corrigida) e Aprovada | pass |  |
| V01 | Validador | parede impossivel => REPROVADA com G1 (simulacao) | pass | Reprovada |
| V02 | Validador | espinho dentro de bloco => C1 | pass |  |
| V03 | Validador | objeto acima da area jogavel => C3 | pass |  |
| V04 | Validador | objeto apos o fim da musica => T2 | pass |  |
| V05 | Validador | objetos duplicados => S6 | pass |  |
| V06 | Validador | perigo antes do lead-in => T1 | pass |  |
| V07 | Validador | forma especial sem portal de saida => P1/P2 | pass | [('P1', 'fail'), ('P2', 'fail')] |
| V08 | Validador | dois grupos de perigo mais proximos que o tempo de reacao (0.48 s < 0.56 s) => T3 | pass |  |
| V10 | Validador | acorde de 3 notas simultaneas => N5 | pass |  |
| V11 | Validador | densidade acima do limite => N4 | pass |  |
| V12 | Validador | mesma pista com intervalo menor que o minimo => N3 | pass |  |
| V13 | Validador | notas impossiveis para 2 dedos (2 holds + toque + duplo) => N6 | pass |  |
| V14 | Validador | slide para pista nao adjacente / nota em pista inexistente => S7 | pass |  |
| V15 | Validador | notas fora da musica => falha | pass | Reprovada |
| V16 | Validador | padrao acima do nivel da dificuldade => D2 | pass |  |
| V17 | Validador | busca truncada sem caminho => NAO VERIFICADA (nao READY, nao FAILED) | pass | G1=unverified resultado=Nao verificada |
| V18 | Validador | regra: READY nunca coexiste com teste reprovado (invariante) | pass |  |
| X01 | Corretor | parede impossivel dentro de um padrao e corrigida (ciclo gerar->validar->corrigir->revalidar) e aprovada | pass | Reprovada -> Aprovada em 1 iteracoes: ['substituir Pattern_Jump_02 por Pattern_Jump_01 (t=8.37s)'] |
| X02 | Corretor | correcao preserva o restante da fase (somente a instancia defeituosa e alterada) | pass | removidos fora da instancia: 0 |
| X03 | Corretor | notas com densidade/acorde invalidos sao corrigidas e aprovadas | pass | Reprovada -> Aprovada com avisos (6 correcoes) |
| X04 | Corretor | defeito sem trecho responsavel: NAO e escondido; permanece FAILED e registra 'edicao manual' | pass | Reprovada historico=4 |
| X05 | Corretor | limite de tentativas respeitado (sem laco infinito) | pass | iteracoes=3 (entradas no historico=4) |
| X06 | Corretor | regressao: fase corrigida revalidada do zero continua READY e identica ao relatorio | pass |  |
| O01 | Oficiais | 5 fases oficiais existem com mapas reais (objetos/notas/eventos) e audio OGG | pass | problemas: [] |
| O02 | Oficiais | cada fase oficial revalidada do zero (arquivo salvo) => READY | pass | nao READY: [] |
| E01 | Endless | Endless: 12 blocos (96 compassos) com dificuldade crescente sao concluiveis (3 seeds) | pass | falhas: [] |
| E02 | Endless | Endless: velocidade e dificuldade sobem gradualmente (sem saltos > 1 nivel) | pass | velocidade 8.4 -> 17.8 |
| D01 | Persistencia | mapa serializa/desserializa (JSON) sem perda e continua valido | pass |  |
| R01 | Performance | tempo de analise de 78 s de audio < 10 s (referencia Python) | pass | 0.31 s |
| R02 | Performance | geracao + validacao de uma fase de 78 s < 30 s (referencia Python) | pass | 4.92 s |
| R03 | Performance | memoria de pico da suite < 1.5 GB (referencia Python) | pass | 145 MB |

## Verificacao estatica dos .gd (tools/gdscript_lint.py)

41 arquivos, 5815 linhas. Erros: 0. Avisos: 2 (as duas classes internas TimelineView e Gen sao legitimas). **Isto NAO e o parser do Godot**: so confere indentacao com tabs, balanceamento de parenteses, class_name duplicado/igual a autoload, autoloads/cena/recursos existentes e lambdas de uma linha com varias instrucoes. Nao detecta erros de tipo, API inexistente nem erros de execucao.


## Nao executados (limitacoes reais do ambiente)

Estes itens **nao foram testados** e **nao devem ser considerados validados**:

- Interpretacao/execucao de qualquer script GDScript (nao ha Godot neste ambiente). O codigo GDScript foi escrito como porta direta dos algoritmos testados em Python, mas **nunca foi executado**.
- Todos os botoes dos menus, cenas, editor de fases, modo pratica, replay e telas de resultado (dependem do motor).
- Reproducao real de audio, pausa/retomada, interrupcoes (ligacao, fone), latencia e offset de sincronizacao no aparelho.
- Importacao de MP3/WAV/OGG pelo seletor de arquivos do Android; decodificacao de MP3/OGG pelo Godot; **FLAC nao e suportado nativamente pelo Godot 4** (documentado).
- Toque na tela, multitoque, orientacao, permissoes.
- FPS, memoria e tempo de carregamento no aparelho (os tempos de R01-R03 sao do codigo Python de referencia, nao do jogo).
- Exportacao Android / APK (sem Android SDK, JDK de assinatura e templates de exportacao). **Nenhum APK foi gerado.**
- Sensacao de jogo, diversao e dificuldade percebida por humanos (a 'dificuldade estimada' e uma heuristica calibrada no gerador).

## Limites do que foi provado

- A simulacao fisica testa **se existe uma trajetoria** com entradas amostradas a 30 Hz sobre a fisica de referencia (`data/physics.json`). Aprovada = caminho encontrado (prova de viabilidade). Reprovada = busca exaustiva sem caminho. Nao verificada = busca truncada sem caminho (nao e possivel afirmar).
- 'Fase tecnicamente valida', 'funcional', 'testada' e 'aprovada para entrega' sao niveis distintos (campo `levels` do relatorio de cada fase). Passar nos testes **nao prova que a fase e divertida**.
- A analise de BPM foi verificada com audio sintetico de BPM conhecido (equivalencia de oitava aceita: 80->160 e 174->87). Musica real (voz, ritmo variavel, swing) **nao foi testada**; o jogo mostra a confianca e permite ajuste manual de BPM/offset.
