# Arquitetura

## Principio
Uma unica fonte de verdade por regra, em **dados + codigo portado 1:1**:
`data/physics.json` (fisica), `difficulty.json` (parametros por dificuldade), `patterns.json` (biblioteca de padroes), `pattern_compat.json` (padroes validados por dificuldade/BPM).
O algoritmo existe em Python (`tools/rdtools`, **testado**) e em GDScript (`scripts/`, **nao executado**), com a mesma ordem de chamadas do PRNG para que a mesma seed gere a mesma fase.

## Sincronizacao
`AudioManager.get_time()` = posicao de reproducao + `get_time_since_last_mix()` - `get_output_latency()` + offset do usuario (monotonico). A posicao horizontal do jogador e
**funcao do tempo de audio** (`x(t)` integra os eventos de velocidade), e a fisica avanca em passos fixos de 1/120 s ate alcancar o tempo de audio. Nada depende de FPS ou timers.
Notas sao julgadas pelo tempo de audio no instante do toque (limitacao: o Godot nao expoe timestamp do evento de toque; usa-se o relogio no inicio do frame).

## Fisica (PhysicsModel / sim.py)
Estado `[y, vy, gravidade, no_chao, aux, hold_anterior]`. Formas: cubo, robo (pulo variavel), nave, bola (inverte gravidade), aranha (teleporta), onda (45 graus).
Colisao: topo de bloco e seguro (tolerancia 0,12), lateral/cabeca mata; espinhos tem hitbox menor que o desenho; piso e teto (formas com teto).

## Analise (BeatAnalyzer / analyzer.py)
Mono ~11 kHz -> 3 bandas (IIR 1 polo) -> envelope log por hop de 256 -> fluxo positivo -> forca de onset -> tempo por *comb filter* com prior (~120 BPM), normalizado em 80-160 BPM
(ambiguidade de oitava) -> fase da grade -> onsets (picos com piso absoluto) -> energia por compasso. Retorna **confianca**; o BPM e aproximado e ajustavel manualmente.

## Geracao (LevelGenerator / generator.py)
Planeja velocidade; percorre compassos; densidade depende da energia e da dificuldade; escolhe padroes elegiveis (nivel, forma, compatibilidade validada, estilo) por peso;
ancora na grade de batidas favorecendo onsets fortes; instancia padroes (espacamento esticado ao tempo de reacao, corredores procedurais de nave/onda, inversoes de gravidade,
blocos do robo, final); aplica restricoes de lead-in, folga e transicoes. Modos: geometria, notas (pistas por banda de frequencia), hibrido (trechos de corrida e de 3 linhas), endless (rampa).

## Validacao (LevelValidator / validator.py) e correcao (TestManager / fixer.py)
Testes: estrutura (S), colisao (C), tempo (T), notas (N), progressao (P), dificuldade (D) e **gameplay (G1)** = busca de alcancabilidade com entradas a 30 Hz sobre a fisica.
Resultado: Aprovada / Aprovada com avisos / Reprovada / Nao verificada -> READY / FAILED / UNVERIFIED. READY nunca coexiste com teste reprovado (invariante testada).
Corretor: gerar -> validar -> localizar instancia responsavel -> corrigir so ela (trocar por padrao simples, remover ultimo perigo, remover instancia; notas: remover a invalida) ->
revalidar -> comparar (severidade, 1a falha) -> aceitar/rejeitar; limite de tentativas; 3 rejeicoes seguidas => "oferecer edicao manual".

## Fluxo de importacao -> jogo
Minhas musicas (seletor nativo, validacao, copia local opcional, analise em thread) -> Criar fase (modo, dificuldade, estilo, trecho, pistas, seed) -> Carregamento
(`GenerationJob`: gerar -> previa validada -> validacao completa -> correcao -> finalizar; **TESTAR FASE** aparece quando a previa passa) -> JOGAR (somente READY), EDITAR, SALVAR, REGERAR.
