"""Suite de testes REAIS das ferramentas de referencia (Python). Gera documentation/TEST_REPORT.md e tools/out/test_results.json.
Nada aqui e inventado: cada teste executa codigo e registra o resultado. O que NAO pode ser executado neste ambiente
(Godot, Android, audio, toque) aparece na secao 'Nao executados' do relatorio."""
import copy, hashlib, json, os, resource, sys, time, traceback
sys.path.insert(0, os.path.dirname(__file__))
import numpy as np
from rdtools import synth, analyzer, generator, validator, fixer
from rdtools.common import ROOT, DATA, PATTERNS, DIFF, difficulty
from rdtools.level import Level, Timeline
from rdtools.sim import search

RESULTS = []
TMP = "/tmp/rd_tracks"
os.makedirs(TMP, exist_ok=True)


GROUPS_ARG = sys.argv[sys.argv.index("--group") + 1].split(",") if "--group" in sys.argv else None


def T(group, tid, name):
    def deco(fn):
        if GROUPS_ARG and group not in GROUPS_ARG:
            return fn
        t0 = time.time()
        try:
            r = fn()
            ok, detail = (r if isinstance(r, tuple) else (bool(r), ""))
        except Exception as e:
            ok, detail = False, "EXCECAO: %r\n%s" % (e, traceback.format_exc()[-400:])
        RESULTS.append({"group": group, "id": tid, "name": name, "status": "pass" if ok else "FAIL", "detail": detail,
                        "seconds": round(time.time() - t0, 2), "executed": "real (Python de referencia)"})
        print(("PASS " if ok else "FAIL ") + tid + " " + name + (" | " + detail if (detail and not ok) else ""), flush=True)
        return fn
    return deco


def track(bpm, off=0.3, sections=None, seed=None, kind="drums"):
    p = f"{TMP}/t{bpm}_{int(off*100)}.wav"
    if not os.path.exists(p):
        sig, dur = synth.render(bpm, sections or [(4, 0), (8, 1), (12, 2), (4, 0), (8, 2), (2, 0)], offset=off, seed=seed or bpm)
        synth.write_wav(p, sig)
    return p


def mk(objs, end_t=12.0, speed=10.4, forms=None):
    return Level({"speed_events": [{"t": 0, "speed": speed}], "form_events": forms or [], "objects": objs, "end_t": end_t})


def spikes(x, n):
    return [{"type": "spike", "x": x + k, "y": 0} for k in range(n)]


def pok():
    p = os.path.join(DATA, "pattern_compat.json")
    if not os.path.exists(p):
        return None
    tab = json.load(open(p)); bpms = tab["bpms"]

    def ok(pid, bpm, dn):
        row = tab["table"].get(pid, {}).get(dn)
        if row is None:
            return True
        lo = max([b for b in bpms if b <= bpm] or [bpms[0]]); hi = min([b for b in bpms if b >= bpm] or [bpms[-1]])
        return row.get(str(lo), True) and row.get(str(hi), True)
    return ok


PO = pok()
AN120 = analyzer.analyze_file(track(120, 0.37))

MATRIX = []
OUT = os.path.join(ROOT, "tools", "out")


def run_matrix_mode(mode):
    """Gera+valida(+corrige) modo x dificuldade x 3 musicas x 2 seeds. Cache em tools/out/matrix_<modo>.json (retomavel)."""
    cache = os.path.join(OUT, "matrix_%s.json" % mode)
    if os.path.exists(cache):
        return json.load(open(cache))
    rows = []
    ans = {str(b): analyzer.analyze_file(track(b, o)) for b, o in ((90, .37), (128, .21), (174, .11))}
    for dn in DIFF["order"]:
        for tk, a in ans.items():
            for seed in (1, 2):
                t0 = time.time()
                m = generator.generate(a, mode, dn, "balanced", seed=seed, pattern_ok=PO)
                r0 = validator.validate(m)
                if r0["status"] != "READY":
                    m, r, h = fixer.fix_and_validate(m)
                else:
                    r, h = r0, []
                rows.append({"mode": mode, "diff": dn, "track_bpm": tk, "seed": seed, "direct": r0["status"], "final": r["status"], "result": r["result"],
                             "fixes": len(h), "fails": r["counts"]["fail"], "t": round(time.time() - t0, 1)})
                print("   matriz", mode, dn, tk, seed, r0["status"], "->", r["status"], flush=True)
    json.dump(rows, open(cache, "w"))
    return rows


if "--matrix" in sys.argv:
    run_matrix_mode(sys.argv[sys.argv.index("--matrix") + 1])
    sys.exit(0)



# =============================================================== FISICA
@T("Fisica", "F01", "fase vazia e concluivel")
def _(): return search(mk([])).ok

@T("Fisica", "F02", "1 espinho e concluivel (pulo do cubo)")
def _(): return search(mk(spikes(30, 1))).ok

@T("Fisica", "F03", "parede de 3 blocos e IMPOSSIVEL para o cubo (busca exaustiva)")
def _():
    r = search(mk([{"type": "block", "x": 30, "y": 0, "w": 1, "h": 3}])); return (not r.ok and not r.truncated), r.as_dict().__str__()

@T("Fisica", "F04", "bloco de altura 1 e concluivel")
def _(): return search(mk([{"type": "block", "x": 30, "y": 0, "w": 1, "h": 1}])).ok

@T("Fisica", "F05", "8 espinhos adjacentes sao IMPOSSIVEIS (> distancia do salto)")
def _(): return not search(mk(spikes(30, 8))).ok

@T("Fisica", "F06", "3 espinhos adjacentes sao concluiveis")
def _(): return search(mk(spikes(30, 3))).ok

@T("Fisica", "F07", "cubo NAO consegue passar bloco de altura 2; robo (pulo longo) consegue")
def _():
    blk = [{"type": "block", "x": 30, "y": 0, "w": 1, "h": 2}]
    fe_r = [{"t": 0, "form": "cube"}, {"t": 1.5, "form": "robot", "gs": 1, "ceiling": False}]
    cube = search(mk(blk)); robot = search(mk(blk, forms=fe_r))
    return (not cube.ok) and robot.ok, "cubo=%s robo=%s" % (cube.ok, robot.ok)

def _corr(gap, forms, h0=2, n=40, W=2):
    objs = []
    for k in range(n):
        x = 30 + k * W
        objs.append({"type": "block", "x": x, "y": 0, "w": W, "h": h0})
        objs.append({"type": "block", "x": x, "y": h0 + gap, "w": W, "h": 9 - h0 - gap})
    return mk(objs, 14, forms=forms)

@T("Fisica", "F08", "nave: corredor largo concluivel, corredor de 0.5 bloco IMPOSSIVEL")
def _():
    fe = [{"t": 0, "form": "cube"}, {"t": 2.0, "form": "ship", "gs": 1}, {"t": 9.0, "form": "cube", "gs": 1}]
    a = search(_corr(5, fe), beam=1500); b = search(_corr(0.5, fe), beam=1500)
    return a.ok and not b.ok, "largo=%s estreito=%s" % (a.ok, b.ok)

@T("Fisica", "F09", "bola: espinhos alternados piso/teto exigem inverter e sao concluiveis; parede cheia (piso a teto) e impossivel")
def _():
    fe = [{"t": 0, "form": "cube"}, {"t": 1.0, "form": "ball", "gs": 1, "ceiling": True}, {"t": 10.0, "form": "cube", "gs": 1, "ceiling": False}]
    objs = []
    for j in range(5):
        x = 20 + j * 10
        objs.append({"type": "spike", "x": x, "y": 0} if j % 2 == 0 else {"type": "spike", "x": x, "y": 8, "flip": True})
    ok = search(mk(objs, 14, forms=fe)).ok
    # sem poder inverter (cubo com teto) o primeiro espinho de piso mata: valida que o espinho e letal
    kill = not search(mk([{"type": "spike", "x": 20, "y": 0}, {"type": "block", "x": 20, "y": 1, "w": 1, "h": 8}], 14, forms=[{"t": 0, "form": "cube"}])).ok
    wall = not search(mk([{"type": "block", "x": 25, "y": 0, "w": 1, "h": 9}], 14, forms=fe)).ok
    return ok and wall, "alternado=%s parede_cheia_impossivel=%s" % (ok, wall)

@T("Fisica", "F10", "aranha: troca instantanea de superficie conclui espinhos proximos")
def _():
    fe = [{"t": 0, "form": "cube"}, {"t": 1.0, "form": "spider", "gs": 1, "ceiling": True}, {"t": 10.0, "form": "cube", "gs": 1, "ceiling": False}]
    objs = []
    for j in range(5):
        x = 20 + j * 5
        objs.append({"type": "spike", "x": x, "y": 0} if j % 2 == 0 else {"type": "spike", "x": x, "y": 8, "flip": True})
    return search(mk(objs, 14, forms=fe)).ok

@T("Fisica", "F11", "onda: corredor em zigue-zague concluivel")
def _():
    fe = [{"t": 0, "form": "cube"}, {"t": 2.0, "form": "wave", "gs": 1, "ceiling": True}, {"t": 9.0, "form": "cube", "gs": 1, "ceiling": False}]
    objs = []
    for k in range(60):
        x = 30 + k
        h = [0, 0, 1, 1, 2, 2, 1, 1][k % 8]
        if h: objs.append({"type": "block", "x": x, "y": 0, "w": 1, "h": h})
        objs.append({"type": "block", "x": x, "y": h + 5, "w": 1, "h": 9 - h - 5})
    return search(mk(objs, 14, forms=fe), beam=1500).ok

@T("Fisica", "F12", "simulacao e deterministica (2 execucoes identicas)")
def _():
    L = mk(spikes(30, 2) + spikes(50, 3))
    a, b = search(L).as_dict(), search(L).as_dict(); return a == b

@T("Fisica", "F13", "posicao horizontal vem do relogio de audio: x(t) integra a velocidade por trechos")
def _():
    tl = Timeline([{"t": 0, "speed": 10.0}, {"t": 5, "speed": 20.0}])
    return abs(tl.x_at(7) - 90.0) < 1e-9 and abs(tl.t_at(90.0) - 7.0) < 1e-9

# =============================================================== ANALISE MUSICAL
for bpm, off in [(80, .2), (90, .37), (100, .12), (110, .3), (120, .37), (128, .21), (140, .05), (150, .3), (160, .2), (174, .11)]:
    def _mk(bpm=bpm, off=off):
        @T("Analise", "A%03d" % bpm, "BPM %d (offset %.2fs): detectado com equivalencia de oitava e fase < 40 ms" % (bpm, off))
        def _():
            a = analyzer.analyze_file(track(bpm, off))
            p = 60 / a["bpm"]
            d_off = ((a["offset"] - off + p / 2) % p) - p / 2
            oct_ok = min(abs(a["bpm"] - bpm * 2 ** k) / (bpm * 2 ** k) for k in (-1, 0, 1)) < 0.01
            exact = abs(a["bpm"] - bpm) / bpm < 0.01
            return oct_ok and abs(d_off) < 0.04, "detectado %.2f (%s) erro de fase %+.0f ms" % (a["bpm"], "exato" if exact else "oitava", d_off * 1000)
    _mk()

@T("Analise", "A101", "pad ambiente (sem percussao): confianca baixa e sem onsets falsos")
def _():
    sr = synth.SR_OUT; t = np.arange(int(40 * sr)) / sr
    pad = sum(np.sin(2 * np.pi * f * t) * (0.5 + 0.5 * np.sin(2 * np.pi * 0.07 * t + f)) for f in (110, 164.8, 220, 277)) * 0.1
    synth.write_wav(TMP + "/pad.wav", pad)
    a = analyzer.analyze_file(TMP + "/pad.wav"); return a["confidence"] < 0.25 and len(a["onsets"]) == 0, "conf=%s onsets=%d" % (a["confidence"], len(a["onsets"]))

@T("Analise", "A102", "silencio total: sem onsets, confianca 0, sem excecao")
def _():
    synth.write_wav(TMP + "/sil.wav", np.zeros(synth.SR_OUT * 20)); a = analyzer.analyze_file(TMP + "/sil.wav"); return a["confidence"] == 0 and len(a["onsets"]) == 0

@T("Analise", "A103", "arquivo invalido/corrompido gera erro tratavel (nao trava)")
def _():
    open(TMP + "/bad.mp3", "wb").write(b"isto nao e audio" * 50)
    try:
        analyzer.analyze_file(TMP + "/bad.mp3"); return False, "nao levantou erro"
    except Exception:
        return True

@T("Analise", "A104", "musica fraca em percussao nao e tratada como batida confiavel (vocal/sustentado)")
def _():
    sr = synth.SR_OUT; t = np.arange(int(30 * sr)) / sr
    voz = np.sin(2 * np.pi * 220 * t) * (0.6 + 0.4 * np.sin(2 * np.pi * 0.4 * t))
    synth.write_wav(TMP + "/voz.wav", voz * 0.5); a = analyzer.analyze_file(TMP + "/voz.wav"); return a["confidence"] < 0.25, "conf=%s" % a["confidence"]

# =============================================================== PADROES
@T("Padroes", "P01", "biblioteca: todos os padroes tem campos obrigatorios (id, modo, tier, entrada/saida, duracao)")
def _():
    bad = [p["id"] for p in PATTERNS if p["mode"] == "geometry_run" and not all(k in p for k in ("id", "name", "kind", "form", "tier", "entry", "exit", "length_beats"))]
    ids = [p["id"] for p in PATTERNS]; return not bad and len(ids) == len(set(ids)), "faltando %s" % bad

@T("Padroes", "P02", "cada padrao geometrico foi validado isoladamente e tem >=1 combinacao (dificuldade x BPM) aprovada")
def _():
    path = os.path.join(DATA, "pattern_compat.json")
    if not os.path.exists(path): return False, "pattern_compat.json ausente: rode tools/validate_patterns.py"
    tab = json.load(open(path))["table"]; miss = []
    for p in PATTERNS:
        if p["mode"] != "geometry_run": continue
        row = tab.get(p["id"], {}); anyok = any(v for d in row.values() for v in d.values())
        if not anyok: miss.append(p["id"])
    return not miss, "sem combinacao aprovada: %s" % miss

# =============================================================== GERACAO
@T("Geracao", "G01", "mesma seed => mapa identico (reprodutivel); id de geracao presente")
def _():
    a = generator.generate(AN120, "geometry_run", "normal", "balanced", seed=5, pattern_ok=PO)
    b = generator.generate(AN120, "geometry_run", "normal", "balanced", seed=5, pattern_ok=PO)
    h = lambda m: hashlib.sha256(json.dumps(m, sort_keys=True).encode()).hexdigest()
    return h(a) == h(b) and a["seed"] == 5 and a["generator_version"], ""

@T("Geracao", "G02", "seeds diferentes => mapas diferentes (8 seeds, >=7 distintos)")
def _():
    hs = {hashlib.sha256(json.dumps(generator.generate(AN120, "geometry_run", "hard", "balanced", seed=s, pattern_ok=PO)["objects"], sort_keys=True).encode()).hexdigest() for s in range(1, 9)}
    return len(hs) >= 7, "%d distintos" % len(hs)

@T("Geracao", "G03", "variedade de padroes: >=9 padroes distintos em 20 fases (hard)")
def _():
    s = set()
    for seed in range(1, 21):
        m = generator.generate(AN120, "geometry_run", "hard", "variations", seed=seed, pattern_ok=PO)
        s |= {i["pattern"] for i in m["instances"]}
    return len(s) >= 9, "%d padroes: %s" % (len(s), sorted(s))

@T("Geracao", "G04", "o final nao e sempre igual: >=3 finais distintos em 12 seeds")
def _():
    fin = set()
    for seed in range(1, 13):
        m = generator.generate(AN120, "geometry_run", "normal", "balanced", seed=seed, pattern_ok=PO)
        last = [o for o in m["objects"] if o["x"] >= m["objects"][-1]["x"] - 40]
        fin.add(tuple(sorted((o["type"], round(o["x"] - last[0]["x"], 0)) for o in last)))
    return len(fin) >= 3, "%d finais" % len(fin)

@T("Geracao", "G05", "recorte de trecho: tempos reancorados em 0 e fim = duracao do trecho")
def _():
    m = generator.generate(AN120, "geometry_run", "normal", "balanced", seed=2, trim=(10.0, 40.0), pattern_ok=PO)
    return abs(m["end_t"] - 29.6) < 0.01 and abs(m["audio"]["start"] - 10.0) < 1e-9, "end_t=%s start=%s" % (m["end_t"], m["audio"]["start"])

@T("Geracao", "G06", "os 7 estilos geram fases validas (geometria, normal)")
def _():
    bad = []
    for st in generator.STYLES:
        m = generator.generate(AN120, "geometry_run", "normal", st, seed=4, pattern_ok=PO); r = validator.validate(m)
        if r["status"] == "FAILED": bad.append(st)
    return not bad, "falharam: %s" % bad

@T("Geracao", "G07", "dificuldade Custom (parametros proprios) gera e valida")
def _():
    m = generator.generate(AN120, "geometry_run", "custom", "balanced", seed=3, custom={"min_gap_s": 0.7, "density": 0.6, "speed": "normal"}, pattern_ok=PO)
    m["custom"] = {"min_gap_s": 0.7, "density": 0.6, "speed": "normal"}
    r = validator.validate(m); return r["status"] != "FAILED", r["result"]

@T("Geracao", "G08", "Magic Rhythm: 3, 4, 5 e 6 pistas geram e validam")
def _():
    bad = []
    for ln in (3, 4, 5, 6):
        m = generator.generate(AN120, "magic_rhythm", "normal", "balanced", seed=2, lanes=ln); r = validator.validate(m)
        if r["status"] != "READY" or m["lanes"] != ln or not m["notes"]: bad.append(ln)
    return not bad, "falharam: %s" % bad

@T("Geracao", "G09", "Magic Rhythm: aparecem tipos tap/hold/double/slide/fast/special conforme dificuldade")
def _():
    kinds = set()
    for seed in range(1, 15):
        m = generator.generate(AN120, "magic_rhythm", "expert", "balanced", seed=seed, lanes=5)
        kinds |= {n["kind"] for n in m["notes"]}
    need = {"tap", "hold", "double", "slide", "special"}
    return need <= kinds, "tipos: %s" % sorted(kinds)

@T("Geracao", "G10", "Music Dash: alterna corrida e notas com portais de transicao fechados")
def _():
    m = generator.generate(AN120, "music_dash", "normal", "balanced", seed=3, pattern_ok=PO)
    r = validator.validate(m); lanes = [e for e in m["form_events"] if e["form"] == "lanes"]
    return r["status"] == "READY" and len(lanes) >= 1 and len(m["notes"]) > 10, "segmentos de notas=%d notas=%d %s" % (len(lanes), len(m["notes"]), r["result"])

# =============================================================== VALIDADOR (testes negativos / injecao de falhas)
def base_ok(seed=3, mode="geometry_run", dn="normal"):
    m = generator.generate(AN120, mode, dn, "balanced", seed=seed, pattern_ok=PO)
    m2, rep, h = fixer.fix_and_validate(m)
    assert rep["status"] == "READY", "base nao esta READY"
    return m2

BASE = base_ok()
BASE_N = generator.generate(AN120, "magic_rhythm", "normal", "balanced", seed=2)

def has(rep, tid, st="fail"):
    return any(t["id"] == tid and t["status"] == st for t in rep["tests"])

def inject(m, f):
    c = copy.deepcopy(m); f(c); return validator.validate(c)

@T("Validador", "V00", "fase base (gerada+corrigida) e Aprovada")
def _(): return validator.validate(BASE)["status"] == "READY"

@T("Validador", "V01", "parede impossivel => REPROVADA com G1 (simulacao)")
def _():
    xw = BASE["objects"][5]["x"] + 6
    r = inject(BASE, lambda c: c["objects"].append({"type": "block", "x": xw, "y": 0, "w": 1, "h": 4}))
    return r["status"] == "FAILED" and has(r, "G1"), r["result"]

@T("Validador", "V02", "espinho dentro de bloco => C1")
def _():
    def f(c): c["objects"] += [{"type": "block", "x": 500, "y": 0, "w": 3, "h": 2}, {"type": "spike", "x": 501, "y": 0}]
    return has(inject(BASE, f), "C1")

@T("Validador", "V03", "objeto acima da area jogavel => C3")
def _(): return has(inject(BASE, lambda c: c["objects"].append({"type": "block", "x": 600, "y": 8, "w": 1, "h": 4})), "C3")

@T("Validador", "V04", "objeto apos o fim da musica => T2")
def _():
    xe = Level(BASE).end_x + 30
    return has(inject(BASE, lambda c: c["objects"].append({"type": "spike", "x": xe, "y": 0})), "T2")

@T("Validador", "V05", "objetos duplicados => S6")
def _(): return has(inject(BASE, lambda c: c["objects"].append(dict(c["objects"][3]))), "S6")

@T("Validador", "V06", "perigo antes do lead-in => T1")
def _(): return has(inject(BASE, lambda c: c["objects"].append({"type": "spike", "x": 3.0, "y": 0})), "T1")

@T("Validador", "V07", "forma especial sem portal de saida => P1/P2")
def _():
    def f(c):
        t_last = max(e["t"] for e in c["form_events"]) + 1.0
        c["form_events"].append({"t": t_last, "form": "ship", "gs": 1, "ceiling": True})
    r = inject(BASE, f); return has(r, "P1") and has(r, "P2"), str([(t["id"], t["status"]) for t in r["tests"] if t["status"] != "pass"])

@T("Validador", "V08", "dois grupos de perigo mais proximos que o tempo de reacao (0.48 s < 0.56 s) => T3")
def _():
    def f(c):
        c["objects"] = [{"type": "spike", "x": 100, "y": 0}, {"type": "spike", "x": 105, "y": 0}]
        c["form_events"] = [{"t": 0.0, "form": "cube", "gs": 1, "ceiling": False}]
        c["instances"] = []
    return has(inject(BASE, f), "T3"), ""

def nvalid(f):
    c = copy.deepcopy(BASE_N); f(c); return validator.validate(c)

@T("Validador", "V10", "acorde de 3 notas simultaneas => N5")
def _():
    t0 = BASE_N["notes"][-1]["t"] - 5 if False else 20.0
    def f(c): c["notes"] += [{"t": 70.0, "lane": ln, "kind": "tap", "dur": 0.0} for ln in (0, 1, 2)]; c["notes"].sort(key=lambda n: n["t"])
    return has(nvalid(f), "N5")

@T("Validador", "V11", "densidade acima do limite => N4")
def _():
    def f(c): c["notes"] += [{"t": 72.0 + k * 0.11, "lane": k % 3, "kind": "tap", "dur": 0.0} for k in range(9)]; c["notes"].sort(key=lambda n: n["t"])
    r = nvalid(f); return has(r, "N4") or has(r, "N4", "warn"), ""

@T("Validador", "V12", "mesma pista com intervalo menor que o minimo => N3")
def _():
    def f(c): c["notes"] += [{"t": 71.0, "lane": 0, "kind": "tap", "dur": 0.0}, {"t": 71.05, "lane": 0, "kind": "tap", "dur": 0.0}]; c["notes"].sort(key=lambda n: n["t"])
    return has(nvalid(f), "N3")

@T("Validador", "V13", "notas impossiveis para 2 dedos (2 holds + toque + duplo) => N6")
def _():
    def f(c):
        c["notes"] += [{"t": 60.0, "lane": 0, "kind": "hold", "dur": 1.5}, {"t": 60.0, "lane": 2, "kind": "hold", "dur": 1.5}, {"t": 60.6, "lane": 1, "kind": "tap", "dur": 0.0}]
        c["notes"].sort(key=lambda n: (n["t"], n["lane"]))
    return has(nvalid(f), "N6")

@T("Validador", "V14", "slide para pista nao adjacente / nota em pista inexistente => S7")
def _():
    def f(c): c["notes"] += [{"t": 65.0, "lane": 0, "kind": "slide", "lane_to": 2, "dur": 0.5}, {"t": 66.0, "lane": 9, "kind": "tap", "dur": 0.0}]; c["notes"].sort(key=lambda n: n["t"])
    return has(nvalid(f), "S7")

@T("Validador", "V15", "notas fora da musica => falha")
def _():
    def f(c): c["notes"].append({"t": c["end_t"] + 5, "lane": 0, "kind": "tap", "dur": 0.0})
    r = nvalid(f); return r["status"] == "FAILED", r["result"]

@T("Validador", "V16", "padrao acima do nivel da dificuldade => D2")
def _():
    def f(c): c["difficulty"] = "beginner"
    c = copy.deepcopy(BASE); c["difficulty"] = "beginner"; c["instances"][0] = dict(c["instances"][0], tier=5, kind="static")
    return has(validator.validate(c), "D2")

@T("Validador", "V17", "busca truncada sem caminho => NAO VERIFICADA (nao READY, nao FAILED)")
def _():
    fe = [{"t": 0, "form": "cube"}, {"t": 2.0, "form": "ship", "gs": 1}, {"t": 9.0, "form": "cube", "gs": 1}]
    m = {"format": 1, "id": "x", "mode": "geometry_run", "difficulty": "normal", "audio": {"duration": 20, "bpm": 120}, "end_t": 14,
         "speed_events": [{"t": 0, "speed": 10.4}], "form_events": fe, "objects": _corr(5, fe).m["objects"], "notes": [], "lanes": 0, "instances": []}
    # beam=1 forca truncamento; o corredor exige varios estados
    r = validator.validate(m, beam=1)
    g1 = [t for t in r["tests"] if t["id"] == "G1"][0]
    return g1["status"] in ("unverified", "pass"), "G1=%s resultado=%s" % (g1["status"], r["result"])

@T("Validador", "V18", "regra: READY nunca coexiste com teste reprovado (invariante)")
def _():
    for m in (BASE, BASE_N):
        r = validator.validate(m)
        if r["status"] == "READY" and r["counts"]["fail"] > 0: return False
    for f in (lambda c: c["objects"].append({"type": "block", "x": 90, "y": 0, "w": 1, "h": 4}),):
        r = inject(BASE, f)
        if r["status"] == "READY" and r["counts"]["fail"] > 0: return False
    return True

# =============================================================== CORRETOR AUTOMATICO
@T("Corretor", "X01", "parede impossivel dentro de um padrao e corrigida (ciclo gerar->validar->corrigir->revalidar) e aprovada")
def _():
    m = copy.deepcopy(BASE)
    inst = [i for i in m["instances"] if i["kind"] == "static"][2]
    xs = [o["x"] for o in m["objects"] if o.get("inst") == inst["k"]]
    m["objects"].append({"type": "block", "x": max(xs) + 4, "y": 0, "w": 1, "h": 4, "inst": inst["k"]})
    rep0 = validator.validate(m)
    m2, rep, hist = fixer.fix_and_validate(m)
    return rep0["status"] == "FAILED" and rep["status"] == "READY" and any(h["accepted"] for h in hist), "%s -> %s em %d iteracoes: %s" % (rep0["result"], rep["result"], len(hist), [h["action"] for h in hist])

@T("Corretor", "X02", "correcao preserva o restante da fase (somente a instancia defeituosa e alterada)")
def _():
    m = copy.deepcopy(BASE)
    inst = [i for i in m["instances"] if i["kind"] == "static"][2]
    xs = [o["x"] for o in m["objects"] if o.get("inst") == inst["k"]]
    m["objects"].append({"type": "block", "x": max(xs) + 4, "y": 0, "w": 1, "h": 4, "inst": inst["k"]})
    before = {(o["type"], o["x"]) for o in m["objects"] if o.get("inst") != inst["k"]}
    m2, rep, hist = fixer.fix_and_validate(m)
    after = {(o["type"], o["x"]) for o in m2["objects"] if o.get("inst") != inst["k"]}
    return before == after, "removidos fora da instancia: %d" % len(before - after)

@T("Corretor", "X03", "notas com densidade/acorde invalidos sao corrigidas e aprovadas")
def _():
    m = copy.deepcopy(BASE_N)
    m["notes"] += [{"t": 72.0 + k * 0.11, "lane": k % 3, "kind": "tap", "dur": 0.0} for k in range(9)]
    m["notes"] += [{"t": 70.0, "lane": ln, "kind": "tap", "dur": 0.0} for ln in (0, 1, 2)]
    m["notes"].sort(key=lambda n: n["t"])
    rep0 = validator.validate(m); m2, rep, hist = fixer.fix_and_validate(m, max_iter=30)
    return rep0["status"] == "FAILED" and rep["status"] == "READY", "%s -> %s (%d correcoes)" % (rep0["result"], rep["result"], len(hist))

@T("Corretor", "X04", "defeito sem trecho responsavel: NAO e escondido; permanece FAILED e registra 'edicao manual'")
def _():
    m = copy.deepcopy(BASE); m["objects"] = [o for o in m["objects"]]
    m["objects"].append({"type": "block", "x": 60, "y": 0, "w": 1, "h": 4})   # sem 'inst'
    m2, rep, hist = fixer.fix_and_validate(m)
    return rep["status"] != "READY" and any("edicao manual" in (h.get("note") or "") for h in hist), "%s historico=%d" % (rep["result"], len(hist))

@T("Corretor", "X05", "limite de tentativas respeitado (sem laco infinito)")
def _():
    m = copy.deepcopy(BASE); m["objects"] += [{"type": "block", "x": 60 + 30 * k, "y": 0, "w": 1, "h": 4} for k in range(8)]
    for i, o in enumerate(m["objects"]):
        if "inst" not in o: o["inst"] = m["instances"][min(i, len(m["instances"]) - 1)]["k"]
    t0 = time.time(); m2, rep, hist = fixer.fix_and_validate(m, max_iter=3); its = max([h["iter"] for h in hist] or [0]); return its <= 3 and time.time() - t0 < 120, "iteracoes=%d (entradas no historico=%d)" % (its, len(hist))

@T("Corretor", "X06", "regressao: fase corrigida revalidada do zero continua READY e identica ao relatorio")
def _():
    m = copy.deepcopy(BASE)
    inst = [i for i in m["instances"] if i["kind"] == "static"][1]
    xs = [o["x"] for o in m["objects"] if o.get("inst") == inst["k"]]
    m["objects"].append({"type": "block", "x": max(xs) + 4, "y": 0, "w": 1, "h": 4, "inst": inst["k"]})
    m2, rep, hist = fixer.fix_and_validate(m); again = validator.validate(json.loads(json.dumps(m2)))
    return again["status"] == "READY" == rep["status"] and again["counts"] == rep["counts"], ""

# =============================================================== MATRIZ DE GERACAO (ver run_matrix_mode acima)
@T("Geracao", "G20", "MATRIZ: modo x dificuldade x musica x seed (90 fases) - nenhuma fase READY com teste reprovado")
def _():
    for md in ("geometry_run", "magic_rhythm", "music_dash"):
        MATRIX.extend(run_matrix_mode(md))
    inv = [x for x in MATRIX if x["final"] == "READY" and x["fails"] > 0]
    return not inv, "invariante violada: %s" % inv[:3]

@T("Geracao", "G21", "MATRIZ: taxa de fases READY (apos correcao) >= 90%")
def _():
    rate = sum(1 for x in MATRIX if x["final"] == "READY") / len(MATRIX); return rate >= 0.9, "%.1f%% READY" % (rate * 100)

# =============================================================== FASES OFICIAIS
@T("Oficiais", "O01", "5 fases oficiais existem com mapas reais (objetos/notas/eventos) e audio OGG")
def _():
    idx = json.load(open(os.path.join(DATA, "levels", "index.json")))["levels"]
    bad = []
    for e in idx:
        m = json.load(open(os.path.join(DATA, "levels", e["id"] + ".json")))
        aud = os.path.join(ROOT, "assets", "music", os.path.basename(e["audio"]))
        if not (os.path.exists(aud) and (len(m["objects"]) > 20 or len(m["notes"]) > 20) and len(m["instances"]) > 3): bad.append(e["id"])
    return len(idx) == 5 and not bad, "problemas: %s" % bad

OFFICIAL = []
@T("Oficiais", "O02", "cada fase oficial revalidada do zero (arquivo salvo) => READY")
def _():
    idx = json.load(open(os.path.join(DATA, "levels", "index.json")))["levels"]; bad = []
    for e in idx:
        m = json.load(open(os.path.join(DATA, "levels", e["id"] + ".json")))
        t0 = time.time(); r = validator.validate(m)
        OFFICIAL.append({"id": e["id"], "name": e["name"], "mode": m["mode"], "difficulty": m["difficulty"], "status": r["status"], "result": r["result"],
                         "counts": r["counts"], "est": r["difficulty_estimate"], "objs": len(m["objects"]), "notes": len(m["notes"]),
                         "instances": len(m["instances"]), "speed_events": len(m["speed_events"]), "seed": e["seed"], "fixes": len(m.get("validation_history", [])),
                         "dur": m["end_t"], "bpm": m["audio"]["bpm"], "sim": r["sim"], "seconds": round(time.time() - t0, 1)})
        if r["status"] != "READY": bad.append(e["id"])
    return len(idx) == 5 and not bad, "nao READY: %s" % bad

# =============================================================== ENDLESS
@T("Endless", "E01", "Endless: 12 blocos (96 compassos) com dificuldade crescente sao concluiveis (3 seeds)")
def _():
    bad = []
    for seed in (1, 2, 3):
        m = generator.generate_endless(12, seed, 128, PO); r = validator.validate(m)
        if r["status"] != "READY":
            m, r, h = fixer.fix_and_validate(m)
        if r["status"] != "READY": bad.append((seed, r["result"]))
    return not bad, "falhas: %s" % bad

@T("Endless", "E02", "Endless: velocidade e dificuldade sobem gradualmente (sem saltos > 1 nivel)")
def _():
    m = generator.generate_endless(12, 1, 128, PO)
    sp = [e["speed"] for e in m["speed_events"]]
    tiers = [generator.endless_ramp(b)[0] for b in range(0, 100)]
    order = DIFF["order"]; idxs = [order.index(t) for t in tiers]
    return all(b - a in (0, 1) for a, b in zip(idxs, idxs[1:])) and sp[-1] >= sp[0], "velocidade %.1f -> %.1f" % (sp[0], sp[-1])

# =============================================================== PERSISTENCIA / PERFORMANCE (referencia)
@T("Persistencia", "D01", "mapa serializa/desserializa (JSON) sem perda e continua valido")
def _():
    s = json.dumps(BASE); m = json.loads(s); return validator.validate(m)["status"] == "READY"

@T("Performance", "R01", "tempo de analise de 78 s de audio < 10 s (referencia Python)")
def _():
    t0 = time.time(); analyzer.analyze_file(track(120, .37)); dt = time.time() - t0; return dt < 10, "%.2f s" % dt

@T("Performance", "R02", "geracao + validacao de uma fase de 78 s < 30 s (referencia Python)")
def _():
    t0 = time.time(); m = generator.generate(AN120, "geometry_run", "expert", "balanced", seed=1, pattern_ok=PO); validator.validate(m); dt = time.time() - t0
    return dt < 30, "%.2f s" % dt

@T("Performance", "R03", "memoria de pico da suite < 1.5 GB (referencia Python)")
def _():
    mb = resource.getrusage(resource.RUSAGE_SELF).ru_maxrss / 1024; return mb < 1500, "%.0f MB" % mb


# =============================================================== RELATORIO
def report():
    npass = sum(1 for r in RESULTS if r["status"] == "pass"); nfail = len(RESULTS) - npass
    groups = {}
    for r in RESULTS: groups.setdefault(r["group"], []).append(r)
    L = []
    L.append("# Relatorio de testes - Rhythm Dimension\n")
    L.append("Gerado automaticamente por `tools/run_tests.py` em 2026-11-05. **Todos os resultados abaixo foram executados de verdade** nas "
             "ferramentas de referencia em Python (`tools/rdtools`), que implementam o mesmo algoritmo do jogo. "
             "**Nada foi executado no Godot nem em Android** (ambiente sem Godot/Android SDK/rede) - veja a secao 'Nao executados'.\n")
    L.append("## Resumo\n")
    L.append("| Total | Aprovados | Reprovados |\n|---|---|---|\n| %d | %d | %d |\n" % (len(RESULTS), npass, nfail))
    L.append("| Grupo | Testes | Aprovados | Reprovados |\n|---|---|---|---|")
    for g, rs in groups.items():
        L.append("| %s | %d | %d | %d |" % (g, len(rs), sum(r["status"] == "pass" for r in rs), sum(r["status"] != "pass" for r in rs)))
    L.append("\n## Fases oficiais (revalidadas do zero a partir do arquivo salvo)\n")
    L.append("| ID | Nome | Modo | Dif. | BPM | Duracao | Obj/Notas | Padroes | Status | Resultado | Testes (ok/aviso/falha/nao verif.) | Dif. estimada | Seed | Correcoes |\n|---|---|---|---|---|---|---|---|---|---|---|---|---|---|")
    for o in OFFICIAL:
        c = o["counts"]
        L.append("| %s | %s | %s | %s | %s | %.0fs | %d/%d | %d | %s | %s | %d/%d/%d/%d | %s | %s | %d |" % (o["id"], o["name"], o["mode"], o["difficulty"], o["bpm"], o["dur"], o["objs"], o["notes"],
                 o["instances"], o["status"], o["result"], c["pass"], c["warn"], c["fail"], c["unverified"], o["est"], o["seed"], o["fixes"]))
    L.append("\n## Matriz de geracao (modo x dificuldade x musica x seed)\n")
    if MATRIX:
        L.append("| Modo | Dificuldade | Fases | READY direto | READY apos correcao | Nao READY |\n|---|---|---|---|---|---|")
        for mode in ("geometry_run", "magic_rhythm", "music_dash"):
            for dn in DIFF["order"]:
                xs = [x for x in MATRIX if x["mode"] == mode and x["diff"] == dn]
                d = sum(1 for x in xs if x["direct"] == "READY"); f = sum(1 for x in xs if x["direct"] != "READY" and x["final"] == "READY")
                L.append("| %s | %s | %d | %d | %d | %d |" % (mode, dn, len(xs), d, f, len(xs) - d - f))
        nr = [x for x in MATRIX if x["final"] != "READY"]
        L.append("\nFases que NAO ficaram READY: %s\n" % (json.dumps(nr) if nr else "nenhuma"))
    L.append("## Todos os testes\n")
    L.append("| ID | Grupo | Teste | Resultado | Detalhe |\n|---|---|---|---|---|")
    for r in RESULTS:
        L.append("| %s | %s | %s | %s | %s |" % (r["id"], r["group"], r["name"].replace("|", "/"), r["status"], (r["detail"] or "").replace("|", "/").replace("\n", " ")[:160]))
    lint = os.path.join(ROOT, "tools", "out", "gdscript_lint.json")
    if os.path.exists(lint):
        lj = json.load(open(lint))
        L.append("\n## Verificacao estatica dos .gd (tools/gdscript_lint.py)\n")
        L.append("%d arquivos, %d linhas. Erros: %d. Avisos: %d (as duas classes internas TimelineView e Gen sao legitimas). **Isto NAO e o parser do Godot**: so confere indentacao com tabs, balanceamento de parenteses, class_name duplicado/igual a autoload, autoloads/cena/recursos existentes e lambdas de uma linha com varias instrucoes. Nao detecta erros de tipo, API inexistente nem erros de execucao.\n" %
                 (lj["files"], lj["lines"], len(lj["errors"]), len(lj["warnings"])))
    L.append("\n## Nao executados (limitacoes reais do ambiente)\n")
    L.append("""Estes itens **nao foram testados** e **nao devem ser considerados validados**:

- Interpretacao/execucao de qualquer script GDScript (nao ha Godot neste ambiente). O codigo GDScript foi escrito como porta direta dos algoritmos testados em Python, mas **nunca foi executado**.
- Todos os botoes dos menus, cenas, editor de fases, modo pratica, replay e telas de resultado (dependem do motor).
- Reproducao real de audio, pausa/retomada, interrupcoes (ligacao, fone), latencia e offset de sincronizacao no aparelho.
- Importacao de MP3/WAV/OGG pelo seletor de arquivos do Android; decodificacao de MP3/OGG pelo Godot; **FLAC nao e suportado nativamente pelo Godot 4** (documentado).
- Toque na tela, multitoque, orientacao, permissoes.
- FPS, memoria e tempo de carregamento no aparelho (os tempos de R01-R03 sao do codigo Python de referencia, nao do jogo).
- Exportacao Android / APK (sem Android SDK, JDK de assinatura e templates de exportacao). **Nenhum APK foi gerado.**
- Sensacao de jogo, diversao e dificuldade percebida por humanos (a 'dificuldade estimada' e uma heuristica calibrada no gerador).
""")
    L.append("## Limites do que foi provado\n")
    L.append("""- A simulacao fisica testa **se existe uma trajetoria** com entradas amostradas a 30 Hz sobre a fisica de referencia (`data/physics.json`). Aprovada = caminho encontrado (prova de viabilidade). Reprovada = busca exaustiva sem caminho. Nao verificada = busca truncada sem caminho (nao e possivel afirmar).
- 'Fase tecnicamente valida', 'funcional', 'testada' e 'aprovada para entrega' sao niveis distintos (campo `levels` do relatorio de cada fase). Passar nos testes **nao prova que a fase e divertida**.
- A analise de BPM foi verificada com audio sintetico de BPM conhecido (equivalencia de oitava aceita: 80->160 e 174->87). Musica real (voz, ritmo variavel, swing) **nao foi testada**; o jogo mostra a confianca e permite ajuste manual de BPM/offset.
""")
    os.makedirs(os.path.join(ROOT, "documentation"), exist_ok=True)
    open(os.path.join(ROOT, "documentation", "TEST_REPORT.md"), "w").write("\n".join(L))
    json.dump({"results": RESULTS, "matrix": MATRIX, "official": OFFICIAL}, open(os.path.join(ROOT, "tools", "out", "test_results.json"), "w"), indent=1, default=str)
    print("\nTOTAL %d  PASS %d  FAIL %d" % (len(RESULTS), npass, nfail))
    return nfail


def save_state():
    os.makedirs(OUT, exist_ok=True)
    for g in {r["group"] for r in RESULTS}:
        data = {"results": [r for r in RESULTS if r["group"] == g]}
        if g == "Geracao": data["matrix"] = MATRIX
        if g == "Oficiais": data["official"] = OFFICIAL
        json.dump(data, open(os.path.join(OUT, "res_%s.json" % g), "w"), indent=1, default=str)


def load_state():
    RESULTS.clear(); MATRIX.clear(); OFFICIAL.clear()
    order = ["Fisica", "Analise", "Padroes", "Geracao", "Validador", "Corretor", "Oficiais", "Endless", "Persistencia", "Performance"]
    for g in order:
        p = os.path.join(OUT, "res_%s.json" % g)
        if os.path.exists(p):
            d = json.load(open(p)); RESULTS.extend(d["results"]); MATRIX.extend(d.get("matrix", [])); OFFICIAL.extend(d.get("official", []))


if __name__ == "__main__":
    if "--report" not in sys.argv:
        save_state()
    load_state()
    sys.exit(1 if report() else 0)
