"""Validador de fases. Espelha scripts/validation/level_validator.gd.

Cada teste retorna um registro {id, category, name, status, detail, refs, executed}.
status: pass | warn | fail | unverified.  executed: 'real' (executado de fato) ou 'heuristic'.
Resultado final: Aprovada | Aprovada com avisos | Reprovada | Nao verificada -> status READY | FAILED | UNVERIFIED.
"""
import math
from .common import PHYS, difficulty
from .level import Level, Timeline
from .sim import search

CEIL = PHYS["ceiling_y"]
FORMS = ("cube", "ship", "ball", "robot", "spider", "wave", "lanes")
NOTE_KINDS = ("tap", "hold", "double", "slide", "fast", "special")
OBJ_TYPES = ("spike", "block")


def _t(id_, cat, name, status, detail="", refs=None, executed="real"):
    return {"id": id_, "category": cat, "name": name, "status": status, "detail": detail, "refs": refs or [], "executed": executed}


def diff_of(m):
    name = m.get("difficulty", "normal")
    if name == "endless":
        d = difficulty("beginner")
        d["name"] = "endless"
        d["band"] = [0.0, 10.1]
        return d
    if name == "custom":
        return difficulty("custom", m.get("custom"))
    return difficulty(name)


# ------------------------------------------------------------------ estrutura
def test_structure(m, out):
    miss = [k for k in ("format", "id", "mode", "difficulty", "audio", "end_t", "speed_events") if k not in m]
    out.append(_t("S1", "estrutura", "campos obrigatorios", "fail" if miss else "pass", "faltando: %s" % miss if miss else ""))
    if miss:
        return
    a = m["audio"]
    ok = a.get("duration", 0) > 5 and a.get("bpm", 0) > 30 and 8.0 <= m["end_t"] <= a["duration"] + 0.01
    out.append(_t("S2", "estrutura", "duracao/BPM/fim dentro da musica", "pass" if ok else "fail", "end_t=%s dur=%s bpm=%s" % (m["end_t"], a.get("duration"), a.get("bpm"))))
    bad = []
    for i, o in enumerate(m.get("objects", [])):
        try:
            x, y = float(o["x"]), float(o.get("y", 0))
            w, h = float(o.get("w", 1)), float(o.get("h", 1))
            if o["type"] not in OBJ_TYPES or not all(map(math.isfinite, (x, y, w, h))) or x < 0 or w <= 0 or h <= 0 or y < 0:
                bad.append(i)
        except Exception:
            bad.append(i)
    out.append(_t("S3", "estrutura", "objetos validos (tipo, numeros, x>=0, tamanhos)", "fail" if bad else "pass", "indices: %s" % bad[:10], bad))
    ev_bad = []
    last = -1.0
    for i, e in enumerate(m.get("form_events", [])):
        if e.get("form") not in FORMS or e.get("gs", 1) not in (1, -1) or not (0 <= e["t"] <= m["end_t"]) or e["t"] < last - 1e-9:
            ev_bad.append(i)
        last = e["t"]
    out.append(_t("S4", "estrutura", "eventos de forma/portal (tempo, forma, gravidade)", "fail" if ev_bad else "pass", "indices: %s" % ev_bad, ev_bad))
    sp_bad = [i for i, e in enumerate(m["speed_events"]) if not (4 <= e["speed"] <= 25) or e["t"] < 0 or e["t"] > m["end_t"]]
    out.append(_t("S5", "estrutura", "eventos de velocidade", "fail" if sp_bad else "pass", "", sp_bad))
    # duplicados
    seen, dup = set(), []
    for i, o in enumerate(m.get("objects", [])):
        k = (o["type"], round(o["x"], 2), o.get("y", 0), o.get("flip", False))
        if k in seen:
            dup.append(i)
        seen.add(k)
    out.append(_t("S6", "estrutura", "objetos duplicados", "fail" if dup else "pass", "", dup))
    # notas
    lanes = m.get("lanes", 0)
    nb = []
    for i, n in enumerate(m.get("notes", [])):
        okn = n.get("kind") in NOTE_KINDS and 0 <= n.get("lane", -1) < max(lanes, 1) and n.get("dur", 0) >= 0 and 0 <= n["t"] <= m["end_t"]
        if n.get("kind") == "slide":
            lt = n.get("lane_to")
            okn = okn and lt is not None and abs(lt - n["lane"]) == 1 and 0 <= lt < lanes and n["dur"] >= 0.2
        if n.get("kind") == "hold":
            okn = okn and n["dur"] >= 0.15
        if not okn:
            nb.append(i)
    out.append(_t("S7", "estrutura", "notas validas (tipo, pista, duracao, adjacencia do slide)", "fail" if nb else "pass", "indices: %s" % nb[:10], nb))
    if m.get("mode") in ("magic_rhythm", "music_dash") and m.get("notes") is not None and len(m["notes"]) == 0:
        out.append(_t("S8", "estrutura", "fase de notas tem notas", "fail", "nenhuma nota"))


# ------------------------------------------------------------------ colisao / posicionamento
def test_collision(m, out):
    objs = m.get("objects", [])
    solids = [(i, o["x"], o.get("y", 0), o["x"] + o.get("w", 1), o.get("y", 0) + o.get("h", 1)) for i, o in enumerate(objs) if o["type"] == "block"]
    spikes = [(i, o["x"], o.get("y", 0)) for i, o in enumerate(objs) if o["type"] == "spike"]
    solids.sort(key=lambda s: s[1])
    inside = []
    for (i, sx, sy) in spikes:
        for (j, x0, y0, x1, y1) in solids:
            if x0 > sx + 1.0:
                break
            if sx + 1.0 > x0 + 1e-6 and sx < x1 - 1e-6 and sy + 1.0 > y0 + 1e-6 and sy < y1 - 1e-6:
                inside.append(i)
                break
    out.append(_t("C1", "colisao", "espinho dentro de bloco (hitbox impossivel)", "fail" if inside else "pass", "", inside))
    ov = []
    for a in range(len(solids)):
        for b in range(a + 1, len(solids)):
            ia, ax0, ay0, ax1, ay1 = solids[a]
            ib, bx0, by0, bx1, by1 = solids[b]
            if bx0 >= ax1:
                break
            if min(ax1, bx1) - max(ax0, bx0) > 0.01 and min(ay1, by1) - max(ay0, by0) > 0.01:
                ov.append(ib)
    out.append(_t("C2", "colisao", "blocos sobrepostos", "warn" if ov else "pass", "indices: %s" % ov[:10], ov))
    fe = sorted(m.get("form_events", []), key=lambda e: e["t"])
    tl = Timeline(m["speed_events"])
    oob = []
    for i, o in enumerate(objs):
        top = o.get("y", 0) + (o.get("h", 1) if o["type"] == "block" else 1)
        if top > CEIL + 1e-6 or o.get("y", 0) < 0:
            oob.append(i)
    out.append(_t("C3", "colisao", "objetos dentro da area jogavel", "fail" if oob else "pass", "", oob))
    # objetos dentro de trecho 'lanes'
    lane_iv = []
    for k, e in enumerate(fe):
        if e["form"] == "lanes":
            t_end = fe[k + 1]["t"] if k + 1 < len(fe) else m["end_t"]
            lane_iv.append((e["t"], t_end))
    bad = [i for i, o in enumerate(objs) if any(a - 0.05 <= tl.t_at(o["x"]) <= b + 0.05 for a, b in lane_iv)]
    out.append(_t("C4", "colisao", "perigos dentro de trecho de notas (Music Dash)", "fail" if bad else "pass", "", bad))


# ------------------------------------------------------------------ tempo
def diff_at(m, d, t):
    """Dificuldade vigente no instante t (Endless muda por compasso; demais modos: constante)."""
    tb = m.get("tier_by_bar")
    if not tb:
        return d
    bar_len = 240.0 / m["audio"]["bpm"]
    k = min(max(int((t - m["audio"]["offset"]) // bar_len), 0), len(tb) - 1)
    return difficulty(tb[k])


def _hazard_groups(m, tl):
    """Grupos de perigos fora de corredores/formas especiais (para espacamento e reacao)."""
    fe = sorted(m.get("form_events", []), key=lambda e: e["t"])

    def form_at(t):
        f = "cube"
        for e in fe:
            if e["t"] <= t:
                f = e["form"]
            else:
                break
        return f

    items = []
    for i, o in enumerate(m.get("objects", [])):
        t0 = tl.t_at(o["x"])
        t1 = tl.t_at(o["x"] + o.get("w", 1))
        f = form_at(t0)
        items.append((t0, t1, i, f))
    items.sort()
    groups = []
    for (t0, t1, i, f) in items:
        if groups and t0 - groups[-1]["t1"] < 0.25 and f == groups[-1]["form"]:
            groups[-1]["t1"] = max(groups[-1]["t1"], t1)
            groups[-1]["refs"].append(i)
        else:
            groups.append({"t0": t0, "t1": t1, "form": f, "refs": [i]})
    return groups


def test_timing(m, out, d):
    tl = Timeline(m["speed_events"])
    objs = m.get("objects", [])
    if objs:
        first = min(tl.t_at(o["x"]) for o in objs)
        out.append(_t("T1", "tempo", "primeiro perigo respeita a entrada (lead-in)", "pass" if first >= d["lead_in_s"] - 0.3 else "fail",
                      "primeiro em %.2fs (min %.2fs)" % (first, d["lead_in_s"] - 0.3)))
        late = [i for i, o in enumerate(objs) if tl.t_at(o["x"]) > m["end_t"] + 0.01]
        out.append(_t("T2", "tempo", "objetos fora da musica (apos o fim)", "fail" if late else "pass", "", late))
        groups = [g for g in _hazard_groups(m, tl) if g["form"] in ("cube", "robot")]
        bad, warn = [], []
        for a, b in zip(groups, groups[1:]):
            gap = b["t0"] - a["t0"]
            mg = diff_at(m, d, b["t0"])["min_gap_s"]
            if gap < mg * 0.7:
                bad.append(b["refs"][0])
            elif gap < mg * 0.9:
                warn.append(b["refs"][0])
        out.append(_t("T3", "tempo", "espacamento minimo entre perigos (reacao, por dificuldade)", "fail" if bad else "warn" if warn else "pass",
                      "min_gap=%.2fs" % d["min_gap_s"], bad or warn))
        last_end = max(tl.t_at(o["x"] + o.get("w", 1)) for o in objs)
        out.append(_t("T4", "tempo", "pista livre ate o fim (finalizacao)", "pass" if m["end_t"] - last_end >= 1.0 else "fail", "folga %.2fs" % (m["end_t"] - last_end)))
        # reacao apos portal de forma
        fe = sorted(m.get("form_events", []), key=lambda e: e["t"])
        qb = []
        for e in fe:
            if e["form"] in ("ball", "spider", "robot", "ship", "wave") and e["t"] > 0:
                nxt = [tl.t_at(o["x"]) for o in objs if tl.t_at(o["x"]) >= e["t"] - 0.01]
                if nxt and min(nxt) - e["t"] < d["reaction_s"]:
                    qb.append(round(e["t"], 2))
        out.append(_t("T5", "tempo", "tempo de reacao apos portal de forma", "fail" if qb else "pass", "portais em %s" % qb, []))


# ------------------------------------------------------------------ notas
def _finger_check(notes, lanes):
    """Verifica se 2 dedos conseguem executar as notas (ocupacao por hold/slide + tempo de deslocamento)."""
    TRAVEL = 0.045
    PRESS = 0.05
    fingers = [{"pos": lanes // 2, "free": -9.0}, {"pos": lanes // 2, "free": -9.0}]
    i = 0
    n = len(notes)
    while i < n:
        j = i
        while j + 1 < n and abs(notes[j + 1]["t"] - notes[i]["t"]) < 0.005:
            j += 1
        grp = notes[i:j + 1]
        if len(grp) > 2:
            return i
        used = set()
        for nt in sorted(grp, key=lambda q: q["lane"]):
            best, bs = None, 1e9
            for fi, f in enumerate(fingers):
                if fi in used:
                    continue
                ready = f["free"] + min(TRAVEL * abs(f["pos"] - nt["lane"]), 0.14)
                if ready <= nt["t"] + 1e-6:
                    sc = abs(f["pos"] - nt["lane"]) + max(0.0, (nt["t"] - f["free"]))*0.0
                    if sc < bs:
                        best, bs = fi, sc
            if best is None:
                return i
            used.add(best)
            f = fingers[best]
            end = nt["t"] + max(nt.get("dur", 0.0), PRESS)
            f["free"] = end
            f["pos"] = nt.get("lane_to", nt["lane"]) if nt["kind"] == "slide" else nt["lane"]
        i = j + 1
    return None


def test_notes(m, out, d):
    notes = m.get("notes", [])
    if not notes:
        return
    nd = d["notes"]
    lanes = m["lanes"]
    ts = [n["t"] for n in notes]
    out.append(_t("N1", "notas", "notas ordenadas e dentro da musica", "pass" if ts == sorted(ts) and ts[-1] <= m["end_t"] else "fail"))
    out.append(_t("N2", "notas", "primeira nota respeita a entrada", "pass" if ts[0] >= d["lead_in_s"] - 0.3 else "fail", "primeira em %.2fs" % ts[0]))
    # pista: espacamento
    last, badg = {}, []
    for i, n in enumerate(notes):
        for ln, endt in ((n["lane"], n["t"] + n.get("dur", 0.0)),) + (((n["lane_to"], n["t"] + n.get("dur", 0.0)),) if n["kind"] == "slide" else ()):
            if ln in last and n["t"] - last[ln] < nd["lane_gap_s"] * 0.98:
                badg.append(i)
            last[ln] = endt
    out.append(_t("N3", "notas", "intervalo minimo por pista (tempo de reacao)", "fail" if badg else "pass", "min %.2fs" % nd["lane_gap_s"], badg))
    # densidade
    mx, wi = 0, 0
    j = 0
    for i in range(len(ts)):
        while ts[i] - ts[j] > 1.0:
            j += 1
        if i - j + 1 > mx:
            mx, wi = i - j + 1, i
    lim = nd["max_nps"]
    st = "fail" if mx > lim * 1.15 else "warn" if mx > lim + 1e-9 else "pass"
    out.append(_t("N4", "notas", "densidade maxima (notas/s em janela de 1s)", st, "pico=%d limite=%.1f" % (mx, lim), [wi]))
    out[-1]["severity"] = max(0.0, mx - lim)
    # acordes
    big, i = [], 0
    while i < len(notes):
        j = i
        while j + 1 < len(notes) and abs(notes[j + 1]["t"] - notes[i]["t"]) < 0.005:
            j += 1
        if j - i + 1 > nd["max_chord"]:
            big.extend(range(i + nd["max_chord"], j + 1))
        i = j + 1
    out.append(_t("N5", "notas", "tamanho maximo de acorde/notas simultaneas", "fail" if big else "pass", "max %d" % nd["max_chord"], big))
    fi = _finger_check(notes, lanes)
    out.append(_t("N6", "notas", "execucao com 2 dedos (alcance, hold/slide ocupando dedo)", "fail" if fi is not None else "pass", "", [fi] if fi is not None else []))
    if fi is not None:
        out[-1]["t_fail"] = notes[fi]["t"]
    dup = [i for i in range(1, len(notes)) if notes[i]["lane"] == notes[i - 1]["lane"] and abs(notes[i]["t"] - notes[i - 1]["t"]) < 0.001]
    out.append(_t("N7", "notas", "notas duplicadas/sobrepostas na mesma pista", "fail" if dup else "pass", "", dup))
    out.append(_t("N8", "notas", "quantidade de pistas valida para a dificuldade", "pass" if 3 <= lanes <= 6 else "fail", "lanes=%d" % lanes))


# ------------------------------------------------------------------ progressao
def test_progression(m, out, d):
    fe = sorted(m.get("form_events", []), key=lambda e: e["t"])
    if m.get("mode") in ("geometry_run", "music_dash", "endless"):
        open_special = [e for e in fe if e["form"] in ("ship", "ball", "spider", "robot", "wave", "lanes")]
        ok = True
        cur = "cube"
        for e in fe:
            cur = e["form"]
        ok = cur == "cube"
        out.append(_t("P1", "progressao", "fase termina em forma normal (portais de saida presentes)", "pass" if ok else "fail"))
        exitless = []
        for k, e in enumerate(fe):
            if e["form"] != "cube" and (k + 1 >= len(fe) or fe[k + 1]["form"] == e["form"]):
                exitless.append(round(e["t"], 2))
        out.append(_t("P2", "progressao", "toda forma especial tem saida (transicoes completas)", "fail" if exitless else "pass", "%s" % exitless))
        if m.get("instances"):
            insts = m["instances"]
            over = []
            for a, b in zip(insts, insts[1:]):
                if b["t0"] < a["t1"] - 0.01:
                    over.append(b["k"])
            out.append(_t("P3", "progressao", "padroes consecutivos nao se sobrepoem", "fail" if over else "pass", "", []))
            tiers = [i["tier"] for i in insts if i["kind"] != "finale"]
            toohigh = [i["k"] for i in insts if i["kind"] == "static" and i["tier"] > diff_at(m, d, i["t0"])["tier"]]
            out.append(_t("D2", "dificuldade", "nenhum padrao acima do nivel da dificuldade (nao subir so por velocidade)", "fail" if toohigh else "pass", "", []))
    out.append(_t("P4", "progressao", "possibilidade de concluir (ver teste de gameplay)", "pass", "validado pela simulacao G1/G2", [], "real"))


def estimate_difficulty(m, d):
    tl = Timeline(m["speed_events"])
    active = max(m["end_t"] - d["lead_in_s"], 1.0)
    if m.get("mode") == "magic_rhythm":
        notes = m.get("notes", [])
        if not notes:
            return 0.0
        mean_nps = len(notes) / active
        ts = [n["t"] for n in notes]
        mx, j = 1, 0
        for i in range(len(ts)):
            while ts[i] - ts[j] > 1.0:
                j += 1
            mx = max(mx, i - j + 1)
        s = 0.5 * min(mean_nps / 6.0, 1) + 0.3 * min(mx / 9.0, 1) + 0.2 * (m["lanes"] - 3) / 3.0
        return round(10 * max(0.0, min(s, 1.0)), 2)
    groups = _hazard_groups(m, tl)
    cube_groups = [g for g in groups if g["form"] in ("cube", "robot")]
    forms = [e for e in m.get("form_events", []) if e["form"] not in ("cube", "lanes") ]
    n_forms = len([e for e in forms if True]) / 2.0
    ev = (len(cube_groups) + 3 * n_forms + len(m.get('notes', [])) / 3.0) / active
    sp = [e["speed"] for e in m["speed_events"]]
    mean_speed = sum(sp) / len(sp)
    tiers = [i["tier"] for i in m.get("instances", [])]
    tier_mean = sum(tiers) / len(tiers) if tiers else 1.0
    s = 0.45 * min(ev / 1.1, 1) + 0.30 * min(max(mean_speed - 8.4, 0) / 7.2, 1) + 0.25 * (tier_mean - 1) / 4.0
    if m.get("mode") == "music_dash" and m.get("notes"):
        s += 0.05
    return round(10 * max(0.0, min(s, 1.0)), 2)


# ------------------------------------------------------------------ gameplay (simulacao)
def test_gameplay(m, out, beam=1200, level=None):
    res_info = {}
    if m.get("mode") in ("geometry_run", "music_dash", "endless"):
        L = level or Level(m)
        r = search(L, beam=beam)
        res_info = r.as_dict()
        if r.ok:
            out.append(_t("G1", "gameplay", "simulacao fisica: existe trajetoria que conclui a fase", "pass",
                          "30Hz de entrada, frontier max=%d%s" % (r.max_frontier, " (beam truncado, caminho encontrado e real)" if r.truncated else ""), [], "real"))
        elif r.truncated:
            out.append(_t("G1", "gameplay", "simulacao fisica: existe trajetoria que conclui a fase", "unverified",
                          "busca truncada e sem caminho ate t=%.2fs: nao e possivel afirmar impossibilidade" % r.t_fail, [], "real"))
            out[-1]["t_fail"] = r.t_fail
        else:
            out.append(_t("G1", "gameplay", "simulacao fisica: existe trajetoria que conclui a fase", "fail",
                          "nenhuma trajetoria passa de t=%.2fs (busca exaustiva)" % r.t_fail, [], "real"))
            out[-1]["t_fail"] = r.t_fail
    return res_info


def validate(m, beam=1200, level=None):
    d = diff_of(m)
    tests = []
    test_structure(m, tests)
    if any(t["status"] == "fail" and t["id"] in ("S1",) for t in tests):
        return _final(m, tests, {}, d)
    test_collision(m, tests)
    test_timing(m, tests, d)
    test_notes(m, tests, d)
    test_progression(m, tests, d)
    est = estimate_difficulty(m, d)
    lo, hi = d["band"]
    st = "pass" if lo <= est <= hi else "warn"
    tests.append(_t("D1", "dificuldade", "dificuldade estimada (heuristica) dentro da faixa da dificuldade escolhida", st,
                    "estimada=%.1f faixa=[%.1f, %.1f]" % (est, lo, hi), [], "heuristic"))
    structural_fail = [t for t in tests if t["status"] == "fail"]
    sim = {}
    if not structural_fail or True:
        sim = test_gameplay(m, tests, beam, level)
    return _final(m, tests, sim, d, est)


def _final(m, tests, sim, d, est=None):
    fails = [t for t in tests if t["status"] == "fail"]
    unv = [t for t in tests if t["status"] == "unverified"]
    warns = [t for t in tests if t["status"] == "warn"]
    if fails:
        result, status = "Reprovada", "FAILED"
    elif unv:
        result, status = "Nao verificada", "UNVERIFIED"
    elif warns:
        result, status = "Aprovada com avisos", "READY"
    else:
        result, status = "Aprovada", "READY"
    struct = [t for t in tests if t["category"] in ("estrutura",)]
    levels = {
        "tecnicamente_valida": all(t["status"] == "pass" for t in struct),
        "funcional": not any(t["id"] in ("G1", "N6") and t["status"] != "pass" for t in tests),
        "testada": not unv and not any(t["status"] == "fail" for t in tests if t["category"] == "estrutura"),
        "aprovada_para_entrega": status == "READY",
    }
    return {"status": status, "result": result, "tests": tests, "sim": sim, "levels": levels,
            "counts": {"total": len(tests), "pass": sum(t["status"] == "pass" for t in tests), "warn": len(warns), "fail": len(fails), "unverified": len(unv)},
            "difficulty_estimate": est}
