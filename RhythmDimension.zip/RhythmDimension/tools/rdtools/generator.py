"""Gerador procedural de fases a partir de analise musical, padroes proprios, seed e dificuldade.
Espelha scripts/generation/level_generator.gd. Nada aqui copia fases comerciais: os padroes sao abstracoes proprias
(patterns.json) combinadas e variadas (espacamento, ancora na musica, formas, transicoes) a cada seed."""
import math
from .common import PHYS, PATTERNS, GENERATOR_VERSION, difficulty, speed_value
from .rng import Rng
from .level import Timeline

CEIL = PHYS["ceiling_y"]
STYLES = ["balanced", "obstacles", "notes", "speed", "precision", "variations", "random"]
SILENCE = 0.05


# ------------------------------------------------------------------ utilidades de analise
def energy_at(an, t):
    be = an["bar_energy"]
    if not be:
        return 0.5
    k = int((t - an["offset"]) // an["bar_len"])
    k = min(max(k, 0), len(be) - 1)
    return be[k]


def onset_near(an, t, tol=0.05):
    ot = an.get("_onset_t")
    if ot is None:
        ot = an["_onset_t"] = [o["t"] for o in an["onsets"]]
    import bisect
    i = bisect.bisect_left(ot, t - tol)
    best = 0.0
    while i < len(ot) and ot[i] <= t + tol:
        best = max(best, an["onsets"][i]["s"])
        i += 1
    return best


def trim_analysis(an, a, b):
    """Recorta a analise para [a,b] e reancora todos os tempos em 0 (inicio da reproducao)."""
    beat = 60.0 / an["bpm"]
    new_off = (an["offset"] - a) % beat
    n_b = int((b - a - new_off) // (4 * beat)) + 1
    bars = [energy_at(an, a + new_off + (k + 0.5) * 4 * beat) for k in range(max(n_b, 1))]
    return {
        "bpm": an["bpm"], "offset": new_off, "duration": b - a, "bar_len": 4 * beat, "bar_energy": bars,
        "onsets": [dict(o, t=round(o["t"] - a, 4)) for o in an["onsets"] if a <= o["t"] <= b],
        "confidence": an.get("confidence", 0.0), "audio_start": a,
    }


def synthetic_analysis(bpm, bars, energy_fn=None, offset=0.0):
    beat = 60.0 / bpm
    be = [energy_fn(k) if energy_fn else 0.8 for k in range(bars)]
    ons = []
    for q in range(bars * 4):
        ons.append({"t": round(offset + q * beat, 4), "s": 1.5 if q % 4 == 0 else 1.0, "b": 0})
    return {"bpm": bpm, "offset": offset, "duration": offset + bars * 4 * beat + 1.0, "bar_len": 4 * beat,
            "bar_energy": be, "onsets": ons, "confidence": 1.0}


# ------------------------------------------------------------------ geracao geometrica
def _weights(p, style, dd, rng):
    w = p.get("weight", 1.0)
    k = p["kind"]
    if style == "variations" and k != "static":
        w *= 1.6
    if style == "precision" and p["id"] in ("Pattern_Platform_08", "Pattern_Stair_05", "Pattern_SpikeBlock_06", "Pattern_Block_03"):
        w *= 1.8
    if style == "obstacles" and k == "static":
        w *= 1.2
    if p["tier"] == dd["tier"] and p["tier"] >= 2:
        w *= 1.8          # favorece padroes do nivel da dificuldade (nao subir so por velocidade)
    elif p["tier"] < dd["tier"] - 1:
        w *= 0.5
    if style == "random":
        w *= 0.4 + 1.2 * rng.f()
    return w


class _Gen:
    """Estado de uma geracao geometrica."""

    def __init__(self, an, diff, style, seed, ramp, pattern_ok, lane_bars, blocked):
        self.an, self.diff, self.style, self.seed = an, diff, style, seed
        self.ramp, self.pattern_ok = ramp, pattern_ok
        self.rng = Rng(seed)
        self.beat = 60.0 / an["bpm"]
        self.bar_len = 4 * self.beat
        self.off = an["offset"]
        self.lane_bars = set(lane_bars or [])
        self.blocked = set(blocked or [])
        self.objs, self.fev, self.insts = [], [{"t": 0.0, "form": "cube", "gs": 1, "ceiling": False}], []
        self.tl = None

    def grid(self, b):
        return self.off + b * self.beat

    def dd(self, bar):
        if self.ramp:
            name = self.ramp(bar)[0]
            d = difficulty(name)
            return d
        return self.diff

    def speed_for_bar(self, bar):
        d = self.dd(bar)
        sv = speed_value(d)
        if self.ramp:
            sv *= self.ramp(bar)[1]
        if self.style == "speed":
            sv *= 1.08
        return sv


def _plan_speed(g, first_bar, last_bar):
    """Perfil de velocidade: constante, zonas rapidas (hard+/estilo velocidade) ou rampa (endless)."""
    ev = []
    cur = None
    zone_mult = {}
    d0 = g.diff
    if not g.ramp and (d0["tier"] >= 3 or (d0["tier"] == 2 and g.style == "speed")):
        b = first_bar + 2
        while b < last_bar - 6:
            if energy_at(g.an, g.grid(b * 4) + g.bar_len / 2) >= 0.8:
                n = 0
                while b + n < last_bar - 2 and energy_at(g.an, g.grid((b + n) * 4) + g.bar_len / 2) >= 0.8:
                    n += 1
                if n >= 4 and g.rng.f() < (0.55 if d0["tier"] >= 3 else 0.3):
                    for k in range(n):
                        zone_mult[b + k] = 1.2
                    b += n + 1
                    continue
                b += max(n, 1)
            else:
                b += 1
    for b in range(0, last_bar + 2):
        sv = g.speed_for_bar(b) * zone_mult.get(b, 1.0)
        sv = round(sv, 3)
        if cur is None:
            ev.append({"t": 0.0, "speed": sv})
            cur = sv
        elif abs(sv - cur) > 1e-6:
            ev.append({"t": round(g.grid(b * 4), 4), "speed": sv, "portal": True})
            cur = sv
    return ev


def _obj(g, typ, x, y, inst, **kw):
    o = {"type": typ, "x": round(x, 3), "y": y, "inst": inst}
    o.update(kw)
    return o


def _pattern_min_gap_beats(p):
    bs = sorted(set(o["beat"] for o in p.get("objects", [])))
    gaps = [b2 - b1 for b1, b2 in zip(bs, bs[1:])]
    return min(gaps) if gaps else None


def _inst_static(g, p, anchor, dd, k):
    beat, tl, rng = g.beat, g.tl, g.rng
    objs = p["objects"]
    stretch = 1.0
    mg = _pattern_min_gap_beats(p)
    if mg:
        stretch = max(1.0, dd["min_gap_s"] / (mg * beat))
        if dd["tier"] >= 2 and rng.f() < 0.35:
            stretch = max(stretch, 1.25)

    def sb(x):
        return math.ceil(x * stretch * 4 - 1e-9) / 4

    out = []
    t_end = 0.0
    for o in objs:
        t = g.grid(anchor + sb(o["beat"]))
        x = tl.x_at(t) + o["dx"]
        if o["type"] == "spike":
            out.append(_obj(g, "spike", x, o.get("y", 0), k))
            w = 1
        else:
            out.append(_obj(g, "block", x, o.get("y", 0), k, w=o["w"], h=o["h"]))
            w = o["w"]
        t_end = max(t_end, tl.t_at(x + w))
    return out, [], g.grid(anchor), t_end


def _corridor(g, p, anchor, dd, k, wave):
    beat, tl, rng = g.beat, g.tl, g.rng
    par = p["params"]
    nb = rng.rng_i(par["beats"][0], par["beats"][1])
    nb = max(4, (nb // 2) * 2)
    t_in, t_out = g.grid(anchor), g.grid(anchor + nb)
    gap_i = int(math.ceil(dd["ship_gap"]))
    if wave:
        gap_i = max(gap_i, 4)
    amp = par["amp"] * (0.6 if dd["tier"] <= 1 else 1.0 if dd["tier"] <= 3 else 1.15)
    period = par["period_beats"] * beat
    W = 1.0 if wave else 2.0
    x0, x1 = tl.x_at(t_in + 1.5 * beat), tl.x_at(t_out - 1.0 * beat)
    out = []
    x = x0
    t_c0 = t_in + 1.5 * beat
    t_c1 = t_out - 1.0 * beat
    while x < x1:
        t = tl.t_at(x)
        ramp = min(1.0, (t - t_c0) / (2 * beat)) * min(1.0, (t_c1 - t) / (2 * beat))
        ramp = max(ramp, 0.0)
        ph = (t - t_c0) / period
        if wave:
            tri = abs(2.0 * (ph - math.floor(ph + 0.5)))   # onda triangular 0..1
            c = gap_i / 2.0 + amp * tri * ramp
        else:
            c = gap_i / 2.0 + amp * (1 - math.cos(2 * math.pi * ph)) / 2.0 * ramp
        hf = int(math.floor(c - gap_i / 2.0 + 0.5))
        hf = max(0, min(hf, int(CEIL) - gap_i - 1))
        top = hf + gap_i
        if hf >= 1:
            out.append(_obj(g, "block", x, 0, k, w=W, h=hf))
        if CEIL - top >= 1:
            out.append(_obj(g, "block", x, top, k, w=W, h=CEIL - top))
        x += W
    form = "wave" if wave else "ship"
    fe = [{"t": round(t_in, 4), "form": form, "gs": 1, "ceiling": True, "portal": True, "inst": k},
          {"t": round(t_out, 4), "form": "cube", "gs": 1, "ceiling": False, "portal": True, "inst": k}]
    return out, fe, t_in, t_out + 0.45


def _flips(g, p, anchor, dd, k, spider):
    beat, tl, rng = g.beat, g.tl, g.rng
    par = p["params"]
    n = rng.rng_i(par["count"][0], par["count"][1])
    sp_b = rng.rng_f(par["spacing_beats"][0], par["spacing_beats"][1])
    t_in = g.grid(anchor)
    v = tl.speed_at(t_in)
    min_blocks = 4.0 if spider else 7.0
    need_beats = (min_blocks / v) / beat
    need_gap_b = dd["min_gap_s"] / beat
    sp_b = math.ceil(max(sp_b, need_beats, need_gap_b) * 2) / 2.0
    out = []
    t = t_in + sp_b * beat
    for j in range(n):
        x = tl.x_at(t)
        if j % 2 == 0:
            out.append(_obj(g, "spike", x, 0, k))
        else:
            out.append(_obj(g, "spike", x, int(CEIL) - 1, k, flip=True))
        t += sp_b * beat
    t_out = t
    form = "spider" if spider else "ball"
    fe = [{"t": round(t_in, 4), "form": form, "gs": 1, "ceiling": True, "portal": True, "inst": k},
          {"t": round(t_out, 4), "form": "cube", "gs": 1, "ceiling": False, "portal": True, "inst": k}]
    return out, fe, t_in, t_out + 0.5


def _robot(g, p, anchor, dd, k):
    beat, tl, rng = g.beat, g.tl, g.rng
    par = p["params"]
    n = rng.rng_i(par["count"][0], par["count"][1])
    sp_b = rng.rng_f(par["spacing_beats"][0], par["spacing_beats"][1])
    sp_b = math.ceil(max(sp_b, dd["min_gap_s"] / beat) * 2) / 2.0
    t_in = g.grid(anchor)
    out = []
    t = t_in + sp_b * beat
    for j in range(n):
        x = tl.x_at(t)
        out.append(_obj(g, "block", x, 0, k, w=1, h=2))
        t += sp_b * beat
    fe = [{"t": round(t_in, 4), "form": "robot", "gs": 1, "ceiling": False, "portal": True, "inst": k},
          {"t": round(t + 0.3, 4), "form": "cube", "gs": 1, "ceiling": False, "portal": True, "inst": k}]
    return out, fe, t_in, t + 0.8


def _finale(g, p, anchor, dd, k):
    beat, tl, rng = g.beat, g.tl, g.rng
    n = rng.rng_i(p["params"]["hops"][0], p["params"]["hops"][1])
    n = min(n + (dd["tier"] - 1) // 2, 6)
    sp = 2.0
    b = anchor
    out = []
    t_end = 0.0
    for j in range(n):
        x = tl.x_at(g.grid(b))
        if j == n - 1 and dd["tier"] >= 2:
            for dx in range(3):
                out.append(_obj(g, "spike", x + dx, 0, k))
            t_end = tl.t_at(x + 3)
        else:
            out.append(_obj(g, "spike", x, 0, k))
            t_end = tl.t_at(x + 1)
        floor_b = max(1.0, math.ceil(dd["min_gap_s"] / beat * 4) / 4.0)
        sp = max(floor_b, sp - 0.25)
        b += sp
    return out, [], g.grid(anchor), t_end


def _instantiate(g, p, anchor, dd, k):
    kind = p["kind"]
    if kind == "static":
        return _inst_static(g, p, anchor, dd, k)
    if kind == "corridor_ship":
        return _corridor(g, p, anchor, dd, k, False)
    if kind == "corridor_wave":
        return _corridor(g, p, anchor, dd, k, True)
    if kind == "flip_ball":
        return _flips(g, p, anchor, dd, k, False)
    if kind == "flip_spider":
        return _flips(g, p, anchor, dd, k, True)
    if kind == "robot_blocks":
        return _robot(g, p, anchor, dd, k)
    if kind == "finale":
        return _finale(g, p, anchor, dd, k)
    return None


def _eligible(g, dd, tier_cap, allow_forms, bpm, spd_name):
    res = []
    for p in PATTERNS:
        if p["mode"] != "geometry_run":
            continue
        if p["tier"] > tier_cap or p["kind"] == "finale":
            continue
        if p["form"] != "cube" and (not allow_forms or p["form"] not in dd["forms"]):
            continue
        if p["kind"] == "static" and p["tier"] > dd["tier"]:
            continue
        if g.pattern_ok is not None and not g.pattern_ok(p["id"], bpm, spd_name):
            continue
        res.append(p)
    return res


def generate_geometry(an, diff, style="balanced", seed=1, name=None, ramp=None, pattern_ok=None,
                      lane_bars=None, blocked_bars=None, allow_forms=True, mode="geometry_run", level_id=None):
    g = _Gen(an, diff, style, seed, ramp, pattern_ok, lane_bars, blocked_bars)
    beat, bar_len, off = g.beat, g.bar_len, g.off
    end_t = an["duration"] - 0.4
    n_full = int((end_t - off) // bar_len)
    first_bar = max(0, int(math.ceil((diff["lead_in_s"] - off) / bar_len)))
    last_bar = n_full - 1
    z = last_bar - 1                       # ultimo compasso com perigos (o ultimo fica livre)
    sev = _plan_speed(g, first_bar, last_bar)
    g.tl = Timeline(sev)
    if g.style == "speed" and not ramp:
        pass
    rng = g.rng
    last_end = 0.0
    last_form_bar = -99
    n_active = max(z - first_bar + 1, 1)
    finale_done = False
    insts = g.insts
    lane_starts = sorted(g.grid(a * 4) for a, c in _runs(sorted(g.lane_bars)))
    for b in range(first_bar, z + 1):
        if b in g.blocked or b in g.lane_bars:
            continue
        dd = g.dd(b)
        t_bar = g.grid(b * 4)
        I = energy_at(an, t_bar + bar_len / 2)
        if I < SILENCE:
            continue
        prog = (b - first_bar) / n_active
        intro = prog < 0.10
        is_finale = (b >= z - 1) and not ramp and n_active >= 8
        tier_cap = 1 if intro else dd["tier"]
        pd = dd["density"] * (0.35 + 0.9 * I)
        if g.style == "obstacles":
            pd *= 1.2
        if g.style == "random":
            pd *= 0.75 + 0.5 * rng.f()
        if intro:
            pd *= 0.5
        pd = min(pd, 0.97)
        if is_finale and not finale_done:
            pd = 1.0
        if rng.f() > pd:
            continue
        spd_name = dd["name"]
        bpm = an["bpm"]
        cands = []
        if is_finale and not finale_done:
            cands = [p for p in PATTERNS if p["kind"] == "finale"]
        else:
            cands = _eligible(g, dd, tier_cap, allow_forms and not intro, bpm, spd_name)
            # formas especiais so em trechos de maior energia e com cooldown
            keep = []
            for p in cands:
                if p["form"] != "cube":
                    if I < 0.45 or (b - last_form_bar) < 3 or b > z - 3:
                        continue
                keep.append(p)
            cands = keep
        if not cands:
            continue
        ws = []
        for p in cands:
            w = _weights(p, g.style, dd, rng)
            if p["form"] != "cube":
                w *= 0.55 if g.style != "variations" else 1.2
            ws.append(w)
        p = rng.weighted(cands, ws)
        # ancoras possiveis dentro do compasso (preferindo batidas fortes na musica)
        earliest = last_end + dd["min_gap_s"]
        if last_form_bar == b - 1 or (insts and insts[-1]["form"] != "cube" and g.grid(b * 4) - last_end < 0.2):
            earliest += 0.3
        steps = [0, 1, 2, 3] + ([0.5, 1.5, 2.5, 3.5] if dd["tier"] >= 3 else [])
        opts, wts = [], []
        len_s = p["length_beats"] * beat
        for q in steps:
            tq = g.grid(b * 4 + q)
            if tq < earliest or tq + len_s > end_t - 1.2:
                continue
            nb = int((tq - off) // bar_len)
            if (nb + 1) in g.lane_bars or (b + 1) in g.lane_bars and q >= 3:
                continue
            opts.append(q)
            wts.append(0.15 + onset_near(an, tq, 0.06))
        if not opts:
            continue
        q = rng.weighted(opts, wts)
        anchor = b * 4 + q
        k = len(insts)
        res = _instantiate(g, p, anchor, dd, k)
        if res is None:
            continue
        objs, fe, t0, t1 = res
        if t1 > end_t - 1.1:       # folga final minima (validador T4 exige >= 1.0 s)
            continue
        if any(t0 < ls < t1 + 0.5 for ls in lane_starts):
            continue          # cauda do padrao invadiria o trecho de notas do Music Dash
        g.objs.extend(objs)
        g.fev.extend(fe)
        insts.append({"k": k, "pattern": p["id"], "kind": p["kind"], "form": p["form"], "t0": round(t0, 3), "t1": round(t1, 3),
                      "bar": b, "tier": p["tier"], "anchor": anchor, "fixed": False})
        last_end = t1
        if p["form"] != "cube":
            last_form_bar = b
        if p["kind"] == "finale":
            finale_done = True
    # trechos de notas do Music Dash (portais de entrada/saida)
    lane_runs = _runs(sorted(g.lane_bars))
    for (a, c) in lane_runs:
        t_a = g.grid(a * 4)
        t_c = g.grid((c + 1) * 4)
        g.fev.append({"t": round(t_a, 4), "form": "lanes", "gs": 1, "ceiling": False, "portal": True, "lanes": True})
        g.fev.append({"t": round(t_c, 4), "form": "cube", "gs": 1, "ceiling": False, "portal": True})
    g.fev.sort(key=lambda e: e["t"])
    g.objs.sort(key=lambda o: o["x"])
    m = {
        "format": 1, "id": level_id or f"gen_{an['bpm']:.0f}_{style}_{seed}", "name": name or "Fase gerada", "mode": mode,
        "difficulty": diff["name"], "style": style, "seed": seed, "generator_version": GENERATOR_VERSION,
        "audio": {"bpm": an["bpm"], "offset": round(an["offset"], 4), "duration": round(an["duration"], 3),
                  "start": an.get("audio_start", 0.0), "confidence": an.get("confidence", 0.0)},
        "speed_events": sev, "form_events": g.fev, "objects": g.objs, "notes": [], "lanes": 0, "instances": insts,
        "end_t": round(end_t, 3), "status": "GENERATING",
    }
    m["checkpoints"] = _checkpoints(m, g)
    return m


def _runs(bars):
    runs = []
    for b in bars:
        if runs and b == runs[-1][1] + 1:
            runs[-1][1] = b
        else:
            runs.append([b, b])
    return [(a, c) for a, c in runs]


def _checkpoints(m, g):
    haz = sorted(inst["t0"] for inst in m["instances"])
    cps = []
    last = 0.0
    bar_len = g.bar_len
    b = 1
    while g.grid(b * 4) < m["end_t"] - 3:
        t = g.grid(b * 4)
        near = [h for h in m["instances"] if h["t0"] - 1.0 <= t <= h["t1"] + 1.0]
        if not near and t - last >= 8.0:
            cps.append(round(t, 3))
            last = t
        b += 1
    return cps


# ------------------------------------------------------------------ geracao de notas (Magic Rhythm / lanes do Music Dash)
def _band_near(an, t, tol=0.06):
    import bisect
    ot = an.get("_onset_t")
    if ot is None:
        ot = an["_onset_t"] = [o["t"] for o in an["onsets"]]
    i = bisect.bisect_left(ot, t - tol)
    best, band = -1.0, 1
    while i < len(ot) and ot[i] <= t + tol:
        if an["onsets"][i]["s"] > best:
            best, band = an["onsets"][i]["s"], an["onsets"][i]["b"]
        i += 1
    return band


def generate_notes(an, diff, style="balanced", seed=1, lanes=None, name=None, bars_only=None, kinds=None,
                   nps_scale=1.0, level_id=None, mode="magic_rhythm", as_part=False):
    rng = Rng((seed ^ 0x5BD1E995) & 0xFFFFFFFF)
    nd = diff["notes"]
    if lanes is None:
        lanes = nd["lanes"][len(nd["lanes"]) // 2]
    lanes = max(3, min(6, int(lanes))) if mode != "music_dash" else 3
    beat = 60.0 / an["bpm"]
    bar_len = 4 * beat
    off = an["offset"]
    end_t = an["duration"] - 0.4
    first_t = diff["lead_in_s"]
    kinds = list(kinds or nd["kinds"])
    tier = diff["tier"]
    cap = nd["max_nps"] * 0.88 * nps_scale
    if style == "notes":
        cap *= 1.12
    lane_gap = nd["lane_gap_s"]
    subs = {1: [0.0], 2: [0.0, 0.5], 3: [0.0, 0.5], 4: [0.0, 0.25, 0.5, 0.75], 5: [0.0, 0.25, 0.5, 0.75]}[min(tier, 5)]
    if tier == 1 and diff.get("name") == "beginner":
        subs = [0.0, 0.5]
    notes = []
    recent = []
    lane_last = {}
    hold_busy = {}          # lane -> t ate quando ocupada
    last_lane = lanes // 2
    n_beats = int((end_t - 1.0 - off) // beat)
    thr_shift = (-0.15 if style == "notes" else 0.0) - 0.12 * max(tier - 2, 0)
    bi = 0
    while bi < n_beats:
        t_beat = off + bi * beat
        bar = bi // 4
        if t_beat < first_t - 0.01 or (bars_only is not None and bar not in bars_only):
            bi += 1
            continue
        I = energy_at(an, t_beat)
        if I < SILENCE:
            bi += 1
            continue
        for s in subs:
            t = t_beat + s * beat
            if t < first_t or t > end_t - 1.0:
                continue
            st = onset_near(an, t, 0.05)
            score = st + (0.5 if s == 0 else 0.0) + (0.2 if s == 0.5 else 0.0)
            thr = 1.55 - 1.0 * I + thr_shift
            if s == 0 and bi % 4 == 0:
                thr -= 0.25
            if s == 0.25 or s == 0.75:
                thr += 0.4 if tier < 4 else 0.12
            if score < thr:
                continue
            win = [x for x in recent if t - x <= 1.0 + 1e-9]
            if len(win) + 1 > cap + 1e-9:
                continue
            busy = [ln for ln, tt in hold_busy.items() if tt > t - 0.02]
            band = _band_near(an, t)
            # regiao de lanes por banda
            third = max(lanes // 3, 1)
            region = list(range(0, third)) if band == 0 else list(range(lanes - third, lanes)) if band == 2 else list(range(third, lanes - third + (1 if lanes % 3 else 0)))
            if not region:
                region = list(range(lanes))
            free = [ln for ln in region if ln not in busy and t - lane_last.get(ln, -9) >= lane_gap and ln != last_lane]
            if not free:
                free = [ln for ln in range(lanes) if ln not in busy and t - lane_last.get(ln, -9) >= lane_gap and ln != last_lane]
            if not free:
                continue
            lane = rng.pick(free)
            kind = "tap"
            dur = 0.0
            lane_to = None
            r = rng.f()
            nbusy = len(busy)
            recent_hold = any(t - tt < 0.25 for tt in hold_busy.values())
            if nbusy == 0 and s == 0 and "hold" in kinds and r < nd["hold_ratio"] and I < 0.9 and bi % 2 == 0 and st >= 0.6:
                nbeats_h = 2.0 if rng.f() < 0.5 else 1.0
                dur = nbeats_h * beat - 0.08
                kind = "hold"
            elif nbusy == 0 and s == 0 and "slide" in kinds and r < nd["hold_ratio"] + 0.12 and I < 0.9 and bi % 2 == 0 and st >= 0.6:
                nbrs = [ln for ln in (lane - 1, lane + 1) if 0 <= ln < lanes and t - lane_last.get(ln, -9) >= lane_gap]
                if nbrs:
                    lane_to = rng.pick(nbrs)
                    dur = beat - 0.08
                    kind = "slide"
            elif nbusy == 0 and not recent_hold and s == 0 and "double" in kinds and st >= 1.2 and bi % 2 == 0 and rng.f() < 0.35 and lanes >= 3 and len(win) + 2 <= cap + 1e-9:
                cands = [ln for ln in range(lanes) if abs(ln - lane) >= 2 and ln not in busy and t - lane_last.get(ln, -9) >= lane_gap]
                if cands:
                    l2 = rng.pick(cands)
                    notes.append({"t": round(t, 4), "lane": lane, "kind": "double", "dur": 0.0})
                    notes.append({"t": round(t, 4), "lane": l2, "kind": "double", "dur": 0.0})
                    lane_last[lane] = lane_last[l2] = t
                    recent.extend([t, t])
                    last_lane = lane
                    continue
            elif nbusy == 0 and "special" in kinds and st >= 1.3 and s == 0 and rng.f() < 0.10:
                kind = "special"
            elif "fast" in kinds and I >= 0.75 and s == 0 and bi % 4 == 0 and rng.f() < 0.35 and tier >= 3 and nbusy == 0 \
                    and (beat / 4) * 3 >= lane_gap and cap >= 4 / 1.0 * 1.0 and (len(win) + 4) <= cap + 0.01:
                cyc = rng.pick([[0, 1, 2], [2, 1, 0]]) if lanes >= 3 else [0, 1]
                base = rng.rng_i(0, lanes - 3)
                seq = [base + cyc[j % 3] for j in range(4)]
                ok = all(t + j * beat / 4 - lane_last.get(seq[j], -9) >= lane_gap for j in range(4))
                if ok and t + 4 * beat / 4 < end_t - 1.0:
                    for j in range(4):
                        tj = t + j * beat / 4
                        notes.append({"t": round(tj, 4), "lane": seq[j], "kind": "fast", "dur": 0.0})
                        lane_last[seq[j]] = tj
                        recent.append(tj)
                    last_lane = seq[-1]
                    continue
            n = {"t": round(t, 4), "lane": lane, "kind": kind, "dur": round(dur, 4)}
            if lane_to is not None:
                n["lane_to"] = lane_to
                hold_busy[lane_to] = t + dur
                lane_last[lane_to] = t + dur
            if dur > 0:
                hold_busy[lane] = t + dur
            notes.append(n)
            lane_last[lane] = t + dur
            recent.append(t)
            last_lane = lane
        bi += 1
    notes.sort(key=lambda n: (n["t"], n["lane"]))
    m = {
        "format": 1, "id": level_id or f"gen_{an['bpm']:.0f}_{mode}_{style}_{seed}", "name": name or "Fase gerada", "mode": mode,
        "difficulty": diff["name"], "style": style, "seed": seed, "generator_version": GENERATOR_VERSION,
        "audio": {"bpm": an["bpm"], "offset": round(an["offset"], 4), "duration": round(an["duration"], 3),
                  "start": an.get("audio_start", 0.0), "confidence": an.get("confidence", 0.0)},
        "speed_events": [{"t": 0.0, "speed": speed_value(diff)}], "form_events": [], "objects": [], "notes": notes,
        "lanes": lanes, "instances": [], "end_t": round(end_t, 3), "status": "GENERATING",
    }
    return m


# ------------------------------------------------------------------ Music Dash (hibrido)
def generate_dash(an, diff, style="balanced", seed=1, name=None, pattern_ok=None, level_id=None):
    rng = Rng((seed ^ 0xA5A5A5) & 0xFFFFFFFF)
    beat = 60.0 / an["bpm"]
    bar_len = 4 * beat
    off = an["offset"]
    end_t = an["duration"] - 0.4
    n_full = int((end_t - off) // bar_len)
    first_bar = max(0, int(math.ceil((diff["lead_in_s"] - off) / bar_len)))
    z = n_full - 2
    lane_bars = []
    pos = first_bar + rng.rng_i(3, 5)          # primeira corrida de 3 a 5 compassos
    while True:
        room = z - 4 - pos + 1                 # reserva 4 compassos finais para a corrida final (final + pista livre)
        if room < 3:
            break
        ln = min(rng.rng_i(4, 6), room)
        if energy_at(an, off + (pos + ln / 2) * bar_len) >= 0.15:
            lane_bars.extend(range(pos, pos + ln))
        pos += ln + rng.rng_i(3, 5)
    blocked = set()
    for (a, c) in _runs(sorted(lane_bars)):
        blocked.add(a - 1)      # compasso antes: pista livre para a transicao
        blocked.add(c + 1)      # compasso depois: pista livre
    m = generate_geometry(an, diff, style, seed, name, None, pattern_ok, lane_bars, blocked, True, "music_dash", level_id)
    ln = generate_notes(an, diff, style, seed, 3, None, set(lane_bars), ["tap", "hold", "double"], 0.8, None, "music_dash")
    m["notes"] = ln["notes"]
    m["lanes"] = 3
    m["lane_bars"] = sorted(lane_bars)
    m["lane_segments"] = [{"t0": round(off + a * bar_len, 4), "t1": round(off + (c + 1) * bar_len, 4)} for a, c in _runs(sorted(lane_bars))]
    return m


# ------------------------------------------------------------------ Endless
ENDLESS_TIERS = ["beginner", "normal", "hard", "expert", "insane"]


def endless_ramp(bar):
    ti = min(len(ENDLESS_TIERS) - 1, bar // 24)
    return ENDLESS_TIERS[ti], min(1.0 + 0.012 * (bar // 8), 1.25)


def generate_endless(chunks, seed=1, bpm=128, pattern_ok=None, level_id=None):
    bars = chunks * 8 + 6
    an = synthetic_analysis(bpm, bars, lambda k: min(1.0, 0.6 + 0.4 * min(k, 24) / 24.0), offset=0.0)
    an["duration"] = bars * 4 * 60.0 / bpm + 0.4
    base = difficulty("beginner")
    base["lead_in_s"] = 3.0
    m = generate_geometry(an, base, "balanced", seed, "Endless Rhythm", endless_ramp, pattern_ok, None, None, True, "endless_rhythm", level_id)
    m["mode"] = "endless"
    m["difficulty"] = "endless"
    m["tier_by_bar"] = [endless_ramp(b)[0] for b in range(bars)]   # dificuldade vigente por compasso (rampa)
    return m


# ------------------------------------------------------------------ entrada principal
def generate(an, mode, diff_name, style="balanced", seed=1, custom=None, lanes=None, trim=None, pattern_ok=None,
             name=None, level_id=None):
    diff = difficulty(diff_name, custom)
    if trim:
        an = trim_analysis(an, trim[0], trim[1])
    if mode == "geometry_run":
        return generate_geometry(an, diff, style, seed, name, None, pattern_ok, None, None, True, "geometry_run", level_id)
    if mode == "magic_rhythm":
        return generate_notes(an, diff, style, seed, lanes, name, None, None, 1.0, level_id)
    if mode == "music_dash":
        return generate_dash(an, diff, style, seed, name, pattern_ok, level_id)
    raise ValueError("modo desconhecido: " + mode)
