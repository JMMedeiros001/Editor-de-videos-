"""Sintetizador de musicas ORIGINAIS (sem direitos autorais) com BPM conhecido (verdade-de-chao para testes)."""
import math
import os
import subprocess
import numpy as np
from scipy.io import wavfile

SR_OUT = 44100


def _env(n, a, d):
    t = np.arange(n) / SR_OUT
    return np.exp(-t / d) * np.minimum(1.0, t / a)


def kick(rng):
    n = int(0.28 * SR_OUT)
    t = np.arange(n) / SR_OUT
    f = 45 + 110 * np.exp(-t * 28)
    ph = 2 * np.pi * np.cumsum(f) / SR_OUT
    return np.sin(ph) * np.exp(-t * 11) * 1.0


def snare(rng):
    n = int(0.22 * SR_OUT)
    t = np.arange(n) / SR_OUT
    noise = rng.standard_normal(n)
    from scipy.signal import butter, lfilter
    b, a = butter(2, [1200 / (SR_OUT / 2), 6500 / (SR_OUT / 2)], "band")
    nz = lfilter(b, a, noise) * np.exp(-t * 18)
    tone = np.sin(2 * np.pi * 190 * t) * np.exp(-t * 25) * 0.5
    return (nz * 0.9 + tone) * 0.8


def hat(rng, open_=False):
    n = int((0.22 if open_ else 0.06) * SR_OUT)
    t = np.arange(n) / SR_OUT
    from scipy.signal import butter, lfilter
    b, a = butter(2, 7000 / (SR_OUT / 2), "high")
    return lfilter(b, a, rng.standard_normal(n)) * np.exp(-t * (14 if open_ else 70)) * 0.28


def note(freq, dur, kind="saw", amp=0.2):
    n = int(dur * SR_OUT)
    t = np.arange(n) / SR_OUT
    if kind == "saw":
        w = 2 * ((t * freq) % 1.0) - 1
    elif kind == "square":
        w = np.sign(np.sin(2 * np.pi * freq * t))
    else:
        w = np.sin(2 * np.pi * freq * t)
    from scipy.signal import butter, lfilter
    b, a = butter(2, min(2600, freq * 6) / (SR_OUT / 2), "low")
    w = lfilter(b, a, w)
    return w * _env(n, 0.005, dur * 0.7) * amp


def mtof(m):
    return 440.0 * 2 ** ((m - 69) / 12)


def render(bpm, sections, offset=0.37, seed=1, root=45, scale=(0, 3, 5, 7, 10)):
    """sections: lista de (n_compassos, nivel) nivel em {0: calmo, 1: medio, 2: forte}."""
    rng = np.random.default_rng(seed)
    beat = 60.0 / bpm
    total_bars = sum(s[0] for s in sections)
    dur = offset + total_bars * 4 * beat + 1.5
    out = np.zeros(int(dur * SR_OUT) + SR_OUT)
    K, S, H, HO = kick(rng), snare(rng), hat(rng), hat(rng, True)

    def put(sig, t, g=1.0):
        i = int(round(t * SR_OUT))
        if i < 0 or i >= len(out):
            return
        j = min(len(out), i + len(sig))
        out[i:j] += sig[: j - i] * g

    bar = 0
    for (nb, lvl) in sections:
        for b in range(nb):
            t0 = offset + bar * 4 * beat
            deg = scale[(bar // 2) % len(scale)]
            for q in range(4):
                tb = t0 + q * beat
                if lvl >= 1:
                    put(K, tb, 1.0 if lvl == 2 else 0.8)
                elif q == 0:
                    put(K, tb, 0.6)
                if lvl >= 1 and q in (1, 3):
                    put(S, tb, 0.8 if lvl == 2 else 0.5)
                if lvl >= 1:
                    put(H, tb + beat / 2, 0.8)
                if lvl == 2:
                    put(H, tb, 0.5)
                    put(H, tb + beat / 4, 0.35)
                    put(H, tb + 3 * beat / 4, 0.35)
                    if q == 3:
                        put(HO, tb + beat / 2, 0.5)
                # baixo
                if lvl >= 1:
                    put(note(mtof(root + deg), beat * 0.45, "saw", 0.28), tb + beat / 2)
                    if q % 2 == 0:
                        put(note(mtof(root + deg), beat * 0.4, "saw", 0.3), tb)
                else:
                    if q == 0:
                        put(note(mtof(root + 12 + deg), beat * 3.6, "sine", 0.18), tb)
                # arpejo
                if lvl >= 1:
                    for e in range(2):
                        d2 = scale[(q * 2 + e + bar) % len(scale)]
                        put(note(mtof(root + 24 + d2), beat * 0.4, "square", 0.07 if lvl == 1 else 0.1), tb + e * beat / 2)
            bar += 1
    out = out[: int(dur * SR_OUT)]
    pk = np.max(np.abs(out)) + 1e-9
    out = out / pk * 0.89
    return out, dur


def write_wav(path, sig):
    wavfile.write(path, SR_OUT, (np.clip(sig, -1, 1) * 32767).astype(np.int16))


def to_ogg(wav, ogg, q=4):
    subprocess.run(["ffmpeg", "-v", "error", "-y", "-i", wav, "-c:a", "libvorbis", "-q:a", str(q), ogg], check=True)
