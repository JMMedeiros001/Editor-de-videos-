"""Modelo de fase (mapa) para geometria/fisica. Espelha scripts/core/rhythm_map.gd."""
import bisect
import math
from .common import PHYS

DT = PHYS["dt"]
BODY = PHYS["body"]
HURT = PHYS["hurt"]
SPW = PHYS["spike_w"]
SPH = PHYS["spike_h"]
CEIL = PHYS["ceiling_y"]


class Timeline:
    """Perfil de velocidade: converte tempo de audio em posicao horizontal (blocos) e vice-versa."""

    def __init__(self, speed_events):
        sp = sorted(speed_events or [{"t": 0.0, "speed": 10.4}], key=lambda e: e["t"])
        if sp[0]["t"] > 0:
            sp.insert(0, {"t": 0.0, "speed": sp[0]["speed"]})
        self.sp_t = [e["t"] for e in sp]
        self.sp_v = [e["speed"] for e in sp]
        self.sp_x = [0.0]
        for k in range(1, len(sp)):
            self.sp_x.append(self.sp_x[-1] + self.sp_v[k - 1] * (self.sp_t[k] - self.sp_t[k - 1]))

    def x_at(self, t):
        if t <= 0:
            return self.sp_v[0] * t
        k = bisect.bisect_right(self.sp_t, t) - 1
        return self.sp_x[k] + self.sp_v[k] * (t - self.sp_t[k])

    def t_at(self, x):
        k = max(bisect.bisect_right(self.sp_x, x) - 1, 0)
        return self.sp_t[k] + (x - self.sp_x[k]) / self.sp_v[k]

    def speed_at(self, t):
        k = max(bisect.bisect_right(self.sp_t, t) - 1, 0)
        return self.sp_v[k]


class Level(Timeline):
    def __init__(self, m):
        self.m = m
        Timeline.__init__(self, m.get("speed_events"))
        fe = sorted(m.get("form_events", []), key=lambda e: e["t"])
        if not fe or fe[0]["t"] > 0:
            fe.insert(0, {"t": 0.0, "form": "cube", "gs": 1, "ceiling": False})
        self.fe = fe
        self.fe_t = [e["t"] for e in fe]
        self.end_t = m["end_t"]
        self.end_x = self.x_at(self.end_t)
        self.solids = []   # (x0,y0,x1,y1)
        self.spikes = []   # (x0,y0,x1,y1) hitbox letal
        self.cols = {}
        self._index_objects()
        self.nsteps = int(math.ceil(self.end_t / DT)) + 2
        self._build_step_tables()

    def form_event_at(self, t):
        k = max(bisect.bisect_right(self.fe_t, t) - 1, 0)
        return self.fe[k]

    # ---- objetos
    def _index_objects(self):
        for o in self.m.get("objects", []):
            x = o["x"]
            y = o.get("y", 0)
            if o["type"] == "block":
                w = o.get("w", 1)
                h = o.get("h", 1)
                self.solids.append((x, y, x + w, y + h))
            elif o["type"] == "spike":
                cx = x + 0.5
                if o.get("flip"):
                    self.spikes.append((cx - SPW / 2, y + 1 - SPH, cx + SPW / 2, y + 1))
                else:
                    self.spikes.append((cx - SPW / 2, y, cx + SPW / 2, y + SPH))
        self.sol_cols = {}
        for idx, (x0, y0, x1, y1) in enumerate(self.solids):
            for c in range(int(math.floor(x0)) - 1, int(math.floor(x1)) + 1):
                self.sol_cols.setdefault(c, []).append(idx)
        self.spk_cols = {}
        for idx, (x0, y0, x1, y1) in enumerate(self.spikes):
            for c in range(int(math.floor(x0)) - 1, int(math.floor(x1)) + 1):
                self.spk_cols.setdefault(c, []).append(idx)

    def _build_step_tables(self):
        n = self.nsteps + 12     # margem: a busca avanca em blocos de decision_steps
        self.xs = [self.x_at(i * DT) for i in range(n)]
        self.form_at = []
        self.gs_event = []   # gs imposto pelo evento (ou None)
        self.ceil_at = []
        last_ev = None
        for i in range(n):
            ev = self.form_event_at(i * DT)
            self.form_at.append(ev["form"])
            self.ceil_at.append(CEIL if ev.get("ceiling", ev["form"] not in ("cube", "robot")) else None)
            self.gs_event.append(ev if ev is not last_ev else None)
            last_ev = ev
