"""Simulacao fisica deterministica + busca de alcancabilidade (frontier search).

O passo fisico (advance) e a unica fonte de verdade: o jogo (scripts/core/physics_model.gd)
tem uma porta 1:1 desta funcao. A posicao horizontal e funcao do tempo de audio (L.xs).
Entradas: 'hold' (0/1) amostrado a cada decision_steps substeps (30 Hz com dt=1/120).
"""
import math
from .common import PHYS
from .level import Level, DT, BODY, HURT, CEIL

EPS = PHYS["land_eps"]
FORMS = PHYS["forms"]
DSTEPS = PHYS["decision_steps"]
FC, FR, FS, FB, FP, FW = (FORMS[k] for k in ("cube", "robot", "ship", "ball", "spider", "wave"))
FLOOR_FORMS_SLIDE = ("ship", "wave")


def initial_state(L):
    ev = L.fe[0]
    return (0.0, 0.0, ev.get("gs", 1), 1, 0.0, 0)


def adapt(s, ev, prev_form_name):
    y, vy, gs, gr, aux, ph = s
    form = ev["form"]
    gs2 = ev.get("gs", gs)
    ceil = CEIL if ev.get("ceiling", form not in ("cube", "robot")) else None
    if ceil is not None and y + BODY > ceil:
        y = ceil - BODY
    if form != prev_form_name:
        vy = 0.0
    if form == "robot":
        aux = FR["hold_max"]
    else:
        aux = 0.0
    return (y, vy, gs2, 0, aux, ph)


def advance(L, i, s, hold):
    """Avanca um substep (de i*DT ate (i+1)*DT). Retorna novo estado ou None se morreu."""
    y, vy, gs, gr, aux, ph = s
    ev = L.gs_event[i + 1]
    if ev is not None:
        s2 = adapt(s, ev, L.form_at[i])
        y, vy, gs, gr, aux, ph = s2
    form = L.form_at[i + 1]
    if form == "lanes":      # trecho de notas do Music Dash: personagem automatico e seguro
        return (0.0, 0.0, 1, 1, 0.0, 0)
    x1 = L.xs[i + 1]
    ceil = L.ceil_at[i + 1]
    pressed = hold and not ph
    bt = y
    tp = y + BODY

    if form == "cube":
        if gr and hold:
            vy = FC["jump_v"] * gs
        vy -= FC["gravity"] * gs * DT
    elif form == "robot":
        if gr and hold:
            vy = FR["jump_v"] * gs
            aux = 0.0
        elif (not gr) and hold and aux < FR["hold_max"] and vy * gs > 0:
            vy += FR["hold_accel"] * gs * DT
            aux += DT
        elif not hold:
            aux = FR["hold_max"]
        vy -= FR["gravity"] * gs * DT
    elif form == "ship":
        vy += gs * (-FS["gravity"] + (FS["thrust"] if hold else 0.0)) * DT
        if vy > FS["vmax"]:
            vy = FS["vmax"]
        elif vy < -FS["vmax"]:
            vy = -FS["vmax"]
    elif form == "ball":
        if gr and pressed:
            gs = -gs
            gr = 0
            vy = 0.0
        vy -= FB["gravity"] * gs * DT
        if vy > FB["vmax"]:
            vy = FB["vmax"]
        elif vy < -FB["vmax"]:
            vy = -FB["vmax"]
    elif form == "spider":
        aux = aux - DT if aux > DT else 0.0
        if gr and pressed and aux <= 0.0 and ceil is not None:
            if gs == 1:
                y = ceil - BODY
                gs = -1
            else:
                y = 0.0
                gs = 1
            vy = 0.0
            gr = 1
            aux = FP["cooldown"]
            bt = y
            tp = y + BODY
        vy -= FP["gravity"] * gs * DT
        if vy > FP["vmax"]:
            vy = FP["vmax"]
        elif vy < -FP["vmax"]:
            vy = -FP["vmax"]
    else:  # wave
        sp = (L.xs[i + 1] - L.xs[i]) / DT
        vy = (1.0 if hold else -1.0) * gs * FW["slope"] * sp

    yn = y + vy * DT
    gr2 = 0
    if yn < 0.0:
        yn = 0.0
        if form in FLOOR_FORMS_SLIDE:
            if vy < 0:
                vy = 0.0
        elif gs == 1:
            gr2 = 1
            vy = 0.0
        elif vy < 0:
            vy = 0.0
    if ceil is not None and yn + BODY > ceil:
        yn = ceil - BODY
        if form in FLOOR_FORMS_SLIDE:
            if vy > 0:
                vy = 0.0
        elif gs == -1:
            gr2 = 1
            vy = 0.0
        elif vy > 0:
            vy = 0.0

    # --- solidos
    c0 = int(math.floor(x1))
    c1 = int(math.floor(x1 + BODY))
    sc = L.sol_cols
    cand = None
    for c in range(c0, c1 + 1):
        lst = sc.get(c)
        if lst:
            cand = lst if cand is None else cand + lst
    if cand:
        seen = set()
        for idx in cand:
            if idx in seen:
                continue
            seen.add(idx)
            sx0, sy0, sx1, sy1 = L.solids[idx]
            if x1 + BODY <= sx0 or x1 >= sx1:
                continue
            if yn + BODY <= sy0 or yn >= sy1:
                continue
            if form == "wave":
                return None
            res = False
            if vy <= 0 and bt >= sy1 - EPS and (gs == 1 or form == "ship"):
                yn = sy1
                vy = 0.0
                res = True
                if form != "ship" and gs == 1:
                    gr2 = 1
            elif vy >= 0 and tp <= sy0 + EPS and (gs == -1 or form == "ship"):
                yn = sy0 - BODY
                vy = 0.0
                res = True
                if form != "ship" and gs == -1:
                    gr2 = 1
            if not res:
                return None

    # --- espinhos (hurtbox menor que o corpo)
    kc = L.spk_cols
    if kc:
        cxl = x1 + (BODY - HURT) / 2
        cxr = cxl + HURT
        cyb = yn + (BODY - HURT) / 2
        cyt = cyb + HURT
        for c in range(int(math.floor(cxl)), int(math.floor(cxr)) + 1):
            lst = kc.get(c)
            if lst:
                for idx in lst:
                    sx0, sy0, sx1, sy1 = L.spikes[idx]
                    if cxr > sx0 and cxl < sx1 and cyt > sy0 and cyb < sy1:
                        return None
    return (yn, vy, gs, gr2, aux, 1 if hold else 0)


def _key(s, form):
    y, vy, gs, gr, aux, ph = s
    return (int(y * 24), int(vy * 2.0), gs, gr, int(aux * 30), ph if form in ("ball", "spider") else 0)


class SearchResult:
    def __init__(self):
        self.ok = False
        self.t_fail = None
        self.truncated = False
        self.max_frontier = 0
        self.end_frontier = {}

    def as_dict(self):
        return {"ok": self.ok, "t_fail": self.t_fail, "truncated": self.truncated, "max_frontier": self.max_frontier}


def search(L, start_d=0, frontier=None, beam=1200, snaps=None, snap_every=30):
    """Procura ao menos uma trajetoria que conclui a fase. Qualquer caminho encontrado e real (prova de viabilidade).
    Falha so e definitiva (FAILED) se nunca houve truncamento do beam; senao o chamador trata como UNVERIFIED."""
    res = SearchResult()
    if frontier is None:
        s0 = initial_state(L)
        frontier = {_key(s0, L.form_at[0]): s0}
    total_d = int(math.ceil((L.nsteps - 1) / DSTEPS))
    end_x = L.end_x
    for d in range(start_d, total_d):
        i0 = d * DSTEPS
        if snaps is not None and d % snap_every == 0:
            snaps[d] = dict(frontier)
        if L.xs[i0] >= end_x:
            res.ok = True
            res.end_frontier = frontier
            return res
        form = L.form_at[min(i0 + DSTEPS, len(L.form_at) - 1)]
        new = {}
        for s in frontier.values():
            for hold in (0, 1):
                st = s
                for k in range(DSTEPS):
                    st = advance(L, i0 + k, st, hold)
                    if st is None:
                        break
                if st is None:
                    continue
                kk = _key(st, form)
                if kk not in new:
                    new[kk] = st
        if not new:
            res.t_fail = i0 * DT
            return res
        if len(new) > beam:
            res.truncated = True
            items = sorted(new.items())
            stepf = len(items) / beam
            new = dict(items[int(j * stepf)] for j in range(beam))
        if len(new) > res.max_frontier:
            res.max_frontier = len(new)
        frontier = new
    res.ok = True
    res.end_frontier = frontier
    return res
