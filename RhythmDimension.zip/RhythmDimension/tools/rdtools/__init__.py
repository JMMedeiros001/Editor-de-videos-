"""Ferramentas de referencia do Rhythm Dimension (Python).

Implementam e TESTAM, de verdade, os mesmos algoritmos que o jogo (GDScript) usa:
analise de audio, geracao procedural, simulacao fisica e validacao.
"""
