"""Analise musical (BPM, batidas, energia, onsets). Algoritmo no dominio do tempo (sem FFT),
portavel para GDScript (scripts/analysis/beat_analyzer.gd) com o mesmo resultado esperado.

Etapas: mono 11025 Hz -> 3 bandas (IIR 1 polo) -> envelope por hop (256) em log -> fluxo positivo
-> forca de onset -> tempo por comb filter com prior -> fase da grade -> onsets por picos -> energia por compasso.
"""
import bisect
import math
import subprocess
import numpy as np

SR = 11025
HOP = 256
HOP_S = HOP / SR
SCALE_FLOOR = 0.8      # piso absoluto: evita amplificar ruido quando nao ha percussao
ONSET_ABS_MIN = 0.9    # forca bruta minima para considerar onset
CLARITY_REF = 2.5      # p99 bruto que equivale a 100% de clareza
W_LOW, W_MID, W_HIGH = 1.0, 0.8, 0.6


def decode(path, sr=SR):
    cmd = ["ffmpeg", "-v", "error", "-i", path, "-ac", "1", "-ar", str(sr), "-f", "f32le", "-"]
    raw = subprocess.run(cmd, capture_output=True, check=True).stdout
    return np.frombuffer(raw, dtype=np.float32).astype(np.float64)


def _onepole(x, fc, sr):
    from scipy.signal import lfilter
    a = math.exp(-2.0 * math.pi * fc / sr)
    return lfilter([1.0 - a], [1.0, -a], x)


def band_envelopes(x, sr=SR):
    lp1 = _onepole(x, 150.0, sr)
    lp2 = _onepole(x, 1500.0, sr)
    low = lp1
    mid = lp2 - lp1
    high = x - lp2
    n = len(x) // HOP
    out = []
    for b in (low, mid, high):
        seg = b[: n * HOP].reshape(n, HOP)
        rms = np.sqrt((seg ** 2).mean(axis=1))
        out.append(np.log1p(100.0 * rms))
    full = np.sqrt((x[: n * HOP].reshape(n, HOP) ** 2).mean(axis=1))
    return out, full


def onset_strength(envs):
    flux = []
    for e in envs:
        d = np.diff(e, prepend=e[0])
        flux.append(np.clip(d, 0.0, None))
    o = W_LOW * flux[0] + W_MID * flux[1] + W_HIGH * flux[2]
    p95 = np.percentile(o, 95) if len(o) else 1.0
    p99 = np.percentile(o, 99) if len(o) else 0.0
    scale = max(p95, SCALE_FLOOR)
    return o / scale, flux, scale, p99


def _interp(o, pos):
    """Interpola linearmente o array 'o' nas posicoes (em hops) 'pos' (array)."""
    pos = np.asarray(pos)
    i0 = np.floor(pos).astype(int)
    fr = pos - i0
    i0c = np.clip(i0, 0, len(o) - 1)
    i1c = np.clip(i0 + 1, 0, len(o) - 1)
    return o[i0c] * (1.0 - fr) + o[i1c] * fr


def _comb_score(o, period_hops, n_phase=16):
    """Melhor soma da grade de batidas (+ metade do compasso em colcheias) sobre as fases."""
    best = -1.0
    best_ph = 0.0
    n = len(o)
    for k in range(n_phase):
        ph = period_hops * k / n_phase
        pos = np.arange(ph, n - 1, period_hops)
        if len(pos) < 4:
            continue
        s = _interp(o, pos).mean() + 0.35 * _interp(o, pos + period_hops / 2).mean()
        if s > best:
            best, best_ph = s, ph
    return best, best_ph


def estimate_tempo(o, lo=70.0, hi=180.0):
    best_bpm, best_score = 120.0, -1.0
    scores = []
    bpm = lo
    while bpm <= hi + 1e-9:
        period = 60.0 / bpm / HOP_S
        sc, _ = _comb_score(o, period, 12)
        prior = math.exp(-0.5 * (math.log2(bpm / 120.0) / 0.6) ** 2)
        scores.append((bpm, sc * (0.55 + 0.45 * prior)))
        bpm += 0.5
    best_bpm, best_score = max(scores, key=lambda t: t[1])
    # refinamento fino
    fine_best, fine_score = best_bpm, -1.0
    b = best_bpm - 1.0
    while b <= best_bpm + 1.0 + 1e-9:
        period = 60.0 / b / HOP_S
        sc, _ = _comb_score(o, period, 32)
        if sc > fine_score:
            fine_best, fine_score = b, sc
        b += 0.05
    period = 60.0 / fine_best / HOP_S
    sc, ph = _comb_score(o, period, 64)
    return fine_best, ph * HOP_S, sc


def pick_onsets(o, flux, scale, min_sep=3, thr=0.22):
    thr = max(thr, ONSET_ABS_MIN / scale)
    peaks = []
    n = len(o)
    last = -100
    for i in range(1, n - 1):
        if o[i] >= thr and o[i] >= o[i - 1] and o[i] > o[i + 1] and i - last >= min_sep:
            fl = [flux[0][i], flux[1][i], flux[2][i]]
            band = int(np.argmax([fl[0] * W_LOW, fl[1] * W_MID, fl[2] * W_HIGH]))
            peaks.append({"t": round((i + 0.5) * HOP_S, 4), "s": round(float(min(o[i], 3.0)), 3), "b": band})
            last = i
    return peaks


def analyze_samples(x, sr=SR):
    dur = len(x) / sr
    envs, full = band_envelopes(x, sr)
    o, flux, scale, p99 = onset_strength(envs)
    bpm, off, sc = estimate_tempo(o)
    folded = False
    # ambiguidade de oitava: normaliza para 80..160 BPM e refaz a fase na nova grade
    while bpm >= 160.0:
        bpm /= 2.0
        folded = True
    while bpm < 80.0:
        bpm *= 2.0
        folded = True
    if folded:
        _, ph = _comb_score(o, 60.0 / bpm / HOP_S, 64)
        off = ph * HOP_S
    period = 60.0 / bpm
    off = off % period
    # confianca: media de O nas batidas / media geral
    pos = np.arange(off / HOP_S, len(o) - 1, period / HOP_S)
    ratio = _interp(o, pos).mean() / (o.mean() + 1e-9) if len(pos) else 1.0
    conf = float(min(max((ratio - 1.0) / 2.0, 0.0), 1.0)) * float(min(p99 / CLARITY_REF, 1.0))
    onsets = pick_onsets(o, flux, scale)
    # energia por compasso (4 batidas)
    bar_len = 4 * period
    nb = int(dur // bar_len)
    raw = []
    for b in range(nb + 1):
        t0 = off + b * bar_len
        i0 = int(t0 / HOP_S)
        i1 = int((t0 + bar_len) / HOP_S)
        seg = full[max(i0, 0):min(i1, len(full))]
        raw.append(float(seg.mean()) if len(seg) else 0.0)
    # normaliza pelo nivel tipico dos COMPASSOS fortes (nao pelos picos de transiente)
    ref = (np.percentile(raw, 90) if raw else 0.0) + 1e-9
    bars = [float(round(min(v / ref, 1.0), 3)) for v in raw]
    return {
        "bpm": round(bpm, 2), "offset": round(off, 4), "confidence": round(conf, 3),
        "duration": round(dur, 3), "onsets": onsets, "bar_energy": bars,
        "bar_len": round(bar_len, 4), "silence_thr": 0.04,
        "bpm_alternatives": [round(bpm * 2, 2), round(bpm / 2, 2)],
    }


def analyze_file(path):
    return analyze_samples(decode(path))


def onset_near(onsets_t, onsets, t, tol=0.05):
    """Maior forca de onset em [t-tol, t+tol]."""
    i = bisect.bisect_left(onsets_t, t - tol)
    best = 0.0
    while i < len(onsets_t) and onsets_t[i] <= t + tol:
        best = max(best, onsets[i]["s"])
        i += 1
    return best
