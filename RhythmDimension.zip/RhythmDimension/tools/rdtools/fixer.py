"""Correcao automatica: gerar -> validar -> encontrar erros -> corrigir (somente o trecho responsavel)
-> validar de novo -> comparar -> aprovar ou rejeitar a correcao. Limite de tentativas; nada e escondido.
Espelha scripts/validation/test_manager.gd (fluxo) e level_validator.gd.
"""
import copy
import math
from .common import PATTERNS, pattern_by_id, difficulty
from .level import Timeline
from . import validator
from .generator import _Gen, _instantiate
from .rng import Rng


def _score(rep):
    """Menor e melhor: (falhas, nao_verificadas, -t_da_primeira_falha_na_simulacao)."""
    fails = [t for t in rep["tests"] if t["status"] == "fail"]
    unv = [t for t in rep["tests"] if t["status"] == "unverified"]
    tf = [t.get("t_fail") for t in rep["tests"] if t.get("t_fail") is not None]
    sev = sum(t.get("severity", len(t["refs"]) or 1) for t in fails)
    return (len(fails) + len(unv), len(unv), round(sev, 3), -(min(tf) if tf else 1e9))


def _drop_instance(m, k):
    m["objects"] = [o for o in m["objects"] if o.get("inst") != k]
    m["form_events"] = [e for e in m["form_events"] if e.get("inst") != k]
    for i in m["instances"]:
        if i["k"] == k:
            i["removed"] = True
    m["instances"] = [i for i in m["instances"] if not i.get("removed")]


def _drop_last_hazard(m, k):
    objs = [o for o in m["objects"] if o.get("inst") == k]
    if len(objs) <= 1:
        return False
    last = max(objs, key=lambda o: o["x"])
    m["objects"].remove(last)
    return True


def _swap_simple(m, k):
    """Substitui a instancia pelo padrao mais simples (Pattern_Jump_01) no mesmo ponto."""
    inst = next((i for i in m["instances"] if i["k"] == k), None)
    if not inst or inst["pattern"] == "Pattern_Jump_01":
        return False
    objs = [o for o in m["objects"] if o.get("inst") == k]
    if not objs:
        return False
    x0 = min(o["x"] for o in objs)
    _drop_instance(m, k)
    m["objects"].append({"type": "spike", "x": round(x0, 3), "y": 0, "inst": k})
    m["instances"].append({"k": k, "pattern": "Pattern_Jump_01", "kind": "static", "form": "cube", "t0": inst["t0"], "t1": inst["t0"] + 0.6,
                           "bar": inst.get("bar", 0), "tier": 1, "anchor": inst.get("anchor", 0), "fixed": True})
    m["instances"].sort(key=lambda i: i["t0"])
    return True


def _remove_notes(m, idxs):
    s = set(idxs)
    m["notes"] = [n for i, n in enumerate(m["notes"]) if i not in s]


def _fix_notes_density(m, win_idx, d):
    notes = m["notes"]
    lim = d["notes"]["max_nps"]
    ts = [n["t"] for n in notes]
    t0 = notes[win_idx]["t"]
    cand = [i for i, n in enumerate(notes) if t0 - 1.0 <= n["t"] <= t0 and n["kind"] in ("tap", "fast")]
    if not cand:
        cand = [i for i, n in enumerate(notes) if t0 - 1.0 <= n["t"] <= t0]
    if not cand:
        return False
    # remove a nota mais fraca (a mais proxima de outra) primeiro
    cand.sort(key=lambda i: min(abs(notes[i]["t"] - notes[j]["t"]) for j in range(len(notes)) if j != i) if len(notes) > 1 else 0)
    _remove_notes(m, [cand[0]])
    return True


def fix_and_validate(m, max_iter=14, log=None, beam=1200):
    """Retorna (mapa_corrigido, relatorio_final, historico). O mapa original nao e alterado."""
    m = copy.deepcopy(m)
    d = validator.diff_of(m)
    hist = []
    rep = validator.validate(m, beam)
    attempts = {}
    rejected_in_a_row = 0
    it = 0
    while rep["status"] != "READY" and it < max_iter:
        it += 1
        bad = [t for t in rep["tests"] if t["status"] in ("fail", "unverified")]
        if not bad:
            break
        base_score = _score(rep)
        cand = copy.deepcopy(m)
        action = None
        # prioridade: estrutura/colisao/notas -> depois gameplay
        order = {"estrutura": 0, "colisao": 1, "notas": 2, "tempo": 3, "progressao": 4, "dificuldade": 5, "gameplay": 6}
        bad.sort(key=lambda t: order.get(t["category"], 9))
        tgt = bad[0]
        tid = tgt["id"]
        if tid in ("S3", "S6", "C1", "C3", "C4") and tgt["refs"]:
            rem = set(tgt["refs"])
            cand["objects"] = [o for i, o in enumerate(cand["objects"]) if i not in rem]
            action = "remover objetos invalidos %s" % sorted(rem)[:6]
        elif tid in ("S7", "N3", "N5", "N7") and tgt["refs"]:
            _remove_notes(cand, tgt["refs"])
            action = "remover notas invalidas %s" % tgt["refs"][:6]
        elif tid == "N4":
            ok = _fix_notes_density(cand, tgt["refs"][0], d)
            action = "remover nota mais fraca da janela de alta densidade" if ok else None
        elif tid == "N6":
            _remove_notes(cand, tgt["refs"])
            action = "remover nota inalcancavel com 2 dedos (indice %s)" % tgt["refs"]
        elif tid in ("T3", "T5", "G1") or tid in ("T1", "T2", "T4"):
            tf = tgt.get("t_fail")
            if tid == "T3" and tgt["refs"]:
                o = cand["objects"][tgt["refs"][0]]
                k = o.get("inst")
                tf = Timeline(cand["speed_events"]).t_at(o["x"])
            ik = None
            if tid == "T4" and cand["instances"]:
                ik = max(cand["instances"], key=lambda i: i["t1"])["k"]
            elif tf is None:
                tl = Timeline(cand["speed_events"])
                if tgt["refs"]:
                    ik = cand["objects"][tgt["refs"][0]].get("inst")
            else:
                near = [i for i in cand["instances"] if i["t0"] - 1.3 <= tf <= i["t1"] + 0.9]
                if near:
                    ik = min(near, key=lambda i: abs((i["t0"] + i["t1"]) / 2 - tf))["k"]
            if ik is None and tid in ("G1", "T3", "T5"):
                action = None
            elif ik is not None:
                n_try = attempts.get(("inst", ik), 0)
                attempts[("inst", ik)] = n_try + 1
                inst = next(i for i in cand["instances"] if i["k"] == ik)
                if n_try == 0 and inst["kind"] == "static" and _swap_simple(cand, ik):
                    action = "substituir %s por Pattern_Jump_01 (t=%.2fs)" % (inst["pattern"], inst["t0"])
                elif n_try <= 1 and inst["kind"] == "static" and _drop_last_hazard(cand, ik):
                    action = "remover ultimo perigo de %s" % inst["pattern"]
                else:
                    _drop_instance(cand, ik)
                    action = "remover instancia %s (t=%.2fs) preservando o restante" % (inst["pattern"], inst["t0"])
        elif tid in ("P1", "P2"):
            # garante que a fase termine em cubo
            cand["form_events"].append({"t": round(cand["end_t"] - 0.5, 3), "form": "cube", "gs": 1, "ceiling": False})
            action = "inserir portal final para forma normal"
        if action is None:
            hist.append({"iter": it, "test": tid, "action": None, "accepted": False, "note": "sem estrategia de correcao automatica; oferecer edicao manual"})
            attempts[("noaction", tid)] = attempts.get(("noaction", tid), 0) + 1
            break
        rep2 = validator.validate(cand, beam)
        s2 = _score(rep2)
        accepted = s2 < base_score or (s2[0] <= base_score[0] and rep2["status"] == "READY")
        rejected_in_a_row = 0 if accepted else rejected_in_a_row + 1
        hist.append({"iter": it, "test": tid, "refs": tgt["refs"][:6], "action": action, "before": {"fails": base_score[0], "unverified": base_score[1]},
                     "after": {"fails": s2[0], "unverified": s2[1]}, "accepted": accepted})
        if log:
            log(hist[-1])
        if accepted:
            m, rep = cand, rep2
        elif rejected_in_a_row >= 3:
            tf = tgt.get("t_fail")
            hist.append({"iter": it, "test": tid, "action": None, "accepted": False,
                         "note": "3 correcoes seguidas rejeitadas (nao melhoram os testes); trecho%s; oferecer edicao manual ou gerar alternativa" %
                                 (" t=%.2fs" % tf if tf is not None else "")})
            break
    m["validation_history"] = hist
    m["status"] = rep["status"]
    m["validation"] = {"result": rep["result"], "counts": rep["counts"], "levels": rep["levels"], "difficulty_estimate": rep["difficulty_estimate"],
                       "iterations": it, "limit": max_iter}
    return m, rep, hist
