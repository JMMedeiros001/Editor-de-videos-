"""PRNG xorshift32 simples. Identico ao scripts/core/rng.gd (mesma sequencia para a mesma seed)."""
M = 0xFFFFFFFF


class Rng:
    def __init__(self, seed: int):
        s = (int(seed) * 2654435761 + 12345) & M
        self.s = s if s != 0 else 1

    def next(self) -> int:
        x = self.s
        x ^= (x << 13) & M
        x ^= x >> 17
        x ^= (x << 5) & M
        self.s = x & M
        return self.s

    def f(self) -> float:
        return self.next() / 4294967296.0

    def i(self, n: int) -> int:
        return self.next() % n if n > 0 else 0

    def rng_i(self, a: int, b: int) -> int:
        return a + self.i(b - a + 1)

    def rng_f(self, a: float, b: float) -> float:
        return a + (b - a) * self.f()

    def pick(self, items):
        return items[self.i(len(items))]

    def weighted(self, items, weights):
        total = sum(weights)
        if total <= 0:
            return items[self.i(len(items))]
        r = self.f() * total
        acc = 0.0
        for it, w in zip(items, weights):
            acc += w
            if r < acc:
                return it
        return items[-1]
