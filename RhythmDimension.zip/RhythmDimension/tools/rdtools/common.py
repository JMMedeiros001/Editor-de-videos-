import json
import os

ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), "..", ".."))
DATA = os.path.join(ROOT, "data")


def load_json(name):
    with open(os.path.join(DATA, name), "r", encoding="utf-8") as f:
        return json.load(f)


PHYS = load_json("physics.json")
DIFF = load_json("difficulty.json")
PATTERNS = load_json("patterns.json")["patterns"]
GENERATOR_VERSION = "1.0.1"


def difficulty(name, custom=None):
    """Retorna parametros da dificuldade. 'custom' aceita sobrescritas (dict)."""
    if name == "custom":
        d = json.loads(json.dumps(DIFF["custom_defaults"]))
        if custom:
            for k, v in custom.items():
                if k == "notes" and isinstance(v, dict):
                    d["notes"].update(v)
                else:
                    d[k] = v
        d["name"] = "custom"
        return d
    d = json.loads(json.dumps(DIFF["levels"][name]))
    d["name"] = name
    return d


def speed_value(d):
    s = d["speed"]
    return PHYS["speeds"][s] if isinstance(s, str) else float(s)


def pattern_by_id(pid):
    for p in PATTERNS:
        if p["id"] == pid:
            return p
    return None
