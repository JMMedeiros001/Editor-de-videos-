"""Valida CADA padrao da biblioteca isoladamente (simulacao fisica real) por dificuldade e BPM.
Gera data/pattern_compat.json, usado pelo gerador (e pelo jogo) para so escolher padroes compativeis."""
import json, math, os, sys, time
sys.path.insert(0, os.path.dirname(__file__))
from rdtools.common import PATTERNS, DIFF, difficulty, speed_value, DATA
from rdtools.generator import _Gen, _instantiate, synthetic_analysis
from rdtools.level import Level, Timeline
from rdtools.sim import search

BPMS = list(range(70, 181, 10))
SEEDS = (1, 2)


def test_pattern(p, dn, bpm, seed):
    dd = difficulty(dn)
    an = synthetic_analysis(bpm, 12)
    g = _Gen(an, dd, "balanced", seed, None, None, None, None)
    g.tl = Timeline([{"t": 0.0, "speed": speed_value(dd)}])
    anchor = int(3.0 / g.beat) + 1
    res = _instantiate(g, p, anchor, dd, 0)
    if res is None:
        return False
    objs, fe, t0, t1 = res
    m = {"speed_events": [{"t": 0.0, "speed": speed_value(dd)}],
         "form_events": [{"t": 0.0, "form": "cube", "gs": 1, "ceiling": False}] + fe,
         "objects": objs, "end_t": t1 + 3.0}
    r = search(Level(m), beam=900)
    return r.ok


def main():
    path = os.path.join(DATA, "pattern_compat.json")
    out = {"version": 1, "bpms": BPMS, "seeds": list(SEEDS), "table": {}}
    if os.path.exists(path):
        try:
            prev = json.load(open(path))
            if prev.get("bpms") == BPMS:
                out["table"] = prev.get("table", {})
        except Exception:
            pass
    t0 = time.time()
    n = 0
    for p in PATTERNS:
        if p["mode"] != "geometry_run":
            continue
        if p["id"] in out["table"]:
            continue
        row = {}
        for dn in DIFF["order"]:
            dd = difficulty(dn)
            if p["kind"] == "static" and p["tier"] > dd["tier"]:
                continue
            if p["form"] != "cube" and p["form"] not in dd["forms"]:
                continue
            row[dn] = {}
            for bpm in BPMS:
                ok = all(test_pattern(p, dn, bpm, s) for s in SEEDS)
                row[dn][str(bpm)] = ok
                n += 1
        out["table"][p["id"]] = row
        with open(path, "w") as f:
            json.dump(out, f, indent=1)
        print(p["id"], {dn: "".join("1" if v else "0" for v in r.values()) for dn, r in row.items()}, f"{time.time()-t0:.0f}s", flush=True)
    out["sims"] = n
    with open(os.path.join(DATA, "pattern_compat.json"), "w") as f:
        json.dump(out, f, indent=1)
    print("pronto:", n, "combinacoes")


if __name__ == "__main__":
    main()
