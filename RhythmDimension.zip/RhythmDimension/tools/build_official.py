"""Constroi as 5 fases oficiais + trilha do Endless: sintetiza musica original (OGG), analisa o arquivo REAL,
gera a fase, valida/corrige e so grava se status == READY e se cumprir os requisitos da fase."""
import json, os, sys, time
sys.path.insert(0, os.path.dirname(__file__))
from rdtools import synth, analyzer, generator, validator, fixer
from rdtools.common import ROOT, DATA, GENERATOR_VERSION, load_json

TRACKS = [
    dict(id="official_01_first_pulse", name="FIRST PULSE", file="first_pulse", bpm=100, off=0.37, root=45, scale=(0, 3, 5, 7, 10),
         sections=[(2, 0), (6, 1), (8, 2), (4, 1), (6, 2), (2, 0)], mode="geometry_run", diff="beginner", style="balanced",
         need=lambda m: True),
    dict(id="official_02_neon_circuit", name="NEON CIRCUIT", file="neon_circuit", bpm=120, off=0.21, root=43, scale=(0, 2, 4, 7, 9),
         sections=[(2, 0), (8, 1), (12, 2), (4, 0), (10, 2), (2, 0)], mode="geometry_run", diff="normal", style="obstacles",
         need=lambda m: any(i["kind"] == "corridor_ship" for i in m["instances"]) and any(i["pattern"] in ("Pattern_Stair_05", "Pattern_SpikeBlock_06", "Pattern_Platform_08") for i in m["instances"])),
    dict(id="official_03_gravity_shift", name="GRAVITY SHIFT", file="gravity_shift", bpm=110, off=0.3, root=41, scale=(0, 3, 5, 6, 10),
         sections=[(2, 0), (8, 1), (8, 2), (4, 0), (10, 2), (2, 0)], mode="geometry_run", diff="normal", style="variations",
         need=lambda m: sum(1 for i in m["instances"] if i["kind"] == "flip_ball") >= 2),
    dict(id="official_04_beat_reactor", name="BEAT REACTOR", file="beat_reactor", bpm=140, off=0.12, root=47, scale=(0, 3, 5, 7, 10),
         sections=[(2, 0), (8, 1), (16, 2), (4, 1), (14, 2), (2, 0)], mode="geometry_run", diff="hard", style="speed",
         need=lambda m: len(m["speed_events"]) >= 3 and any(i["kind"] in ("corridor_wave", "flip_spider") for i in m["instances"])),
    dict(id="official_05_final_frequency", name="FINAL FREQUENCY", file="final_frequency", bpm=150, off=0.25, root=48, scale=(0, 2, 3, 7, 8),
         sections=[(2, 0), (8, 1), (16, 2), (6, 0), (16, 2), (2, 0)], mode="music_dash", diff="expert", style="balanced",
         need=lambda m: len(m.get("lane_segments", [])) >= 2 and len(m["notes"]) >= 40 and any(i["kind"] == "finale" for i in m["instances"])),
]


def pattern_ok_factory():
    p = os.path.join(DATA, "pattern_compat.json")
    if not os.path.exists(p):
        return None
    tab = json.load(open(p))
    bpms = tab["bpms"]

    def ok(pid, bpm, dn):
        row = tab["table"].get(pid, {}).get(dn)
        if row is None:
            return True
        lo = max([b for b in bpms if b <= bpm] or [bpms[0]])
        hi = min([b for b in bpms if b >= bpm] or [bpms[-1]])
        return row.get(str(lo), True) and row.get(str(hi), True)
    return ok


def main():
    os.makedirs(os.path.join(ROOT, "assets", "music"), exist_ok=True)
    os.makedirs(os.path.join(DATA, "levels"), exist_ok=True)
    pok = pattern_ok_factory()
    print("pattern_compat:", "carregado" if pok else "AUSENTE (todos os padroes permitidos)")
    index = []
    for T in TRACKS:
        t0 = time.time()
        sig, dur = synth.render(T["bpm"], T["sections"], offset=T["off"], seed=T["bpm"], root=T["root"], scale=T["scale"])
        wav = f"/tmp/{T['file']}.wav"
        ogg = os.path.join(ROOT, "assets", "music", T["file"] + ".ogg")
        synth.write_wav(wav, sig)
        synth.to_ogg(wav, ogg, 4)
        an = analyzer.analyze_file(ogg)
        octave_ok = min(abs(an["bpm"] - T["bpm"] * 2 ** k) / (T["bpm"] * 2 ** k) for k in (-1, 0, 1)) < 0.01
        print(f"[{T['name']}] audio {dur:.1f}s ogg {os.path.getsize(ogg)//1024}KB  BPM detectado {an['bpm']} (alvo {T['bpm']}, oitava_ok={octave_ok}) conf {an['confidence']}")
        chosen = None
        for seed in range(1, 61):
            m = generator.generate(an, T["mode"], T["diff"], T["style"], seed=seed, pattern_ok=pok, name=T["name"], level_id=T["id"])
            if not T["need"](m):
                continue
            m2, rep, hist = fixer.fix_and_validate(m)
            if rep["status"] == "READY" and T["need"](m2):
                chosen = (seed, m2, rep, hist)
                break
        if not chosen:
            print("   !! nenhuma seed produziu fase READY que cumpra os requisitos:", T["name"])
            continue
        seed, m2, rep, hist = chosen
        m2["audio"]["file"] = f"res://assets/music/{T['file']}.ogg"
        m2["official"] = True
        m2["validation"]["tests"] = [{k: t[k] for k in ("id", "category", "name", "status", "detail", "executed")} for t in rep["tests"]]
        m2["validation"]["validator"] = "python-reference (tools/rdtools)"
        m2["validation"]["date"] = "2026-11-05"
        m2["validation"]["generator_version"] = GENERATOR_VERSION
        m2["version"] = 1
        path = os.path.join(DATA, "levels", T["id"] + ".json")
        with open(path, "w") as f:
            json.dump(m2, f, separators=(",", ":"), ensure_ascii=False)
        kinds = {}
        for i in m2["instances"]:
            kinds[i["pattern"]] = kinds.get(i["pattern"], 0) + 1
        print(f"   seed {seed} -> {rep['result']} ({rep['status']}) testes {rep['counts']} est={rep['difficulty_estimate']} "
              f"objs={len(m2['objects'])} notas={len(m2['notes'])} correcoes={len(hist)} {time.time()-t0:.0f}s")
        print("   padroes:", kinds)
        index.append({"id": T["id"], "name": T["name"], "mode": T["mode"], "difficulty": T["diff"], "file": f"res://data/levels/{T['id']}.json",
                      "audio": f"res://assets/music/{T['file']}.ogg", "seed": seed, "status": rep["status"], "result": rep["result"]})
    # trilha do Endless
    sig, dur = synth.render(128, [(2, 0), (8, 1), (14, 2), (8, 1)], offset=0.2, seed=128, root=45, scale=(0, 3, 5, 7, 10))
    synth.write_wav("/tmp/endless_loop.wav", sig)
    synth.to_ogg("/tmp/endless_loop.wav", os.path.join(ROOT, "assets", "music", "endless_loop.ogg"), 4)
    with open(os.path.join(DATA, "levels", "index.json"), "w") as f:
        json.dump({"levels": index}, f, indent=1)
    print("indice gravado:", len(index), "fases oficiais")


if __name__ == "__main__":
    main()
