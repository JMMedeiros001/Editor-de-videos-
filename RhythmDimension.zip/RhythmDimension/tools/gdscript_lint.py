"""Lint ESTATICO BASICO dos .gd (NAO e o parser do Godot): indentacao, balanceamento, caminhos res://, class_name, lambdas multi-instrucao."""
import os, re, sys, json
ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), ".."))
errs, warns = [], []
gd = []
for d, _, fs in os.walk(os.path.join(ROOT, "scripts")):
    for f in fs:
        if f.endswith(".gd"):
            gd.append(os.path.join(d, f))
for d, _, fs in os.walk(os.path.join(ROOT, "tests")):
    for f in fs:
        if f.endswith(".gd"):
            gd.append(os.path.join(d, f))
class_names = {}
autoloads = {}
proj = open(os.path.join(ROOT, "project.godot")).read()
for m in re.finditer(r'^(\w+)="\*res://(.+)"$', proj, re.M):
    autoloads[m.group(1)] = m.group(2)
for p in autoloads.values():
    if not os.path.exists(os.path.join(ROOT, p)):
        errs.append("autoload ausente: " + p)
scene = open(os.path.join(ROOT, "scenes", "main.tscn")).read()
for m in re.finditer(r'path="res://(.+?)"', scene):
    if not os.path.exists(os.path.join(ROOT, m.group(1))):
        errs.append("cena referencia arquivo ausente: " + m.group(1))
total_lines = 0
for path in sorted(gd):
    rel = os.path.relpath(path, ROOT)
    src = open(path, encoding="utf-8").read()
    lines = src.split("\n")
    total_lines += len(lines)
    for i, ln in enumerate(lines, 1):
        if ln.startswith(" "):
            errs.append(f"{rel}:{i}: indentacao com espacos (use tabs)")
        m = re.match(r"^\s*class_name (\w+)", ln)
        if m:
            if m.group(1) in class_names:
                errs.append(f"{rel}: class_name duplicado {m.group(1)}")
            class_names[m.group(1)] = rel
            if m.group(1) in autoloads:
                errs.append(f"{rel}: class_name igual a autoload {m.group(1)}")
        # lambda de uma linha com varias instrucoes (risco de parse)
        if re.search(r"func\([^)]*\)\s*(->\s*\w+)?\s*:\s*[^#\n]*;\s*\w", ln) and "\tfunc " not in ln[:2]:
            warns.append(f"{rel}:{i}: lambda de uma linha com ';' (prefira metodo nomeado)")
    # balanceamento ignorando strings e comentarios
    depth = {"(": 0, ")": 0, "[": 0, "]": 0, "{": 0, "}": 0}
    for ln in lines:
        buf = re.sub(r'"(\\.|[^"\\])*"', '""', ln)
        buf = re.sub(r"'(\\.|[^'\\])*'", "''", buf)
        buf = buf.split("#")[0]
        for ch in buf:
            if ch in depth:
                depth[ch] += 1
    if depth["("] != depth[")"] or depth["["] != depth["]"] or depth["{"] != depth["}"]:
        errs.append(f"{rel}: parenteses/colchetes/chaves desbalanceados {depth}")
    for m in re.finditer(r'(?:load|preload)\("res://(.+?)"\)|"res://(.+?)"', src):
        pth = m.group(1) or m.group(2)
        if pth and not pth.endswith("/") and "%" not in pth:
            if not os.path.exists(os.path.join(ROOT, pth)):
                warns.append(f"{rel}: referencia a recurso inexistente res://{pth}")
# classes referenciadas existem?
known = set(class_names) | set(autoloads) | {"RD"}
builtin = set("Control Node Node2D RefCounted Thread Mutex Callable Time DirAccess FileAccess JSON Input OS DisplayServer AudioServer AudioStreamPlayer AudioStream AudioStreamWAV AudioStreamMP3 AudioStreamOggVorbis AudioStreamGenerator AudioStreamGeneratorPlayback AudioEffectCapture AudioStreamPlayback ThemeDB Theme StyleBoxFlat Button Label LineEdit HSlider CheckButton OptionButton ProgressBar ScrollContainer VBoxContainer HBoxContainer HFlowContainer MarginContainer ColorRect FileDialog ConfirmationDialog AcceptDialog TextServer Vector2 Vector2i Color Rect2 PackedFloat32Array PackedFloat64Array PackedInt32Array PackedByteArray PackedVector2Array PackedStringArray Array Dictionary String StringName Variant ResourceLoader CanvasItem Script".split())
refs = set()
for path in gd:
    src = open(path, encoding="utf-8").read()
    for m in re.finditer(r"\b([A-Z][A-Za-z0-9]+)\.(?:new|[a-z_]+)\(", src):
        refs.add((os.path.relpath(path, ROOT), m.group(1)))
for rel, c in sorted(refs):
    if c not in known and c not in builtin and not c.isupper():
        warns.append(f"{rel}: classe '{c}' nao e class_name/autoload nem classe nativa conhecida (verificar)")
print("arquivos .gd:", len(gd), " linhas:", total_lines)
print("class_names:", len(class_names), " autoloads:", len(autoloads))
print("ERROS:", len(errs))
for e in errs: print("  ", e)
print("AVISOS:", len(warns))
for w in warns[:40]: print("  ", w)
json.dump({"files": len(gd), "lines": total_lines, "errors": errs, "warnings": warns}, open(os.path.join(ROOT, "tools", "out", "gdscript_lint.json"), "w"), indent=1)
sys.exit(1 if errs else 0)
