class_name AnalysisJob
extends RefCounted
## Analise em thread com progresso REAL (etapas: decodificar, analisar). Consulte poll() a cada frame.

var thread: Thread
var progress := 0.0
var stage := ""
var done := false
var result: Dictionary = {}


func start_stream(stream: AudioStream, path: String) -> void:
	thread = Thread.new()
	thread.start(_run.bind(stream, path))


func start_samples(samples: PackedFloat32Array, sr: float) -> void:
	thread = Thread.new()
	thread.start(_run_samples.bind(samples, sr))


func _run(stream: AudioStream, path: String) -> void:
	stage = "Decodificando audio"
	var dec := MusicImporter.decode_pcm(stream, path, func(p: float): progress = 0.3 * p)
	if not dec["ok"]:
		result = dec
		done = true
		return
	_run_samples(dec["samples"], float(dec["sr"]))


func _run_samples(samples: PackedFloat32Array, sr: float) -> void:
	stage = "Analisando ritmo e batidas"
	result = BeatAnalyzer.analyze(samples, sr, func(p: float): progress = 0.3 + 0.7 * p)
	done = true


func poll() -> bool:
	if done and thread != null and thread.is_started():
		thread.wait_to_finish()
	return done
