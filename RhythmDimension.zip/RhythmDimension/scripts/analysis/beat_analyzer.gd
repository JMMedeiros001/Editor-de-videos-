class_name BeatAnalyzer
extends RefCounted
## Analise musical no dominio do tempo (sem FFT). PORTA de tools/rdtools/analyzer.py (testado la com BPM conhecido).
## Entrada: PCM mono (qualquer taxa; use MusicImporter.decode_pcm que decima para ~11025 Hz).
## O BPM e APROXIMADO e tem ambiguidade de oitava (normalizado em 80..160). Sempre permita ajuste manual.

const HOP := 256
const W_LOW := 1.0
const W_MID := 0.8
const W_HIGH := 0.6
const SCALE_FLOOR := 0.8
const ONSET_ABS_MIN := 0.9
const CLARITY_REF := 2.5


static func _percentile(arr: PackedFloat32Array, p: float) -> float:
	if arr.is_empty():
		return 0.0
	var a := arr.duplicate()
	a.sort()
	var pos := p / 100.0 * float(a.size() - 1)
	var i0 := int(floor(pos))
	var i1 := mini(i0 + 1, a.size() - 1)
	var fr := pos - float(i0)
	return a[i0] * (1.0 - fr) + a[i1] * fr


static func _interp(o: PackedFloat32Array, pos: float) -> float:
	var i0 := int(floor(pos))
	var fr := pos - float(i0)
	var a: float = o[clampi(i0, 0, o.size() - 1)]
	var b: float = o[clampi(i0 + 1, 0, o.size() - 1)]
	return a * (1.0 - fr) + b * fr


static func _comb(o: PackedFloat32Array, period: float, n_phase: int) -> Array:
	var best := -1.0
	var best_ph := 0.0
	var n := o.size()
	for k in range(n_phase):
		var ph := period * float(k) / float(n_phase)
		var p := ph
		var s1 := 0.0
		var s2 := 0.0
		var cnt := 0
		while p < float(n - 1):
			s1 += _interp(o, p)
			s2 += _interp(o, p + period / 2.0)
			cnt += 1
			p += period
		if cnt < 4:
			continue
		var sc := s1 / float(cnt) + 0.35 * s2 / float(cnt)
		if sc > best:
			best = sc
			best_ph = ph
	return [best, best_ph]


## samples: PCM mono float [-1,1]; sr: taxa efetiva em Hz. progress: Callable(float 0..1).
static func analyze(samples: PackedFloat32Array, sr: float, progress: Callable = Callable()) -> Dictionary:
	var hop_s: float = float(HOP) / sr
	var dur: float = float(samples.size()) / sr
	var n: int = samples.size() / HOP
	if n < 40:
		return {"ok": false, "error": "audio muito curto para analise"}
	var a1: float = exp(-2.0 * PI * 150.0 / sr)
	var a2: float = exp(-2.0 * PI * 1500.0 / sr)
	var lp1 := 0.0
	var lp2 := 0.0
	var env_l := PackedFloat32Array(); env_l.resize(n)
	var env_m := PackedFloat32Array(); env_m.resize(n)
	var env_h := PackedFloat32Array(); env_h.resize(n)
	var full := PackedFloat32Array(); full.resize(n)
	for h in range(n):
		var sl := 0.0
		var sm := 0.0
		var sh := 0.0
		var sf := 0.0
		var base := h * HOP
		for k in range(HOP):
			var x: float = samples[base + k]
			lp1 = a1 * lp1 + (1.0 - a1) * x
			lp2 = a2 * lp2 + (1.0 - a2) * x
			var mid := lp2 - lp1
			var high := x - lp2
			sl += lp1 * lp1
			sm += mid * mid
			sh += high * high
			sf += x * x
		env_l[h] = log(1.0 + 100.0 * sqrt(sl / HOP))
		env_m[h] = log(1.0 + 100.0 * sqrt(sm / HOP))
		env_h[h] = log(1.0 + 100.0 * sqrt(sh / HOP))
		full[h] = sqrt(sf / HOP)
		if progress.is_valid() and h % 400 == 0:
			progress.call(0.5 * float(h) / float(n))
	# fluxo positivo e forca de onset
	var fl := PackedFloat32Array(); fl.resize(n)
	var fm := PackedFloat32Array(); fm.resize(n)
	var fh := PackedFloat32Array(); fh.resize(n)
	var o := PackedFloat32Array(); o.resize(n)
	for h in range(n):
		if h > 0:
			fl[h] = maxf(env_l[h] - env_l[h - 1], 0.0)
			fm[h] = maxf(env_m[h] - env_m[h - 1], 0.0)
			fh[h] = maxf(env_h[h] - env_h[h - 1], 0.0)
		o[h] = W_LOW * fl[h] + W_MID * fm[h] + W_HIGH * fh[h]
	var p95 := _percentile(o, 95.0)
	var p99 := _percentile(o, 99.0)
	var scale := maxf(p95, SCALE_FLOOR)
	for h in range(n):
		o[h] = o[h] / scale
	# tempo (comb + prior), busca grossa e fina
	var best_bpm := 120.0
	var best_sc := -1.0
	var bpm := 70.0
	while bpm <= 180.0 + 1e-9:
		var period := 60.0 / bpm / hop_s
		var r := _comb(o, period, 12)
		var prior := exp(-0.5 * pow((log(bpm / 120.0) / log(2.0)) / 0.6, 2.0))
		var sc: float = float(r[0]) * (0.55 + 0.45 * prior)
		if sc > best_sc:
			best_sc = sc
			best_bpm = bpm
		bpm += 0.5
		if progress.is_valid():
			progress.call(0.5 + 0.35 * (bpm - 70.0) / 110.0)
	var fine_bpm := best_bpm
	var fine_sc := -1.0
	var b := best_bpm - 1.0
	while b <= best_bpm + 1.0 + 1e-9:
		var r2 := _comb(o, 60.0 / b / hop_s, 32)
		if float(r2[0]) > fine_sc:
			fine_sc = float(r2[0])
			fine_bpm = b
		b += 0.05
	var rr := _comb(o, 60.0 / fine_bpm / hop_s, 64)
	var offset: float = float(rr[1]) * hop_s
	var folded := false
	while fine_bpm >= 160.0:
		fine_bpm /= 2.0
		folded = true
	while fine_bpm < 80.0:
		fine_bpm *= 2.0
		folded = true
	if folded:
		var rf := _comb(o, 60.0 / fine_bpm / hop_s, 64)
		offset = float(rf[1]) * hop_s
	var period_s: float = 60.0 / fine_bpm
	offset = fposmod(offset, period_s)
	# confianca
	var s_beats := 0.0
	var c_beats := 0
	var p := offset / hop_s
	while p < float(n - 1):
		s_beats += _interp(o, p)
		c_beats += 1
		p += period_s / hop_s
	var mean_all := 0.0
	for h in range(n):
		mean_all += o[h]
	mean_all /= float(n)
	var ratio := (s_beats / maxf(float(c_beats), 1.0)) / (mean_all + 1e-9)
	var conf: float = clampf((ratio - 1.0) / 2.0, 0.0, 1.0) * minf(p99 / CLARITY_REF, 1.0)
	# onsets
	var thr: float = maxf(0.22, ONSET_ABS_MIN / scale)
	var onsets: Array = []
	var last := -100
	for h in range(1, n - 1):
		if o[h] >= thr and o[h] >= o[h - 1] and o[h] > o[h + 1] and h - last >= 3:
			var cand := [fl[h] * W_LOW, fm[h] * W_MID, fh[h] * W_HIGH]
			var band := 0
			if cand[1] > cand[band]:
				band = 1
			if cand[2] > cand[band]:
				band = 2
			onsets.append({"t": snappedf((float(h) + 0.5) * hop_s, 0.0001), "s": snappedf(minf(o[h], 3.0), 0.001), "b": band})
			last = h
	# energia por compasso (normalizada pelo nivel dos compassos fortes)
	var bar_len: float = 4.0 * period_s
	var nb: int = int(dur / bar_len)
	var raw := PackedFloat32Array()
	for bi in range(nb + 1):
		var t0: float = offset + float(bi) * bar_len
		var i0: int = int(t0 / hop_s)
		var i1: int = int((t0 + bar_len) / hop_s)
		var sm2 := 0.0
		var cnt := 0
		for hh in range(maxi(i0, 0), mini(i1, n)):
			sm2 += full[hh]
			cnt += 1
		raw.append(sm2 / float(cnt) if cnt > 0 else 0.0)
	var ref := _percentile(raw, 90.0) + 1e-9
	var bars: Array = []
	for v in raw:
		bars.append(snappedf(minf(v / ref, 1.0), 0.001))
	if progress.is_valid():
		progress.call(1.0)
	return {"ok": true, "bpm": snappedf(fine_bpm, 0.01), "offset": snappedf(offset, 0.0001), "confidence": snappedf(conf, 0.001),
			"duration": snappedf(dur, 0.001), "onsets": onsets, "bar_energy": bars, "bar_len": snappedf(bar_len, 0.0001),
			"silence_thr": 0.04, "bpm_alternatives": [snappedf(fine_bpm * 2.0, 0.01), snappedf(fine_bpm / 2.0, 0.01)]}
