class_name RD
extends RefCounted
## Acesso a dados (data/*.json) e utilidades comuns. Identico em conteudo ao tools/rdtools/common.py.

const GENERATOR_VERSION := "1.0.1"
const FORM_CUBE := 0
const FORM_ROBOT := 1
const FORM_SHIP := 2
const FORM_BALL := 3
const FORM_SPIDER := 4
const FORM_WAVE := 5
const FORM_LANES := 6
const FORM_NAMES := ["cube", "robot", "ship", "ball", "spider", "wave", "lanes"]
const STYLES := ["balanced", "obstacles", "notes", "speed", "precision", "variations", "random"]
const MODES := ["geometry_run", "magic_rhythm", "music_dash", "endless"]

static var _phys: Dictionary = {}
static var _diff: Dictionary = {}
static var _patterns: Array = []
static var _compat: Dictionary = {}


static func read_json(path: String) -> Variant:
	if not FileAccess.file_exists(path):
		return null
	var f := FileAccess.open(path, FileAccess.READ)
	if f == null:
		return null
	return JSON.parse_string(f.get_as_text())


static func write_json(path: String, data: Variant) -> bool:
	var f := FileAccess.open(path, FileAccess.WRITE)
	if f == null:
		return false
	f.store_string(JSON.stringify(data))
	return true


static func physics() -> Dictionary:
	if _phys.is_empty():
		_phys = read_json("res://data/physics.json")
	return _phys


static func difficulty_table() -> Dictionary:
	if _diff.is_empty():
		_diff = read_json("res://data/difficulty.json")
	return _diff


static func patterns() -> Array:
	if _patterns.is_empty():
		var d: Variant = read_json("res://data/patterns.json")
		_patterns = d["patterns"]
	return _patterns


static func difficulty(dname: String, custom: Dictionary = {}) -> Dictionary:
	var t := difficulty_table()
	var d: Dictionary
	if dname == "custom":
		d = (t["custom_defaults"] as Dictionary).duplicate(true)
		for k in custom.keys():
			if k == "notes" and custom[k] is Dictionary:
				for kk in (custom[k] as Dictionary).keys():
					d["notes"][kk] = custom[k][kk]
			else:
				d[k] = custom[k]
	elif dname == "endless":
		d = (t["levels"]["beginner"] as Dictionary).duplicate(true)
		d["band"] = [0.0, 10.1]
	else:
		d = (t["levels"][dname] as Dictionary).duplicate(true)
	d["name"] = dname
	return d


static func speed_value(d: Dictionary) -> float:
	var s: Variant = d["speed"]
	if s is String:
		return float(physics()["speeds"][s])
	return float(s)


static func pattern_ok(pid: String, bpm: float, dname: String) -> bool:
	if _compat.is_empty():
		var c: Variant = read_json("res://data/pattern_compat.json")
		_compat = c if c != null else {"table": {}, "bpms": [70]}
	var row: Variant = _compat["table"].get(pid, {}).get(dname, null)
	if row == null:
		return true
	var lo: int = -1
	var hi: int = -1
	for b in _compat["bpms"]:
		if float(b) <= bpm:
			lo = int(b)
		if float(b) >= bpm and hi < 0:
			hi = int(b)
	if lo < 0:
		lo = int(_compat["bpms"][0])
	if hi < 0:
		hi = int(_compat["bpms"][_compat["bpms"].size() - 1])
	return bool(row.get(str(lo), true)) and bool(row.get(str(hi), true))
