class_name Rng
extends RefCounted
## xorshift32 - MESMA sequencia do tools/rdtools/rng.py (mesma seed => mesmo mapa).

const M := 0xFFFFFFFF
var s: int = 1


func _init(seed_value: int = 1) -> void:
	var v: int = (int(seed_value) * 2654435761 + 12345) & M
	s = v if v != 0 else 1


func next() -> int:
	var x: int = s
	x ^= (x << 13) & M
	x ^= x >> 17
	x ^= (x << 5) & M
	s = x & M
	return s


func f() -> float:
	return float(next()) / 4294967296.0


func i(n: int) -> int:
	return next() % n if n > 0 else 0


func rng_i(a: int, b: int) -> int:
	return a + i(b - a + 1)


func rng_f(a: float, b: float) -> float:
	return a + (b - a) * f()


func pick(items: Array) -> Variant:
	return items[i(items.size())]


func weighted(items: Array, weights: Array) -> Variant:
	var total := 0.0
	for w in weights:
		total += float(w)
	if total <= 0.0:
		return items[i(items.size())]
	var r := f() * total
	var acc := 0.0
	for k in range(items.size()):
		acc += float(weights[k])
		if r < acc:
			return items[k]
	return items[items.size() - 1]
