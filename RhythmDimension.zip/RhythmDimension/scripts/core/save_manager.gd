extends Node
## Salvamento persistente com escrita atomica + backup + recuperacao (autoload SaveManager).
## user://save.json  (principal)  | user://save.json.bak (anterior) | user://save.json.tmp (escrita)

const PATH := "user://save.json"
var data: Dictionary = {}
var recovered_from_backup := false


func _ready() -> void:
	load_all()


func _default() -> Dictionary:
	return {"version": 1, "records": {}, "stats": {"games": 0, "time": 0.0, "perfect": 0, "great": 0, "good": 0, "miss": 0, "best_combo": 0,
			"by_mode": {}}, "achievements": {}, "xp": 0, "songs": [], "levels": [], "unlocked": ["cube", "neon", "#00e5ff"]}


func load_all() -> void:
	data = _default()
	recovered_from_backup = false
	var d: Variant = RD.read_json(PATH)
	if d == null or not (d is Dictionary) or not (d as Dictionary).has("version"):
		var b: Variant = RD.read_json(PATH + ".bak")
		if b != null and b is Dictionary and (b as Dictionary).has("version"):
			d = b
			recovered_from_backup = true
		else:
			d = null
	if d != null:
		for k in (d as Dictionary).keys():
			data[k] = d[k]


func save_all() -> bool:
	var tmp := PATH + ".tmp"
	if not RD.write_json(tmp, data):
		return false
	if FileAccess.file_exists(PATH):
		DirAccess.copy_absolute(PATH, PATH + ".bak")
	return DirAccess.rename_absolute(tmp, PATH) == OK or RD.write_json(PATH, data)


# ---- biblioteca de musicas (referencias; copia local opcional)
func add_song(info: Dictionary) -> void:
	for s in data["songs"]:
		if s["id"] == info["id"]:
			return
	data["songs"].append(info)
	save_all()


func remove_song(id: String) -> void:
	data["songs"] = (data["songs"] as Array).filter(func(s): return s["id"] != id)
	save_all()


func get_song(id: String) -> Dictionary:
	for s in data["songs"]:
		if s["id"] == id:
			return s
	return {}


func update_song(id: String, patch: Dictionary) -> void:
	for s in data["songs"]:
		if s["id"] == id:
			for k in patch.keys():
				s[k] = patch[k]
	save_all()


# ---- fases do usuario
func save_level(m: Dictionary) -> void:
	DirAccess.make_dir_recursive_absolute("user://levels")
	RD.write_json("user://levels/%s.json" % m["id"], m)
	var lst: Array = data["levels"]
	var found := false
	for e in lst:
		if e["id"] == m["id"]:
			e["name"] = m.get("name", m["id"]); e["status"] = m.get("status", "UNVERIFIED"); found = true
	if not found:
		lst.append({"id": m["id"], "name": m.get("name", m["id"]), "mode": m.get("mode", ""), "difficulty": m.get("difficulty", ""),
				"status": m.get("status", "UNVERIFIED"), "song_id": m.get("song_id", "")})
	save_all()


func load_level(id: String) -> Dictionary:
	var d: Variant = RD.read_json("user://levels/%s.json" % id)
	return d if d is Dictionary else {}


func delete_level(id: String) -> void:
	if FileAccess.file_exists("user://levels/%s.json" % id):
		DirAccess.remove_absolute("user://levels/%s.json" % id)
	data["levels"] = (data["levels"] as Array).filter(func(e): return e["id"] != id)
	save_all()


# ---- recordes / estatisticas / conquistas
func record_result(level_id: String, mode: String, r: Dictionary, practice: bool) -> Dictionary:
	var newrec := false
	var st: Dictionary = data["stats"]
	st["games"] += 1
	st["time"] += float(r.get("time", 0.0))
	for k in ["perfect", "great", "good", "miss"]:
		st[k] += int(r.get(k, 0))
	st["best_combo"] = maxi(int(st["best_combo"]), int(r.get("max_combo", 0)))
	var bm: Dictionary = st["by_mode"]
	if not bm.has(mode):
		bm[mode] = {"games": 0, "best_score": 0, "best_acc": 0.0, "time": 0.0}
	bm[mode]["games"] += 1
	bm[mode]["time"] += float(r.get("time", 0.0))
	if not practice:   # pratica NUNCA altera o recorde oficial
		var rec: Dictionary = data["records"].get(level_id, {"best_score": 0, "best_acc": 0.0, "best_rank": "-", "best_progress": 0.0, "attempts": 0})
		rec["attempts"] += 1
		if int(r.get("score", 0)) > int(rec["best_score"]):
			rec["best_score"] = int(r["score"]); newrec = true
		rec["best_acc"] = maxf(float(rec["best_acc"]), float(r.get("accuracy", 0.0)))
		rec["best_progress"] = maxf(float(rec["best_progress"]), float(r.get("progress", 0.0)))
		if _rank_val(String(r.get("rank", "D"))) > _rank_val(String(rec["best_rank"])):
			rec["best_rank"] = r["rank"]
		data["records"][level_id] = rec
		bm[mode]["best_score"] = maxi(int(bm[mode]["best_score"]), int(r.get("score", 0)))
		bm[mode]["best_acc"] = maxf(float(bm[mode]["best_acc"]), float(r.get("accuracy", 0.0)))
		data["xp"] += int(r.get("score", 0)) / 100 + 20
	var unlocked := _check_achievements(r, practice, newrec)
	save_all()
	return {"new_record": newrec, "achievements": unlocked}


func _rank_val(rk: String) -> int:
	return ["-", "D", "C", "B", "A", "S", "SS"].find(rk)


func level_from_xp() -> int:
	return 1 + int(floor(sqrt(float(data["xp"]) / 100.0)))


func unlock(item: String) -> void:
	if not (data["unlocked"] as Array).has(item):
		data["unlocked"].append(item)


func _ach(id: String) -> bool:
	if data["achievements"].has(id):
		return false
	data["achievements"][id] = true
	return true


func _check_achievements(r: Dictionary, practice: bool, newrec: bool) -> Array:
	var out: Array = []
	if int(r.get("perfect", 0)) > 0 and _ach("primeiro_perfect"): out.append("Primeiro Perfect")
	if int(r.get("max_combo", 0)) >= 50 and _ach("combo_50"): out.append("Combo 50")
	if int(r.get("max_combo", 0)) >= 100 and _ach("combo_100"): out.append("Combo 100")
	if bool(r.get("completed", false)) and not practice and _ach("primeira_fase"): out.append("Primeira fase concluida")
	if newrec and (data["records"] as Dictionary).size() > 0 and int(data["stats"]["games"]) > 1 and _ach("recorde_pessoal"): out.append("Recorde pessoal")
	if bool(r.get("completed", false)) and int(r.get("miss", 0)) == 0 and int(r.get("deaths", 0)) == 0 and not practice and _ach("sem_erros"): out.append("Fase sem erros")
	if bool(r.get("completed", false)) and String(r.get("mode", "")) != "" and (data["records"] as Dictionary).size() >= 5:
		unlock("ship"); unlock("cyberpunk")
	return out


func achievements_list() -> Array:
	var names := {"primeiro_perfect": "Primeiro Perfect", "combo_50": "Combo 50", "combo_100": "Combo 100", "primeira_fase": "Primeira fase concluida",
			"primeira_musica": "Primeira musica importada", "primeira_criada": "Primeira fase criada", "recorde_pessoal": "Recorde pessoal", "sem_erros": "Fase sem erros"}
	var out: Array = []
	for k in names.keys():
		out.append({"id": k, "name": names[k], "done": data["achievements"].has(k)})
	return out


func award(id: String) -> void:
	if _ach(id):
		save_all()
