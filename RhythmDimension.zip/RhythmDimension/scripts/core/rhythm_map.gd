class_name RhythmMap
extends RefCounted
## Mapa/fase (geometria + notas) com tabelas de passo para a simulacao. Porta de tools/rdtools/level.py.

var m: Dictionary
var sp_t: PackedFloat64Array = PackedFloat64Array()
var sp_v: PackedFloat64Array = PackedFloat64Array()
var sp_x: PackedFloat64Array = PackedFloat64Array()
var fe: Array = []
var fe_t: PackedFloat64Array = PackedFloat64Array()
var end_t: float = 0.0
var end_x: float = 0.0
var solids: Array = []
var spikes: Array = []
var sol_cols: Dictionary = {}
var spk_cols: Dictionary = {}
var nsteps: int = 0
var xs: PackedFloat64Array = PackedFloat64Array()
var form_at: PackedInt32Array = PackedInt32Array()
var ceil_at: PackedFloat64Array = PackedFloat64Array()
var ev_at: Array = []


static func from_dict(d: Dictionary) -> RhythmMap:
	var r := RhythmMap.new()
	r.m = d
	r.build()
	return r


static func load_file(path: String) -> RhythmMap:
	var d: Variant = RD.read_json(path)
	if d == null or not (d is Dictionary):
		return null
	return from_dict(d)


func build() -> void:
	var sp: Array = (m.get("speed_events", [{"t": 0.0, "speed": 10.4}]) as Array).duplicate(true)
	sp.sort_custom(func(a, b): return float(a["t"]) < float(b["t"]))
	if sp.is_empty():
		sp = [{"t": 0.0, "speed": 10.4}]
	if float(sp[0]["t"]) > 0.0:
		sp.insert(0, {"t": 0.0, "speed": sp[0]["speed"]})
	sp_t.clear(); sp_v.clear(); sp_x.clear()
	for e in sp:
		sp_t.append(float(e["t"]))
		sp_v.append(float(e["speed"]))
	sp_x.append(0.0)
	for k in range(1, sp.size()):
		sp_x.append(sp_x[k - 1] + sp_v[k - 1] * (sp_t[k] - sp_t[k - 1]))
	fe = (m.get("form_events", []) as Array).duplicate(true)
	fe.sort_custom(func(a, b): return float(a["t"]) < float(b["t"]))
	if fe.is_empty() or float(fe[0]["t"]) > 0.0:
		fe.insert(0, {"t": 0.0, "form": "cube", "gs": 1, "ceiling": false})
	fe_t.clear()
	for e in fe:
		fe_t.append(float(e["t"]))
	end_t = float(m["end_t"])
	end_x = x_at(end_t)
	_index_objects()
	nsteps = int(ceil(end_t / float(RD.physics()["dt"]))) + 2
	_build_step_tables()


func _bisect_right(arr: PackedFloat64Array, v: float) -> int:
	var lo := 0
	var hi := arr.size()
	while lo < hi:
		var mid := (lo + hi) >> 1
		if v < arr[mid]:
			hi = mid
		else:
			lo = mid + 1
	return lo


func x_at(t: float) -> float:
	if t <= 0.0:
		return sp_v[0] * t
	var k := _bisect_right(sp_t, t) - 1
	return sp_x[k] + sp_v[k] * (t - sp_t[k])


func t_at(x: float) -> float:
	var k := maxi(_bisect_right(sp_x, x) - 1, 0)
	return sp_t[k] + (x - sp_x[k]) / sp_v[k]


func speed_at(t: float) -> float:
	return sp_v[maxi(_bisect_right(sp_t, t) - 1, 0)]


func form_event_index(t: float) -> int:
	return maxi(_bisect_right(fe_t, t) - 1, 0)


func form_event_at(t: float) -> Dictionary:
	return fe[form_event_index(t)]


func _index_objects() -> void:
	solids.clear(); spikes.clear(); sol_cols.clear(); spk_cols.clear()
	var P := RD.physics()
	var spw: float = P["spike_w"]
	var sph: float = P["spike_h"]
	for o in m.get("objects", []):
		var x: float = float(o["x"])
		var y: float = float(o.get("y", 0))
		if o["type"] == "block":
			solids.append([x, y, x + float(o.get("w", 1)), y + float(o.get("h", 1))])
		elif o["type"] == "spike":
			var cx := x + 0.5
			if o.get("flip", false):
				spikes.append([cx - spw / 2.0, y + 1.0 - sph, cx + spw / 2.0, y + 1.0])
			else:
				spikes.append([cx - spw / 2.0, y, cx + spw / 2.0, y + sph])
	for idx in range(solids.size()):
		var s: Array = solids[idx]
		for c in range(int(floor(s[0])) - 1, int(floor(s[2])) + 1):
			if not sol_cols.has(c):
				sol_cols[c] = []
			sol_cols[c].append(idx)
	for idx in range(spikes.size()):
		var s2: Array = spikes[idx]
		for c in range(int(floor(s2[0])) - 1, int(floor(s2[2])) + 1):
			if not spk_cols.has(c):
				spk_cols[c] = []
			spk_cols[c].append(idx)


func _build_step_tables() -> void:
	var P := RD.physics()
	var dt: float = P["dt"]
	var ceil_y: float = P["ceiling_y"]
	var n := nsteps + 12
	xs.resize(n); form_at.resize(n); ceil_at.resize(n)
	ev_at.clear()
	var last_k: int = -1
	for i in range(n):
		var k := form_event_index(float(i) * dt)
		var ev: Dictionary = fe[k]
		xs[i] = x_at(float(i) * dt)
		var fi: int = RD.FORM_NAMES.find(String(ev["form"]))
		form_at[i] = fi
		var has_ceil: bool = ev.get("ceiling", not (fi == RD.FORM_CUBE or fi == RD.FORM_ROBOT))
		ceil_at[i] = ceil_y if has_ceil else -1.0
		if k == last_k:
			ev_at.append(null)
		else:
			ev_at.append(ev)
		last_k = k
