extends Node
## Gerenciador do jogo (autoload GameManager): navegacao entre telas, inicio de fases, orientacao, resultados.

var main = null    # raiz da UI (scripts/ui/main.gd); sem tipo para permitir show_screen/toast
var screen_paths := {
	"menu": "res://scripts/ui/main_menu.gd", "play": "res://scripts/ui/play_select.gd", "songs": "res://scripts/ui/my_songs.gd",
	"library": "res://scripts/ui/library.gd", "setup": "res://scripts/ui/song_setup.gd", "loading": "res://scripts/ui/loading_screen.gd",
	"results": "res://scripts/ui/results.gd", "editor": "res://scripts/editor/editor_screen.gd", "challenges": "res://scripts/ui/challenges.gd",
	"customize": "res://scripts/ui/customize.gd", "stats": "res://scripts/ui/stats.gd", "settings": "res://scripts/ui/settings_screen.gd",
	"tutorial": "res://scripts/ui/tutorial.gd", "geometry": "res://scripts/gameplay/geometry_run.gd", "rhythm": "res://scripts/gameplay/magic_rhythm.gd",
}
var last_play_args: Dictionary = {}


func goto(screen: String, args: Dictionary = {}) -> void:
	if main == null:
		return
	var portrait: bool = (screen == "rhythm")
	_set_orientation(screen == "geometry", portrait)
	main.show_screen(screen_paths[screen], args)


func _set_orientation(landscape: bool, portrait: bool) -> void:
	if OS.get_name() != "Android" and OS.get_name() != "iOS":
		return
	if landscape:
		DisplayServer.screen_set_orientation(DisplayServer.SCREEN_SENSOR_LANDSCAPE)
	elif portrait:
		DisplayServer.screen_set_orientation(DisplayServer.SCREEN_SENSOR_PORTRAIT)
	else:
		DisplayServer.screen_set_orientation(DisplayServer.SCREEN_SENSOR)


func toast(msg: String) -> void:
	if main != null:
		main.toast(msg)


## Resolve o AudioStream de uma fase (oficial: res://; do usuario: biblioteca -> copia local ou referencia).
func stream_for_map(m: Dictionary) -> Dictionary:
	var a: Dictionary = m.get("audio", {})
	if a.has("file") and String(a["file"]).begins_with("res://"):
		return MusicImporter.load_stream(String(a["file"]))
	var song: Dictionary = SaveManager.get_song(String(m.get("song_id", "")))
	if song.is_empty():
		return {"ok": false, "error": "musica da fase nao esta na biblioteca"}
	for p in [song.get("local", ""), song.get("path", "")]:
		if String(p) != "" and FileAccess.file_exists(String(p)):
			var r := MusicImporter.load_stream(String(p))
			if r["ok"]:
				return r
	return {"ok": false, "error": "arquivo de audio nao encontrado. Selecione-o novamente em Minhas musicas.", "relink": song["id"]}


## Inicia uma fase. opts: practice(bool), preview(bool), replay(ReplayManager), start_t(float), official(bool)
func start_level(m: Dictionary, opts: Dictionary = {}) -> void:
	var st := stream_for_map(m)
	if not st["ok"]:
		toast(String(st["error"]))
		if st.has("relink"):
			goto("songs", {"relink": st["relink"]})
		return
	var args := {"map": m, "stream": st["stream"], "opts": opts}
	last_play_args = args
	var mode := String(m.get("mode", "geometry_run"))
	goto("rhythm" if mode == "magic_rhythm" else "geometry", args)


func finish_level(result: Dictionary, args: Dictionary) -> void:
	AudioManager.stop()
	AudioManager.player.pitch_scale = 1.0
	goto("results", {"result": result, "play_args": args})


func official_levels() -> Array:
	var idx: Variant = RD.read_json("res://data/levels/index.json")
	return idx["levels"] if idx is Dictionary else []


func load_official(entry: Dictionary) -> Dictionary:
	var d: Variant = RD.read_json(String(entry["file"]))
	return d if d is Dictionary else {}
