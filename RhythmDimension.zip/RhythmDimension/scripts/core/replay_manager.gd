class_name ReplayManager
extends RefCounted
## Replay por eventos de entrada (nao grava video). Como a fisica e deterministica e dirigida pelo relogio de audio,
## re-executar as entradas reconstroi a partida (geometria). Para notas guarda os julgamentos.

var map_id := ""
var seed_value := 0
var inputs: Array = []     # [t, valor]  valor: 1 = pressionou, 0 = soltou (geometria) | [t, lane, tipo] (notas)
var results: Array = []    # julgamentos: [t, lane, "perfect"/...]
var recording := false


func start(id: String, seed_in: int) -> void:
	map_id = id
	seed_value = seed_in
	inputs.clear()
	results.clear()
	recording = true


func add_input(t: float, value: Variant) -> void:
	if recording:
		inputs.append([snappedf(t, 0.001), value])


func add_result(t: float, lane: int, kind: String) -> void:
	if recording:
		results.append([snappedf(t, 0.001), lane, kind])


func stop() -> void:
	recording = false


func save(path: String = "") -> String:
	DirAccess.make_dir_recursive_absolute("user://replays")
	var p := path if path != "" else "user://replays/%s_%d.json" % [map_id, int(Time.get_unix_time_from_system())]
	RD.write_json(p, {"map_id": map_id, "seed": seed_value, "inputs": inputs, "results": results, "version": 1})
	return p


static func load_replay(path: String) -> ReplayManager:
	var d: Variant = RD.read_json(path)
	if d == null:
		return null
	var r := ReplayManager.new()
	r.map_id = d["map_id"]; r.seed_value = int(d["seed"]); r.inputs = d["inputs"]; r.results = d["results"]
	return r


## Estado do botao no instante t (geometria): ultimo evento com tempo <= t.
func hold_at(t: float) -> int:
	var v := 0
	for e in inputs:
		if float(e[0]) <= t:
			v = int(e[1])
		else:
			break
	return v
