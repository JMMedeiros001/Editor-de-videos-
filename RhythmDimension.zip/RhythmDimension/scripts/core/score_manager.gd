class_name ScoreManager
extends RefCounted
## Pontuacao: Perfect/Great/Good/Miss, combo, multiplicador, precisao, classificacao D..SS (criterios fixos).

var perfect := 0
var great := 0
var good := 0
var miss := 0
var combo := 0
var max_combo := 0
var score := 0
var overdrive_until := -1.0

const BASE := {"perfect": 300, "great": 200, "good": 100}
const WEIGHT := {"perfect": 1.0, "great": 0.8, "good": 0.4, "miss": 0.0}


func multiplier(now: float = 0.0) -> int:
	var m: int = 1 + mini(combo / 25, 3)         # x1..x4 (a cada 25 de combo)
	if now < overdrive_until:
		m *= 2
	return m


func hit(kind: String, now: float = 0.0, special: bool = false) -> void:
	match kind:
		"perfect": perfect += 1
		"great": great += 1
		"good": good += 1
	combo += 1
	max_combo = maxi(max_combo, combo)
	var pts: int = int(BASE[kind]) * multiplier(now)
	if special:
		pts = int(pts * 1.5)
		if kind != "good":
			overdrive_until = now + 4.0
	score += pts


func missed() -> void:
	miss += 1
	combo = 0


func total() -> int:
	return perfect + great + good + miss


func accuracy() -> float:
	var t := total()
	if t == 0:
		return 0.0
	return 100.0 * (perfect * 1.0 + great * 0.8 + good * 0.4) / float(t)


## Criterios: SS = 100% sem erros; S >= 95; A >= 90; B >= 80; C >= 70; D < 70.
func rank() -> String:
	var a := accuracy()
	if total() == 0:
		return "D"
	if miss == 0 and good == 0 and great == 0:
		return "SS"
	if a >= 95.0: return "S"
	if a >= 90.0: return "A"
	if a >= 80.0: return "B"
	if a >= 70.0: return "C"
	return "D"


## Geometry Run: classificacao por tentativas (SS = 1a tentativa).
static func rank_by_attempts(attempts: int, completed: bool) -> String:
	if not completed: return "D"
	if attempts <= 1: return "SS"
	if attempts <= 3: return "S"
	if attempts <= 10: return "A"
	if attempts <= 25: return "B"
	if attempts <= 50: return "C"
	return "D"


func to_result(time_s: float) -> Dictionary:
	return {"score": score, "accuracy": snappedf(accuracy(), 0.01), "max_combo": max_combo, "perfect": perfect, "great": great, "good": good,
			"miss": miss, "time": time_s, "rank": rank()}
