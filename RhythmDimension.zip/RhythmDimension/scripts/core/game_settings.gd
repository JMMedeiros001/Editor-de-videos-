extends Node
## Configuracoes persistentes (autoload GameSettings). Salvas em user://settings.json.

signal changed

const PATH := "user://settings.json"
var music_volume := 0.8
var sfx_volume := 0.8
var audio_offset_ms := 0.0      # compensa atraso percebido (positivo = notas "mais tarde")
var latency_ms := 0.0           # latencia extra do aparelho (fone bluetooth etc.)
var sensitivity := 1.0          # largura da janela de acerto: 0.8 mais rigido ... 1.4 mais permissivo
var lanes := 4
var assists := false            # assistencia: perdoa 1 erro por tentativa (nao conta recorde)
var particles := true
var glow := true
var effects_quality := 2        # 0 baixo, 1 medio, 2 alto
var reduce_flashes := false
var reduce_particles := false
var high_contrast := false
var alt_feedback := true        # vibracao como feedback alternativo
var theme := "neon"
var accent := "#00e5ff"
var shape := "cube"
var onboarding_done := false


func _ready() -> void:
	load_settings()


func to_dict() -> Dictionary:
	return {"music_volume": music_volume, "sfx_volume": sfx_volume, "audio_offset_ms": audio_offset_ms, "latency_ms": latency_ms,
			"sensitivity": sensitivity, "lanes": lanes, "assists": assists, "particles": particles, "glow": glow,
			"effects_quality": effects_quality, "reduce_flashes": reduce_flashes, "reduce_particles": reduce_particles,
			"high_contrast": high_contrast, "alt_feedback": alt_feedback, "theme": theme, "accent": accent, "shape": shape,
			"onboarding_done": onboarding_done}


func load_settings() -> void:
	var d: Variant = RD.read_json(PATH)
	if d == null or not (d is Dictionary):
		d = RD.read_json(PATH + ".bak")
	if d == null or not (d is Dictionary):
		return
	for k in (d as Dictionary).keys():
		if k in self:
			set(k, d[k])
	lanes = clampi(int(lanes), 3, 6)
	effects_quality = clampi(int(effects_quality), 0, 2)
	changed.emit()


func save_settings() -> void:
	if FileAccess.file_exists(PATH):
		DirAccess.copy_absolute(PATH, PATH + ".bak")
	RD.write_json(PATH, to_dict())
	changed.emit()


func windows() -> Dictionary:
	# janelas de acerto em segundos (Perfect/Great/Good), escaladas pela sensibilidade
	return {"perfect": 0.045 * sensitivity, "great": 0.090 * sensitivity, "good": 0.135 * sensitivity}
