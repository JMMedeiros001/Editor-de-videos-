class_name RhythmClock
extends RefCounted
## Relogio ritmico: converte tempo de audio em batida/compasso e vice-versa. Fonte de tempo = AudioManager (relogio do audio).

var bpm := 120.0
var offset := 0.0


func _init(bpm_value: float = 120.0, offset_value: float = 0.0) -> void:
	bpm = bpm_value
	offset = offset_value


func beat_len() -> float:
	return 60.0 / bpm


func beat_at(t: float) -> float:
	return (t - offset) / beat_len()


func time_of_beat(b: float) -> float:
	return offset + b * beat_len()


func beat_phase(t: float) -> float:
	return fposmod(beat_at(t), 1.0)


func bar_at(t: float) -> int:
	return int(floor(beat_at(t) / 4.0))


## Pulso 0..1 (1 no instante da batida) - usado por efeitos visuais.
func pulse(t: float) -> float:
	return exp(-5.0 * beat_phase(t))
