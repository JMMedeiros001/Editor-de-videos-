class_name PhysicsModel
extends RefCounted
## Fisica deterministica do jogo + busca de alcancabilidade usada pelo validador.
## PORTA 1:1 de tools/rdtools/sim.py (testado la). O passo (advance) e a unica fonte de verdade tanto para
## o gameplay (geometry_run.gd) quanto para o validador (level_validator.gd).
## Estado: [y, vy, gs(+1 normal/-1 invertida), grounded(0/1), aux, hold_anterior(0/1)]

static var _ok := false
static var DT := 1.0 / 120.0
static var BODY := 0.8
static var HURT := 0.4
static var EPS := 0.12
static var CEIL := 9.0
static var DSTEPS := 4
static var CUBE_G := 80.0
static var CUBE_J := 17.5
static var ROB_G := 70.0
static var ROB_J := 11.5
static var ROB_HA := 48.0
static var ROB_HM := 0.26
static var SHIP_G := 28.0
static var SHIP_T := 42.0
static var SHIP_V := 9.5
static var BALL_G := 60.0
static var BALL_V := 22.0
static var SP_G := 90.0
static var SP_V := 26.0
static var SP_CD := 0.12
static var WAVE_SLOPE := 1.0


static func setup() -> void:
	if _ok:
		return
	var P := RD.physics()
	DT = P["dt"]; BODY = P["body"]; HURT = P["hurt"]; EPS = P["land_eps"]; CEIL = P["ceiling_y"]; DSTEPS = int(P["decision_steps"])
	var F: Dictionary = P["forms"]
	CUBE_G = F["cube"]["gravity"]; CUBE_J = F["cube"]["jump_v"]
	ROB_G = F["robot"]["gravity"]; ROB_J = F["robot"]["jump_v"]; ROB_HA = F["robot"]["hold_accel"]; ROB_HM = F["robot"]["hold_max"]
	SHIP_G = F["ship"]["gravity"]; SHIP_T = F["ship"]["thrust"]; SHIP_V = F["ship"]["vmax"]
	BALL_G = F["ball"]["gravity"]; BALL_V = F["ball"]["vmax"]
	SP_G = F["spider"]["gravity"]; SP_V = F["spider"]["vmax"]; SP_CD = F["spider"]["cooldown"]
	WAVE_SLOPE = F["wave"]["slope"]
	_ok = true


static func initial_state(L: RhythmMap) -> Array:
	setup()
	var ev: Dictionary = L.fe[0]
	return [0.0, 0.0, int(ev.get("gs", 1)), 1, 0.0, 0]


static func _adapt(s: Array, ev: Dictionary, prev_form: int) -> Array:
	var y: float = s[0]
	var vy: float = s[1]
	var form: int = RD.FORM_NAMES.find(String(ev["form"]))
	var gs: int = int(ev.get("gs", s[2]))
	var has_ceil: bool = ev.get("ceiling", not (form == RD.FORM_CUBE or form == RD.FORM_ROBOT))
	if has_ceil and y + BODY > CEIL:
		y = CEIL - BODY
	if form != prev_form:
		vy = 0.0
	var aux: float = ROB_HM if form == RD.FORM_ROBOT else 0.0
	return [y, vy, gs, 0, aux, s[5]]


## Avanca um substep. Retorna o novo estado, ou null se o jogador morreu.
static func advance(L: RhythmMap, i: int, s: Array, hold: int) -> Variant:
	var y: float = s[0]
	var vy: float = s[1]
	var gs: int = s[2]
	var gr: int = s[3]
	var aux: float = s[4]
	var ph: int = s[5]
	var ev: Variant = L.ev_at[i + 1]
	if ev != null:
		var s2 := _adapt(s, ev, L.form_at[i])
		y = s2[0]; vy = s2[1]; gs = s2[2]; gr = s2[3]; aux = s2[4]
	var form: int = L.form_at[i + 1]
	if form == RD.FORM_LANES:
		return [0.0, 0.0, 1, 1, 0.0, 0]
	var x1: float = L.xs[i + 1]
	var cv: float = L.ceil_at[i + 1]
	var has_ceil: bool = cv >= 0.0
	var held: bool = hold == 1
	var pressed: bool = held and ph == 0
	var bt: float = y
	var tp: float = y + BODY

	if form == RD.FORM_CUBE:
		if gr == 1 and held:
			vy = CUBE_J * gs
		vy -= CUBE_G * gs * DT
	elif form == RD.FORM_ROBOT:
		if gr == 1 and held:
			vy = ROB_J * gs
			aux = 0.0
		elif gr == 0 and held and aux < ROB_HM and vy * gs > 0.0:
			vy += ROB_HA * gs * DT
			aux += DT
		elif not held:
			aux = ROB_HM
		vy -= ROB_G * gs * DT
	elif form == RD.FORM_SHIP:
		vy += gs * (-SHIP_G + (SHIP_T if held else 0.0)) * DT
		vy = clampf(vy, -SHIP_V, SHIP_V)
	elif form == RD.FORM_BALL:
		if gr == 1 and pressed:
			gs = -gs
			gr = 0
			vy = 0.0
		vy -= BALL_G * gs * DT
		vy = clampf(vy, -BALL_V, BALL_V)
	elif form == RD.FORM_SPIDER:
		aux = aux - DT if aux > DT else 0.0
		if gr == 1 and pressed and aux <= 0.0 and has_ceil:
			if gs == 1:
				y = cv - BODY
				gs = -1
			else:
				y = 0.0
				gs = 1
			vy = 0.0
			gr = 1
			aux = SP_CD
			bt = y
			tp = y + BODY
		vy -= SP_G * gs * DT
		vy = clampf(vy, -SP_V, SP_V)
	else:
		var sp: float = (L.xs[i + 1] - L.xs[i]) / DT
		vy = (1.0 if held else -1.0) * gs * WAVE_SLOPE * sp

	var yn: float = y + vy * DT
	var gr2: int = 0
	var slide: bool = form == RD.FORM_SHIP or form == RD.FORM_WAVE
	if yn < 0.0:
		yn = 0.0
		if slide:
			if vy < 0.0:
				vy = 0.0
		elif gs == 1:
			gr2 = 1
			vy = 0.0
		elif vy < 0.0:
			vy = 0.0
	if has_ceil and yn + BODY > cv:
		yn = cv - BODY
		if slide:
			if vy > 0.0:
				vy = 0.0
		elif gs == -1:
			gr2 = 1
			vy = 0.0
		elif vy > 0.0:
			vy = 0.0

	# solidos
	var c0: int = int(floor(x1))
	var c1: int = int(floor(x1 + BODY))
	var cand: Array = []
	for c in range(c0, c1 + 1):
		if L.sol_cols.has(c):
			cand = cand + L.sol_cols[c]
	if not cand.is_empty():
		var seen: Dictionary = {}
		for idx in cand:
			if seen.has(idx):
				continue
			seen[idx] = true
			var sd: Array = L.solids[idx]
			if x1 + BODY <= sd[0] or x1 >= sd[2]:
				continue
			if yn + BODY <= sd[1] or yn >= sd[3]:
				continue
			if form == RD.FORM_WAVE:
				return null
			var res: bool = false
			if vy <= 0.0 and bt >= sd[3] - EPS and (gs == 1 or form == RD.FORM_SHIP):
				yn = sd[3]
				vy = 0.0
				res = true
				if form != RD.FORM_SHIP and gs == 1:
					gr2 = 1
			elif vy >= 0.0 and tp <= sd[1] + EPS and (gs == -1 or form == RD.FORM_SHIP):
				yn = sd[1] - BODY
				vy = 0.0
				res = true
				if form != RD.FORM_SHIP and gs == -1:
					gr2 = 1
			if not res:
				return null

	# espinhos (hurtbox menor que o corpo)
	if not L.spk_cols.is_empty():
		var cxl: float = x1 + (BODY - HURT) / 2.0
		var cxr: float = cxl + HURT
		var cyb: float = yn + (BODY - HURT) / 2.0
		var cyt: float = cyb + HURT
		for c in range(int(floor(cxl)), int(floor(cxr)) + 1):
			if L.spk_cols.has(c):
				for idx in L.spk_cols[c]:
					var sk: Array = L.spikes[idx]
					if cxr > sk[0] and cxl < sk[2] and cyt > sk[1] and cyb < sk[3]:
						return null
	return [yn, vy, gs, gr2, aux, (1 if held else 0)]


static func _key(s: Array, form: int) -> int:
	var ky: int = int(s[0] * 24.0)
	var kvy: int = int(s[1] * 2.0)
	var g: int = 1 if int(s[2]) == 1 else 0
	var kp: int = int(s[5]) if (form == RD.FORM_BALL or form == RD.FORM_SPIDER) else 0
	var ka: int = mini(int(s[4] * 30.0), 63)
	return (((((ky + 1000) * 2000 + kvy + 1000) * 2 + g) * 2 + int(s[3])) * 64 + ka) * 2 + kp


## Busca: existe trajetoria que conclui a fase? Entradas a 30 Hz. Qualquer caminho encontrado e real.
## Retorna {ok, t_fail, truncated, max_frontier, t_reached}. 'progress' recebe 0..1 (opcional).
## stop_at_t >= 0 limita a busca (usado na previa: valida somente ate esse instante).
static func search(L: RhythmMap, beam: int = 1200, progress: Callable = Callable(), stop_at_t: float = -1.0) -> Dictionary:
	setup()
	var res := {"ok": false, "t_fail": -1.0, "truncated": false, "max_frontier": 0, "t_reached": 0.0}
	var s0: Array = initial_state(L)
	var frontier: Dictionary = {_key(s0, L.form_at[0]): s0}
	var total_d: int = int(ceil(float(L.nsteps - 1) / float(DSTEPS)))
	for d in range(total_d):
		var i0: int = d * DSTEPS
		var t_now: float = float(i0) * DT
		res["t_reached"] = t_now
		if L.xs[i0] >= L.end_x or (stop_at_t >= 0.0 and t_now >= stop_at_t):
			res["ok"] = true
			return res
		var form: int = L.form_at[mini(i0 + DSTEPS, L.form_at.size() - 1)]
		var nw: Dictionary = {}
		for s in frontier.values():
			for hold in [0, 1]:
				var st: Variant = s
				for k in range(DSTEPS):
					st = advance(L, i0 + k, st, hold)
					if st == null:
						break
				if st == null:
					continue
				var kk: int = _key(st, form)
				if not nw.has(kk):
					nw[kk] = st
		if nw.is_empty():
			res["t_fail"] = t_now
			return res
		if nw.size() > beam:
			res["truncated"] = true
			var keys: Array = nw.keys()
			keys.sort()
			var stepf: float = float(keys.size()) / float(beam)
			var cut: Dictionary = {}
			for j in range(beam):
				var kj: int = keys[int(float(j) * stepf)]
				cut[kj] = nw[kj]
			nw = cut
		if nw.size() > int(res["max_frontier"]):
			res["max_frontier"] = nw.size()
		frontier = nw
		if progress.is_valid() and d % 60 == 0:
			progress.call(clampf(t_now / L.end_t, 0.0, 1.0))
	res["ok"] = true
	return res
