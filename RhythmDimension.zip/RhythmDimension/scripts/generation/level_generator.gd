class_name LevelGenerator
extends RefCounted
## Gerador procedural. PORTA de tools/rdtools/generator.py (mesma ordem de consumo do PRNG => mesma fase para a mesma seed).
## Nao copia fases comerciais: usa padroes proprios (data/patterns.json) combinados/variados sobre a analise da musica.

const SILENCE := 0.05


class Gen:
	var an: Dictionary
	var diff: Dictionary
	var style: String
	var seed_value: int
	var ramp: Callable
	var use_ramp := false
	var rng: Rng
	var beat: float
	var bar_len: float
	var off: float
	var lane_bars: Dictionary = {}
	var blocked: Dictionary = {}
	var objs: Array = []
	var fev: Array = [{"t": 0.0, "form": "cube", "gs": 1, "ceiling": false}]
	var insts: Array = []
	var tl: RhythmMap

	func grid(b: float) -> float:
		return off + b * beat

	func dd(bar: int) -> Dictionary:
		if use_ramp:
			return RD.difficulty(String(ramp.call(bar)[0]))
		return diff

	func speed_for_bar(bar: int) -> float:
		var d := dd(bar)
		var sv := RD.speed_value(d)
		if use_ramp:
			sv *= float(ramp.call(bar)[1])
		if style == "speed":
			sv *= 1.08
		return sv


# ------------------------------------------------------------------ analise
static func energy_at(an: Dictionary, t: float) -> float:
	var be: Array = an["bar_energy"]
	if be.is_empty():
		return 0.5
	var k: int = int(floor((t - float(an["offset"])) / float(an["bar_len"])))
	return float(be[clampi(k, 0, be.size() - 1)])


static func _onset_times(an: Dictionary) -> PackedFloat64Array:
	if not an.has("_onset_t"):
		var a := PackedFloat64Array()
		for o in an["onsets"]:
			a.append(float(o["t"]))
		an["_onset_t"] = a
	return an["_onset_t"]


static func _bisect_left(arr: PackedFloat64Array, v: float) -> int:
	var lo := 0
	var hi := arr.size()
	while lo < hi:
		var mid := (lo + hi) >> 1
		if arr[mid] < v:
			lo = mid + 1
		else:
			hi = mid
	return lo


static func onset_near(an: Dictionary, t: float, tol: float = 0.05) -> float:
	var ot := _onset_times(an)
	var i := _bisect_left(ot, t - tol)
	var best := 0.0
	while i < ot.size() and ot[i] <= t + tol:
		best = maxf(best, float(an["onsets"][i]["s"]))
		i += 1
	return best


static func band_near(an: Dictionary, t: float, tol: float = 0.06) -> int:
	var ot := _onset_times(an)
	var i := _bisect_left(ot, t - tol)
	var best := -1.0
	var band := 1
	while i < ot.size() and ot[i] <= t + tol:
		if float(an["onsets"][i]["s"]) > best:
			best = float(an["onsets"][i]["s"])
			band = int(an["onsets"][i]["b"])
		i += 1
	return band


static func trim_analysis(an: Dictionary, a: float, b: float) -> Dictionary:
	var beat: float = 60.0 / float(an["bpm"])
	var new_off: float = fposmod(float(an["offset"]) - a, beat)
	var n_b: int = int(floor((b - a - new_off) / (4.0 * beat))) + 1
	var bars: Array = []
	for k in range(maxi(n_b, 1)):
		bars.append(energy_at(an, a + new_off + (float(k) + 0.5) * 4.0 * beat))
	var ons: Array = []
	for o in an["onsets"]:
		if float(o["t"]) >= a and float(o["t"]) <= b:
			var c: Dictionary = (o as Dictionary).duplicate()
			c["t"] = snappedf(float(o["t"]) - a, 0.0001)
			ons.append(c)
	return {"bpm": an["bpm"], "offset": new_off, "duration": b - a, "bar_len": 4.0 * beat, "bar_energy": bars, "onsets": ons,
			"confidence": an.get("confidence", 0.0), "audio_start": a}


static func synthetic_analysis(bpm: float, bars: int, ramp_to_full: bool = false) -> Dictionary:
	var beat := 60.0 / bpm
	var be: Array = []
	for k in range(bars):
		be.append(minf(1.0, 0.6 + 0.4 * minf(float(k), 24.0) / 24.0) if ramp_to_full else 0.8)
	var ons: Array = []
	for q in range(bars * 4):
		ons.append({"t": snappedf(float(q) * beat, 0.0001), "s": 1.5 if q % 4 == 0 else 1.0, "b": 0})
	return {"bpm": bpm, "offset": 0.0, "duration": float(bars) * 4.0 * beat + 1.0, "bar_len": 4.0 * beat, "bar_energy": be, "onsets": ons, "confidence": 1.0}


# ------------------------------------------------------------------ geometria
static func _timeline(sev: Array) -> RhythmMap:
	return RhythmMap.from_dict({"speed_events": sev, "form_events": [], "objects": [], "end_t": 1.0})


static func _weight(p: Dictionary, style: String, dd: Dictionary, rng: Rng) -> float:
	var w: float = float(p.get("weight", 1.0))
	var k: String = p["kind"]
	if style == "variations" and k != "static":
		w *= 1.6
	if style == "precision" and ["Pattern_Platform_08", "Pattern_Stair_05", "Pattern_SpikeBlock_06", "Pattern_Block_03"].has(p["id"]):
		w *= 1.8
	if style == "obstacles" and k == "static":
		w *= 1.2
	if int(p["tier"]) == int(dd["tier"]) and int(p["tier"]) >= 2:
		w *= 1.8
	elif int(p["tier"]) < int(dd["tier"]) - 1:
		w *= 0.5
	if style == "random":
		w *= 0.4 + 1.2 * rng.f()
	return w


static func _runs(bars: Array) -> Array:
	var runs: Array = []
	for b in bars:
		if not runs.is_empty() and int(b) == int(runs[runs.size() - 1][1]) + 1:
			runs[runs.size() - 1][1] = int(b)
		else:
			runs.append([int(b), int(b)])
	return runs


static func _plan_speed(g: Gen, first_bar: int, last_bar: int) -> Array:
	var ev: Array = []
	var cur: float = -1.0
	var zone: Dictionary = {}
	var d0: Dictionary = g.diff
	if not g.use_ramp and (int(d0["tier"]) >= 3 or (int(d0["tier"]) == 2 and g.style == "speed")):
		var b := first_bar + 2
		while b < last_bar - 6:
			if energy_at(g.an, g.grid(float(b * 4)) + g.bar_len / 2.0) >= 0.8:
				var n := 0
				while b + n < last_bar - 2 and energy_at(g.an, g.grid(float((b + n) * 4)) + g.bar_len / 2.0) >= 0.8:
					n += 1
				if n >= 4 and g.rng.f() < (0.55 if int(d0["tier"]) >= 3 else 0.3):
					for k in range(n):
						zone[b + k] = 1.2
					b += n + 1
					continue
				b += maxi(n, 1)
			else:
				b += 1
	for b2 in range(0, last_bar + 2):
		var sv: float = snappedf(g.speed_for_bar(b2) * float(zone.get(b2, 1.0)), 0.001)
		if cur < 0.0:
			ev.append({"t": 0.0, "speed": sv})
			cur = sv
		elif absf(sv - cur) > 1e-6:
			ev.append({"t": snappedf(g.grid(float(b2 * 4)), 0.0001), "speed": sv, "portal": true})
			cur = sv
	return ev


static func _obj(typ: String, x: float, y: float, inst: int, extra: Dictionary = {}) -> Dictionary:
	var o := {"type": typ, "x": snappedf(x, 0.001), "y": y, "inst": inst}
	for k in extra.keys():
		o[k] = extra[k]
	return o


static func _inst_static(g: Gen, p: Dictionary, anchor: float, dd: Dictionary, k: int) -> Array:
	var beat := g.beat
	var objs: Array = p["objects"]
	var stretch := 1.0
	var bs: Array = []
	for o in objs:
		if not bs.has(float(o["beat"])):
			bs.append(float(o["beat"]))
	bs.sort()
	var mg: float = -1.0
	for j in range(bs.size() - 1):
		var gap: float = bs[j + 1] - bs[j]
		if mg < 0.0 or gap < mg:
			mg = gap
	if mg > 0.0:
		stretch = maxf(1.0, float(dd["min_gap_s"]) / (mg * beat))
		if int(dd["tier"]) >= 2 and g.rng.f() < 0.35:
			stretch = maxf(stretch, 1.25)
	var out: Array = []
	var t_end := 0.0
	for o in objs:
		var sb: float = ceil(float(o["beat"]) * stretch * 4.0 - 1e-9) / 4.0
		var t: float = g.grid(anchor + sb)
		var x: float = g.tl.x_at(t) + float(o["dx"])
		var w := 1.0
		if o["type"] == "spike":
			out.append(_obj("spike", x, float(o.get("y", 0)), k))
		else:
			out.append(_obj("block", x, float(o.get("y", 0)), k, {"w": o["w"], "h": o["h"]}))
			w = float(o["w"])
		t_end = maxf(t_end, g.tl.t_at(x + w))
	return [out, [], g.grid(anchor), t_end]


static func _corridor(g: Gen, p: Dictionary, anchor: float, dd: Dictionary, k: int, wave: bool) -> Array:
	var beat := g.beat
	var par: Dictionary = p["params"]
	var nb: int = g.rng.rng_i(int(par["beats"][0]), int(par["beats"][1]))
	nb = maxi(4, (nb / 2) * 2)
	var t_in: float = g.grid(anchor)
	var t_out: float = g.grid(anchor + float(nb))
	var gap_i: int = int(ceil(float(dd["ship_gap"])))
	if wave:
		gap_i = maxi(gap_i, 4)
	var amp: float = float(par["amp"]) * (0.6 if int(dd["tier"]) <= 1 else (1.0 if int(dd["tier"]) <= 3 else 1.15))
	var period: float = float(par["period_beats"]) * beat
	var W := 1.0 if wave else 2.0
	var x0: float = g.tl.x_at(t_in + 1.5 * beat)
	var x1: float = g.tl.x_at(t_out - 1.0 * beat)
	var ceil_y: float = float(RD.physics()["ceiling_y"])
	var out: Array = []
	var x := x0
	var t_c0: float = t_in + 1.5 * beat
	var t_c1: float = t_out - 1.0 * beat
	while x < x1:
		var t: float = g.tl.t_at(x)
		var ramp_v: float = minf(1.0, (t - t_c0) / (2.0 * beat)) * minf(1.0, (t_c1 - t) / (2.0 * beat))
		ramp_v = maxf(ramp_v, 0.0)
		var ph: float = (t - t_c0) / period
		var c: float
		if wave:
			var tri: float = absf(2.0 * (ph - floor(ph + 0.5)))
			c = float(gap_i) / 2.0 + amp * tri * ramp_v
		else:
			c = float(gap_i) / 2.0 + amp * (1.0 - cos(TAU * ph)) / 2.0 * ramp_v
		var hf: int = int(floor(c - float(gap_i) / 2.0 + 0.5))
		hf = maxi(0, mini(hf, int(ceil_y) - gap_i - 1))
		var top: int = hf + gap_i
		if hf >= 1:
			out.append(_obj("block", x, 0.0, k, {"w": W, "h": float(hf)}))
		if ceil_y - float(top) >= 1.0:
			out.append(_obj("block", x, float(top), k, {"w": W, "h": ceil_y - float(top)}))
		x += W
	var form := "wave" if wave else "ship"
	var fe: Array = [{"t": snappedf(t_in, 0.0001), "form": form, "gs": 1, "ceiling": true, "portal": true, "inst": k},
			{"t": snappedf(t_out, 0.0001), "form": "cube", "gs": 1, "ceiling": false, "portal": true, "inst": k}]
	return [out, fe, t_in, t_out + 0.45]


static func _flips(g: Gen, p: Dictionary, anchor: float, dd: Dictionary, k: int, spider: bool) -> Array:
	var beat := g.beat
	var par: Dictionary = p["params"]
	var n: int = g.rng.rng_i(int(par["count"][0]), int(par["count"][1]))
	var sp_b: float = g.rng.rng_f(float(par["spacing_beats"][0]), float(par["spacing_beats"][1]))
	var t_in: float = g.grid(anchor)
	var v: float = g.tl.speed_at(t_in)
	var min_blocks := 4.0 if spider else 7.0
	var need_beats: float = (min_blocks / v) / beat
	var need_gap_b: float = float(dd["min_gap_s"]) / beat
	sp_b = ceil(maxf(maxf(sp_b, need_beats), need_gap_b) * 2.0) / 2.0
	var ceil_y: float = float(RD.physics()["ceiling_y"])
	var out: Array = []
	var t: float = t_in + sp_b * beat
	for j in range(n):
		var x: float = g.tl.x_at(t)
		if j % 2 == 0:
			out.append(_obj("spike", x, 0.0, k))
		else:
			out.append(_obj("spike", x, ceil_y - 1.0, k, {"flip": true}))
		t += sp_b * beat
	var form := "spider" if spider else "ball"
	var fe: Array = [{"t": snappedf(t_in, 0.0001), "form": form, "gs": 1, "ceiling": true, "portal": true, "inst": k},
			{"t": snappedf(t, 0.0001), "form": "cube", "gs": 1, "ceiling": false, "portal": true, "inst": k}]
	return [out, fe, t_in, t + 0.5]


static func _robot(g: Gen, p: Dictionary, anchor: float, dd: Dictionary, k: int) -> Array:
	var beat := g.beat
	var par: Dictionary = p["params"]
	var n: int = g.rng.rng_i(int(par["count"][0]), int(par["count"][1]))
	var sp_b: float = g.rng.rng_f(float(par["spacing_beats"][0]), float(par["spacing_beats"][1]))
	sp_b = ceil(maxf(sp_b, float(dd["min_gap_s"]) / beat) * 2.0) / 2.0
	var t_in: float = g.grid(anchor)
	var out: Array = []
	var t: float = t_in + sp_b * beat
	for j in range(n):
		out.append(_obj("block", g.tl.x_at(t), 0.0, k, {"w": 1, "h": 2}))
		t += sp_b * beat
	var fe: Array = [{"t": snappedf(t_in, 0.0001), "form": "robot", "gs": 1, "ceiling": false, "portal": true, "inst": k},
			{"t": snappedf(t + 0.3, 0.0001), "form": "cube", "gs": 1, "ceiling": false, "portal": true, "inst": k}]
	return [out, fe, t_in, t + 0.8]


static func _finale(g: Gen, p: Dictionary, anchor: float, dd: Dictionary, k: int) -> Array:
	var beat := g.beat
	var par: Dictionary = p["params"]
	var n: int = g.rng.rng_i(int(par["hops"][0]), int(par["hops"][1]))
	n = mini(n + (int(dd["tier"]) - 1) / 2, 6)
	var sp := 2.0
	var b: float = anchor
	var out: Array = []
	var t_end := 0.0
	for j in range(n):
		var x: float = g.tl.x_at(g.grid(b))
		if j == n - 1 and int(dd["tier"]) >= 2:
			for dx in range(3):
				out.append(_obj("spike", x + float(dx), 0.0, k))
			t_end = g.tl.t_at(x + 3.0)
		else:
			out.append(_obj("spike", x, 0.0, k))
			t_end = g.tl.t_at(x + 1.0)
		var floor_b: float = maxf(1.0, ceil(float(dd["min_gap_s"]) / beat * 4.0) / 4.0)
		sp = maxf(floor_b, sp - 0.25)
		b += sp
	return [out, [], g.grid(anchor), t_end]


static func _instantiate(g: Gen, p: Dictionary, anchor: float, dd: Dictionary, k: int) -> Variant:
	match String(p["kind"]):
		"static": return _inst_static(g, p, anchor, dd, k)
		"corridor_ship": return _corridor(g, p, anchor, dd, k, false)
		"corridor_wave": return _corridor(g, p, anchor, dd, k, true)
		"flip_ball": return _flips(g, p, anchor, dd, k, false)
		"flip_spider": return _flips(g, p, anchor, dd, k, true)
		"robot_blocks": return _robot(g, p, anchor, dd, k)
		"finale": return _finale(g, p, anchor, dd, k)
	return null


static func _eligible(g: Gen, dd: Dictionary, tier_cap: int, allow_forms: bool, bpm: float, dname: String) -> Array:
	var res: Array = []
	for p in RD.patterns():
		if p["mode"] != "geometry_run":
			continue
		if int(p["tier"]) > tier_cap or p["kind"] == "finale":
			continue
		if p["form"] != "cube" and (not allow_forms or not (dd["forms"] as Array).has(p["form"])):
			continue
		if p["kind"] == "static" and int(p["tier"]) > int(dd["tier"]):
			continue
		if not RD.pattern_ok(String(p["id"]), bpm, dname):
			continue
		res.append(p)
	return res


static func generate_geometry(an: Dictionary, diff: Dictionary, style: String = "balanced", seed_value: int = 1, level_name: String = "Fase gerada",
		ramp: Callable = Callable(), lane_bars: Array = [], blocked_bars: Array = [], allow_forms: bool = true,
		mode: String = "geometry_run", level_id: String = "") -> Dictionary:
	var g := Gen.new()
	g.an = an; g.diff = diff; g.style = style; g.seed_value = seed_value
	g.ramp = ramp; g.use_ramp = ramp.is_valid()
	g.rng = Rng.new(seed_value)
	g.beat = 60.0 / float(an["bpm"])
	g.bar_len = 4.0 * g.beat
	g.off = float(an["offset"])
	for b in lane_bars:
		g.lane_bars[int(b)] = true
	for b in blocked_bars:
		g.blocked[int(b)] = true
	var beat := g.beat
	var bar_len := g.bar_len
	var off := g.off
	var end_t: float = float(an["duration"]) - 0.4
	var n_full: int = int(floor((end_t - off) / bar_len))
	var first_bar: int = maxi(0, int(ceil((float(diff["lead_in_s"]) - off) / bar_len)))
	var last_bar: int = n_full - 1
	var z: int = last_bar - 1
	var sev: Array = _plan_speed(g, first_bar, last_bar)
	g.tl = _timeline(sev)
	var rng := g.rng
	var last_end := 0.0
	var last_form_bar := -99
	var n_active: int = maxi(z - first_bar + 1, 1)
	var finale_done := false
	var lane_keys: Array = g.lane_bars.keys()
	lane_keys.sort()
	var lane_runs: Array = _runs(lane_keys)
	var lane_starts: Array = []
	for r in lane_runs:
		lane_starts.append(g.grid(float(int(r[0]) * 4)))
	for b in range(first_bar, z + 1):
		if g.blocked.has(b) or g.lane_bars.has(b):
			continue
		var dd: Dictionary = g.dd(b)
		var t_bar: float = g.grid(float(b * 4))
		var I: float = energy_at(an, t_bar + bar_len / 2.0)
		if I < SILENCE:
			continue
		var prog: float = float(b - first_bar) / float(n_active)
		var intro: bool = prog < 0.10
		var is_finale: bool = (b >= z - 1) and not g.use_ramp and n_active >= 8
		var tier_cap: int = 1 if intro else int(dd["tier"])
		var pd: float = float(dd["density"]) * (0.35 + 0.9 * I)
		if style == "obstacles":
			pd *= 1.2
		if style == "random":
			pd *= 0.75 + 0.5 * rng.f()
		if intro:
			pd *= 0.5
		pd = minf(pd, 0.97)
		if is_finale and not finale_done:
			pd = 1.0
		if rng.f() > pd:
			continue
		var dname: String = String(dd["name"])
		var bpm: float = float(an["bpm"])
		var cands: Array = []
		if is_finale and not finale_done:
			for p in RD.patterns():
				if p["kind"] == "finale":
					cands.append(p)
		else:
			var el := _eligible(g, dd, tier_cap, allow_forms and not intro, bpm, dname)
			for p in el:
				if p["form"] != "cube":
					if I < 0.45 or (b - last_form_bar) < 3 or b > z - 3:
						continue
				cands.append(p)
		if cands.is_empty():
			continue
		var ws: Array = []
		for p in cands:
			var w: float = _weight(p, style, dd, rng)
			if p["form"] != "cube":
				w *= 0.55 if style != "variations" else 1.2
			ws.append(w)
		var p_sel: Dictionary = rng.weighted(cands, ws)
		var earliest: float = last_end + float(dd["min_gap_s"])
		if last_form_bar == b - 1 or (not g.insts.is_empty() and g.insts[g.insts.size() - 1]["form"] != "cube" and g.grid(float(b * 4)) - last_end < 0.2):
			earliest += 0.3
		var steps: Array = [0.0, 1.0, 2.0, 3.0]
		if int(dd["tier"]) >= 3:
			steps.append_array([0.5, 1.5, 2.5, 3.5])
		var opts: Array = []
		var wts: Array = []
		var len_s: float = float(p_sel["length_beats"]) * beat
		for q in steps:
			var tq: float = g.grid(float(b * 4) + float(q))
			if tq < earliest or tq + len_s > end_t - 1.2:
				continue
			var nb: int = int(floor((tq - off) / bar_len))
			if g.lane_bars.has(nb + 1) or (g.lane_bars.has(b + 1) and float(q) >= 3.0):
				continue
			opts.append(q)
			wts.append(0.15 + onset_near(an, tq, 0.06))
		if opts.is_empty():
			continue
		var qsel: float = float(rng.weighted(opts, wts))
		var anchor: float = float(b * 4) + qsel
		var k: int = g.insts.size()
		var res: Variant = _instantiate(g, p_sel, anchor, dd, k)
		if res == null:
			continue
		var t0: float = res[2]
		var t1: float = res[3]
		if t1 > end_t - 1.1:
			continue
		var crosses := false
		for ls in lane_starts:
			if t0 < float(ls) and float(ls) < t1 + 0.5:
				crosses = true
		if crosses:
			continue
		g.objs.append_array(res[0])
		g.fev.append_array(res[1])
		g.insts.append({"k": k, "pattern": p_sel["id"], "kind": p_sel["kind"], "form": p_sel["form"], "t0": snappedf(t0, 0.001),
				"t1": snappedf(t1, 0.001), "bar": b, "tier": p_sel["tier"], "anchor": anchor, "fixed": false})
		last_end = t1
		if p_sel["form"] != "cube":
			last_form_bar = b
		if p_sel["kind"] == "finale":
			finale_done = true
	for r in lane_runs:
		g.fev.append({"t": snappedf(g.grid(float(int(r[0]) * 4)), 0.0001), "form": "lanes", "gs": 1, "ceiling": false, "portal": true, "lanes": true})
		g.fev.append({"t": snappedf(g.grid(float((int(r[1]) + 1) * 4)), 0.0001), "form": "cube", "gs": 1, "ceiling": false, "portal": true})
	g.fev.sort_custom(func(a, b): return float(a["t"]) < float(b["t"]))
	g.objs.sort_custom(func(a, b): return float(a["x"]) < float(b["x"]))
	var m := {"format": 1, "id": level_id if level_id != "" else "gen_%d_%s_%d" % [int(round(float(an["bpm"]))), style, seed_value],
			"name": level_name, "mode": mode, "difficulty": diff["name"], "style": style, "seed": seed_value, "generator_version": RD.GENERATOR_VERSION,
			"audio": {"bpm": an["bpm"], "offset": snappedf(off, 0.0001), "duration": snappedf(float(an["duration"]), 0.001),
					"start": an.get("audio_start", 0.0), "confidence": an.get("confidence", 0.0)},
			"speed_events": sev, "form_events": g.fev, "objects": g.objs, "notes": [], "lanes": 0, "instances": g.insts,
			"end_t": snappedf(end_t, 0.001), "status": "GENERATING"}
	m["checkpoints"] = _checkpoints(m, g)
	return m


static func _checkpoints(m: Dictionary, g: Gen) -> Array:
	var cps: Array = []
	var last := 0.0
	var b := 1
	while g.grid(float(b * 4)) < float(m["end_t"]) - 3.0:
		var t: float = g.grid(float(b * 4))
		var near := false
		for i in m["instances"]:
			if float(i["t0"]) - 1.0 <= t and t <= float(i["t1"]) + 1.0:
				near = true
		if not near and t - last >= 8.0:
			cps.append(snappedf(t, 0.001))
			last = t
		b += 1
	return cps


# ------------------------------------------------------------------ notas (Magic Rhythm e trechos de notas do Music Dash)
static func generate_notes(an: Dictionary, diff: Dictionary, style: String = "balanced", seed_value: int = 1, lanes_in: int = -1,
		level_name: String = "Fase gerada", bars_only: Array = [], kinds_in: Array = [], nps_scale: float = 1.0, level_id: String = "",
		mode: String = "magic_rhythm") -> Dictionary:
	var rng := Rng.new((seed_value ^ 0x5BD1E995) & 0xFFFFFFFF)
	var nd: Dictionary = diff["notes"]
	var lanes: int = lanes_in
	if lanes < 0:
		lanes = int(nd["lanes"][(nd["lanes"] as Array).size() / 2])
	lanes = 3 if mode == "music_dash" else clampi(lanes, 3, 6)
	var beat: float = 60.0 / float(an["bpm"])
	var off: float = float(an["offset"])
	var end_t: float = float(an["duration"]) - 0.4
	var first_t: float = float(diff["lead_in_s"])
	var kinds: Array = kinds_in if not kinds_in.is_empty() else (nd["kinds"] as Array)
	var tier: int = int(diff["tier"])
	var cap: float = float(nd["max_nps"]) * 0.88 * nps_scale
	if style == "notes":
		cap *= 1.12
	var lane_gap: float = float(nd["lane_gap_s"])
	var subs_tbl := {1: [0.0], 2: [0.0, 0.5], 3: [0.0, 0.5], 4: [0.0, 0.25, 0.5, 0.75], 5: [0.0, 0.25, 0.5, 0.75]}
	var subs: Array = subs_tbl[mini(tier, 5)]
	if tier == 1 and String(diff["name"]) == "beginner":
		subs = [0.0, 0.5]
	var notes: Array = []
	var recent: Array = []
	var lane_last: Dictionary = {}
	var hold_busy: Dictionary = {}
	var last_lane: int = lanes / 2
	var n_beats: int = int(floor((end_t - 1.0 - off) / beat))
	var thr_shift: float = (-0.15 if style == "notes" else 0.0) - 0.12 * float(maxi(tier - 2, 0))
	var bars_set: Dictionary = {}
	for b in bars_only:
		bars_set[int(b)] = true
	var bi := 0
	while bi < n_beats:
		var t_beat: float = off + float(bi) * beat
		var bar: int = bi / 4
		if t_beat < first_t - 0.01 or (not bars_only.is_empty() and not bars_set.has(bar)):
			bi += 1
			continue
		var I: float = energy_at(an, t_beat)
		if I < SILENCE:
			bi += 1
			continue
		for s in subs:
			var t: float = t_beat + float(s) * beat
			if t < first_t or t > end_t - 1.0:
				continue
			var st: float = onset_near(an, t, 0.05)
			var score: float = st + (0.5 if float(s) == 0.0 else 0.0) + (0.2 if float(s) == 0.5 else 0.0)
			var thr: float = 1.55 - 1.0 * I + thr_shift
			if float(s) == 0.0 and bi % 4 == 0:
				thr -= 0.25
			if float(s) == 0.25 or float(s) == 0.75:
				thr += 0.4 if tier < 4 else 0.12
			if score < thr:
				continue
			var win: Array = recent.filter(func(x): return t - float(x) <= 1.0 + 1e-9)
			if float(win.size()) + 1.0 > cap + 1e-9:
				continue
			var busy: Array = []
			for ln in hold_busy.keys():
				if float(hold_busy[ln]) > t - 0.02:
					busy.append(ln)
			var band: int = band_near(an, t)
			var third: int = maxi(lanes / 3, 1)
			var region: Array = []
			if band == 0:
				for q in range(0, third): region.append(q)
			elif band == 2:
				for q in range(lanes - third, lanes): region.append(q)
			else:
				for q in range(third, lanes - third + (1 if lanes % 3 != 0 else 0)): region.append(q)
			if region.is_empty():
				for q in range(lanes): region.append(q)
			var free: Array = region.filter(func(ln): return not busy.has(ln) and t - float(lane_last.get(ln, -9.0)) >= lane_gap and ln != last_lane)
			if free.is_empty():
				for q in range(lanes):
					if not busy.has(q) and t - float(lane_last.get(q, -9.0)) >= lane_gap and q != last_lane:
						free.append(q)
			if free.is_empty():
				continue
			var lane: int = int(rng.pick(free))
			var kind := "tap"
			var dur := 0.0
			var lane_to := -1
			var r: float = rng.f()
			var nbusy: int = busy.size()
			var recent_hold := false
			for tt in hold_busy.values():
				if t - float(tt) < 0.25:
					recent_hold = true
			if nbusy == 0 and float(s) == 0.0 and kinds.has("hold") and r < float(nd["hold_ratio"]) and I < 0.9 and bi % 2 == 0 and st >= 0.6:
				var nbeats_h: float = 2.0 if rng.f() < 0.5 else 1.0
				dur = nbeats_h * beat - 0.08
				kind = "hold"
			elif nbusy == 0 and float(s) == 0.0 and kinds.has("slide") and r < float(nd["hold_ratio"]) + 0.12 and I < 0.9 and bi % 2 == 0 and st >= 0.6:
				var nbrs: Array = []
				for cand in [lane - 1, lane + 1]:
					if cand >= 0 and cand < lanes and t - float(lane_last.get(cand, -9.0)) >= lane_gap:
						nbrs.append(cand)
				if not nbrs.is_empty():
					lane_to = int(rng.pick(nbrs))
					dur = beat - 0.08
					kind = "slide"
			elif nbusy == 0 and not recent_hold and float(s) == 0.0 and kinds.has("double") and st >= 1.2 and bi % 2 == 0 and rng.f() < 0.35 and lanes >= 3 and float(win.size()) + 2.0 <= cap + 1e-9:
				var cl: Array = []
				for q in range(lanes):
					if absi(q - lane) >= 2 and not busy.has(q) and t - float(lane_last.get(q, -9.0)) >= lane_gap:
						cl.append(q)
				if not cl.is_empty():
					var l2: int = int(rng.pick(cl))
					notes.append({"t": snappedf(t, 0.0001), "lane": lane, "kind": "double", "dur": 0.0})
					notes.append({"t": snappedf(t, 0.0001), "lane": l2, "kind": "double", "dur": 0.0})
					lane_last[lane] = t
					lane_last[l2] = t
					recent.append(t)
					recent.append(t)
					last_lane = lane
					continue
			elif nbusy == 0 and kinds.has("special") and st >= 1.3 and float(s) == 0.0 and rng.f() < 0.10:
				kind = "special"
			elif kinds.has("fast") and I >= 0.75 and float(s) == 0.0 and bi % 4 == 0 and rng.f() < 0.35 and tier >= 3 and nbusy == 0 \
					and (beat / 4.0) * 3.0 >= lane_gap and cap >= 4.0 and float(win.size() + 4) <= cap + 0.01:
				var cyc: Array = rng.pick([[0, 1, 2], [2, 1, 0]])
				var base: int = rng.rng_i(0, lanes - 3)
				var seq: Array = []
				for j in range(4):
					seq.append(base + int(cyc[j % 3]))
				var ok := true
				for j in range(4):
					if t + float(j) * beat / 4.0 - float(lane_last.get(seq[j], -9.0)) < lane_gap:
						ok = false
				if ok and t + beat < end_t - 1.0:
					for j in range(4):
						var tj: float = t + float(j) * beat / 4.0
						notes.append({"t": snappedf(tj, 0.0001), "lane": seq[j], "kind": "fast", "dur": 0.0})
						lane_last[seq[j]] = tj
						recent.append(tj)
					last_lane = int(seq[3])
					continue
			var n := {"t": snappedf(t, 0.0001), "lane": lane, "kind": kind, "dur": snappedf(dur, 0.0001)}
			if lane_to >= 0:
				n["lane_to"] = lane_to
				hold_busy[lane_to] = t + dur
				lane_last[lane_to] = t + dur
			if dur > 0.0:
				hold_busy[lane] = t + dur
			notes.append(n)
			lane_last[lane] = t + dur
			recent.append(t)
			last_lane = lane
		bi += 1
	notes.sort_custom(func(a, b): return float(a["t"]) < float(b["t"]) or (float(a["t"]) == float(b["t"]) and int(a["lane"]) < int(b["lane"])))
	return {"format": 1, "id": level_id if level_id != "" else "gen_%d_%s_%s_%d" % [int(round(float(an["bpm"]))), mode, style, seed_value],
			"name": level_name, "mode": mode, "difficulty": diff["name"], "style": style, "seed": seed_value, "generator_version": RD.GENERATOR_VERSION,
			"audio": {"bpm": an["bpm"], "offset": snappedf(off, 0.0001), "duration": snappedf(float(an["duration"]), 0.001),
					"start": an.get("audio_start", 0.0), "confidence": an.get("confidence", 0.0)},
			"speed_events": [{"t": 0.0, "speed": RD.speed_value(diff)}], "form_events": [], "objects": [], "notes": notes, "lanes": lanes,
			"instances": [], "end_t": snappedf(end_t, 0.001), "status": "GENERATING"}


# ------------------------------------------------------------------ Music Dash (hibrido)
static func generate_dash(an: Dictionary, diff: Dictionary, style: String = "balanced", seed_value: int = 1, level_name: String = "Fase gerada",
		level_id: String = "") -> Dictionary:
	var rng := Rng.new((seed_value ^ 0xA5A5A5) & 0xFFFFFFFF)
	var beat: float = 60.0 / float(an["bpm"])
	var bar_len: float = 4.0 * beat
	var off: float = float(an["offset"])
	var end_t: float = float(an["duration"]) - 0.4
	var n_full: int = int(floor((end_t - off) / bar_len))
	var first_bar: int = maxi(0, int(ceil((float(diff["lead_in_s"]) - off) / bar_len)))
	var z: int = n_full - 2
	var lane_bars: Array = []
	var pos: int = first_bar + rng.rng_i(3, 5)
	while true:
		var room: int = z - 4 - pos + 1
		if room < 3:
			break
		var ln: int = mini(rng.rng_i(4, 6), room)
		if energy_at(an, off + (float(pos) + float(ln) / 2.0) * bar_len) >= 0.15:
			for q in range(pos, pos + ln):
				lane_bars.append(q)
		pos += ln + rng.rng_i(3, 5)
	var blocked: Array = []
	for r in _runs(lane_bars):
		blocked.append(int(r[0]) - 1)
		blocked.append(int(r[1]) + 1)
	var m: Dictionary = generate_geometry(an, diff, style, seed_value, level_name, Callable(), lane_bars, blocked, true, "music_dash", level_id)
	var nt: Dictionary = generate_notes(an, diff, style, seed_value, 3, "", lane_bars, ["tap", "hold", "double"], 0.8, "", "music_dash")
	m["notes"] = nt["notes"]
	m["lanes"] = 3
	m["lane_bars"] = lane_bars
	var segs: Array = []
	for r in _runs(lane_bars):
		segs.append({"t0": snappedf(off + float(r[0]) * bar_len, 0.0001), "t1": snappedf(off + float(int(r[1]) + 1) * bar_len, 0.0001)})
	m["lane_segments"] = segs
	return m


# ------------------------------------------------------------------ Endless
const ENDLESS_TIERS := ["beginner", "normal", "hard", "expert", "insane"]


static func endless_ramp(bar: int) -> Array:
	var ti: int = mini(ENDLESS_TIERS.size() - 1, bar / 24)
	return [ENDLESS_TIERS[ti], minf(1.0 + 0.012 * float(bar / 8), 1.25)]


static func generate_endless(chunks: int, seed_value: int = 1, bpm: float = 128.0) -> Dictionary:
	var bars: int = chunks * 8 + 6
	var an: Dictionary = synthetic_analysis(bpm, bars, true)
	an["duration"] = float(bars) * 4.0 * 60.0 / bpm + 0.4
	var base: Dictionary = RD.difficulty("beginner")
	base["lead_in_s"] = 3.0
	var m: Dictionary = generate_geometry(an, base, "balanced", seed_value, "Endless Rhythm", LevelGenerator.endless_ramp, [], [], true, "endless_rhythm", "")
	m["mode"] = "endless"
	m["difficulty"] = "endless"
	var tb: Array = []
	for b in range(bars):
		tb.append(endless_ramp(b)[0])
	m["tier_by_bar"] = tb
	return m


# ------------------------------------------------------------------ entrada principal
static func generate(an_in: Dictionary, mode: String, diff_name: String, style: String = "balanced", seed_value: int = 1,
		custom: Dictionary = {}, lanes: int = -1, trim: Array = [], level_name: String = "Fase gerada", level_id: String = "") -> Dictionary:
	var diff: Dictionary = RD.difficulty(diff_name, custom)
	var an: Dictionary = an_in
	if trim.size() == 2:
		an = trim_analysis(an_in, float(trim[0]), float(trim[1]))
	match mode:
		"geometry_run":
			return generate_geometry(an, diff, style, seed_value, level_name, Callable(), [], [], true, "geometry_run", level_id)
		"magic_rhythm":
			return generate_notes(an, diff, style, seed_value, lanes, level_name, [], [], 1.0, level_id, "magic_rhythm")
		"music_dash":
			return generate_dash(an, diff, style, seed_value, level_name, level_id)
		"endless":
			return generate_endless(12, seed_value, float(an["bpm"]))
	return {}
