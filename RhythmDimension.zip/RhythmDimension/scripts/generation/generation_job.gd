class_name GenerationJob
extends RefCounted
## Pipeline de geracao em thread. Cada etapa e real e o progresso reflete o codigo executado:
##  1 gerar mapa -> 2 montar/validar previa -> 3 validar fase completa (simulacao) -> 4 corrigir se preciso -> 5 finalizar.
## A previa (TESTAR FASE) so aparece quando o trecho inicial passou na validacao; ela nunca vira fase oficial.

var analysis: Dictionary
var cfg: Dictionary
var thread: Thread
var stage := "Preparando"
var step := 0
var steps_total := 5
var progress := 0.0
var done := false
var preview_ready := false
var preview_map: Dictionary = {}
var map: Dictionary = {}
var report: Dictionary = {}
var history: Array = []
var status := "GENERATING"     # GENERATING | PREVIEW | VALIDATING | FIXING | READY | FAILED | UNVERIFIED
var log: Array = []
var _mutex := Mutex.new()


func start(an: Dictionary, config: Dictionary) -> void:
	analysis = an
	cfg = config
	thread = Thread.new()
	thread.start(_run)


func _set(st: String, s: int, pr: float, stat: String) -> void:
	stage = st
	step = s
	progress = pr
	status = stat
	log.append("[%d/%d] %s" % [s, steps_total, st])


func _run() -> void:
	_set("Gerando mapa a partir da analise e dos padroes", 1, 0.05, "GENERATING")
	var seed_value: int = int(cfg.get("seed", 1))
	var m: Dictionary = LevelGenerator.generate(analysis, String(cfg["mode"]), String(cfg["difficulty"]), String(cfg.get("style", "balanced")), seed_value,
			cfg.get("custom", {}), int(cfg.get("lanes", -1)), cfg.get("trim", []), String(cfg.get("name", "Fase gerada")), "")
	m["song_id"] = cfg.get("song_id", "")
	if cfg.has("custom"):
		m["custom"] = cfg["custom"]
	map = m
	_set("Montando e validando a previa (trecho inicial)", 2, 0.2, "PREVIEW")
	var pm := _make_preview(m, 24.0)
	if not pm.is_empty():
		var pr: Dictionary = LevelValidator.validate(pm, 1200)
		if pr["status"] == "READY":
			preview_map = pm
			preview_ready = true
	_set("Validando a fase completa (simulacao fisica e regras)", 3, 0.3, "VALIDATING")
	var rep: Dictionary = LevelValidator.validate(m, 1200, func(p: float): progress = 0.3 + 0.45 * p)
	report = rep
	if rep["status"] != "READY":
		_set("Corrigindo problemas encontrados", 4, 0.78, "FIXING")
		var fx: Dictionary = TestManager.fix_and_validate(m, 14, 1200, func(p: float): progress = 0.78 + 0.18 * p)
		map = fx["map"]
		report = fx["report"]
		history = fx["history"]
	else:
		map["validation_history"] = []
	_set("Finalizando", 5, 0.98, String(report["status"]))
	map["status"] = report["status"]
	map["validation"] = {"result": report["result"], "counts": report["counts"], "levels": report["levels"], "difficulty_estimate": report["difficulty_estimate"],
			"validator": "godot (level_validator.gd)", "date": Time.get_date_string_from_system()}
	progress = 1.0
	status = String(report["status"])
	done = true


## Trecho inicial seguro: corta onde nao ha perigo/portal perto e a forma e normal.
static func _make_preview(m: Dictionary, target_t: float) -> Dictionary:
	var end_t: float = float(m["end_t"])
	if end_t < 14.0:
		return {}
	var tl := RhythmMap.from_dict(m)
	var t_cut := minf(target_t, end_t - 6.0)
	while t_cut >= 10.0:
		var ok := true
		for o in m.get("objects", []):
			var to: float = tl.t_at(float(o["x"]))
			if to > t_cut - 1.2 and to < t_cut + 0.6:
				ok = false
				break
		if ok:
			var ev: Dictionary = tl.form_event_at(t_cut)
			if ev["form"] != "cube":
				ok = false
			for e in tl.fe:
				if float(e["t"]) > t_cut - 1.2 and float(e["t"]) < t_cut + 0.6 and float(e["t"]) > 0.0:
					ok = false
		if ok:
			break
		t_cut -= 0.25
	if t_cut < 10.0:
		return {}
	var p: Dictionary = m.duplicate(true)
	p["end_t"] = snappedf(t_cut, 0.001)
	p["objects"] = (p["objects"] as Array).filter(func(o): return tl.t_at(float(o["x"]) + float(o.get("w", 1))) <= t_cut)
	p["notes"] = (p["notes"] as Array).filter(func(n): return float(n["t"]) + float(n.get("dur", 0.0)) <= t_cut - 0.2)
	p["form_events"] = (p["form_events"] as Array).filter(func(e): return float(e["t"]) <= t_cut)
	p["instances"] = (p["instances"] as Array).filter(func(i): return float(i["t1"]) <= t_cut)
	p["id"] = String(m["id"]) + "_preview"
	p["status"] = "PREVIEW"
	p["is_preview"] = true
	return p


func poll() -> bool:
	if done and thread != null and thread.is_started():
		thread.wait_to_finish()
	return done
