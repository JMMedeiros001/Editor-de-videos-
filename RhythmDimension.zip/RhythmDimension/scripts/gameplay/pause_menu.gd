class_name PauseMenu
extends RefCounted
## Overlay de pausa compartilhado. cbs: resume, restart, exit, speed(Callable(float)), checkpoint, clear_cp.


static func build(parent: Control, practice: bool, cbs: Dictionary) -> Control:
	var ov := ColorRect.new()
	ov.color = Color(0, 0, 0, 0.78)
	ov.set_anchors_preset(Control.PRESET_FULL_RECT)
	ov.visible = false
	ov.z_index = 50
	parent.add_child(ov)
	var box := VBoxContainer.new()
	box.set_anchors_preset(Control.PRESET_CENTER)
	box.custom_minimum_size = Vector2(520, 0)
	box.position = Vector2(-260, -260)
	box.add_theme_constant_override("separation", 12)
	ov.add_child(box)
	box.add_child(UI.label("PAUSADO", 44, UI.accent(), HORIZONTAL_ALIGNMENT_CENTER))
	box.add_child(UI.button("Continuar", cbs["resume"], 72.0))
	box.add_child(UI.button("Reiniciar", cbs["restart"], 72.0))
	if practice:
		box.add_child(UI.label("Modo pratica (nao altera recordes)", 20, UI.GOLD, HORIZONTAL_ALIGNMENT_CENTER))
		var row := HBoxContainer.new()
		for sp in [1.0, 0.75, 0.5]:
			var b := UI.button("%d%%" % int(sp * 100), (cbs["speed"] as Callable).bind(sp), 60.0)
			b.size_flags_horizontal = Control.SIZE_EXPAND_FILL
			row.add_child(b)
		box.add_child(row)
		box.add_child(UI.button("Colocar checkpoint aqui", cbs["checkpoint"], 60.0))
		box.add_child(UI.button("Apagar checkpoints", cbs["clear_cp"], 60.0))
	box.add_child(UI.button("Sair", cbs["exit"], 72.0))
	return ov
