extends Control
## Modo de plataforma: Geometry Run, Music Dash (corrida + trechos de notas) e Endless.
## A fisica (PhysicsModel) avanca a partir do RELOGIO DE AUDIO (AudioManager.get_time), nunca por FPS/timers.
## NAO executado no Godot neste ambiente (ver documentation/TEST_REPORT.md > Nao executados).

var args: Dictionary = {}
var map_dict: Dictionary
var map: RhythmMap
var stream: AudioStream
var opts: Dictionary = {}
var player := PlayerController.new()
var obstacles := ObstacleController.new()
var notes_ctl := NoteController.new()
var score := ScoreManager.new()
var clock: RhythmClock
var rec := ReplayManager.new()
var state := "ready"            # ready | playing | dead | paused | done
var timer := 0.0
var attempts := 0
var deaths := 0
var practice := false
var preview := false
var is_endless := false
var checkpoints: Array = []
var cp_idx := 0
var particles: Array = []
var lanes_active := false
var speed_scale := 1.0
var loop_base := 0.0
var restart_t := 0.0
var best_progress := 0.0
var jtext := ""
var jtime := 0.0
var touches: Dictionary = {}
var pause_ov: Control
var pause_btn: Button
var assist_left := 0
var run_t0 := 0.0
var cur_time := 0.0


func _ready() -> void:
	map_dict = args["map"]
	stream = args["stream"]
	opts = args.get("opts", {})
	practice = bool(opts.get("practice", false))
	preview = bool(opts.get("preview", false))
	is_endless = String(map_dict.get("mode", "")) == "endless"
	map = RhythmMap.from_dict(map_dict)
	obstacles.setup(map)
	clock = RhythmClock.new(float(map_dict["audio"]["bpm"]), float(map_dict["audio"]["offset"]))
	if not (map_dict.get("notes", []) as Array).is_empty():
		notes_ctl.setup(map_dict["notes"], int(map_dict.get("lanes", 3)), score, GameSettings.windows())
		notes_ctl.on_judge = _on_judge
	restart_t = float(opts.get("start_t", 0.0))
	speed_scale = float(opts.get("speed", 1.0))
	mouse_filter = Control.MOUSE_FILTER_STOP
	pause_btn = Button.new()
	pause_btn.text = "II"
	pause_btn.custom_minimum_size = Vector2(88, 72)
	pause_btn.set_anchors_preset(Control.PRESET_TOP_RIGHT)
	pause_btn.position = Vector2(-100, 12)
	pause_btn.pressed.connect(_pause)
	add_child(pause_btn)
	pause_ov = PauseMenu.build(self, practice, {"resume": _resume, "restart": _restart_pressed, "exit": _exit,
			"speed": _set_speed, "checkpoint": _place_checkpoint, "clear_cp": _clear_cps})
	AudioManager.interrupted.connect(_on_interrupted)
	AudioManager.finished.connect(_on_audio_finished)
	if is_endless and "loop" in stream:
		pass    # o loop e feito manualmente (ver _on_audio_finished) para manter o relogio monotonico
	attempts = 0
	assist_left = 1 if GameSettings.assists else 0
	if opts.has("replay"):
		player.replay = opts["replay"]
	elif not practice and not preview:
		rec.start(String(map_dict["id"]), int(map_dict.get("seed", 0)))
	_start_attempt(restart_t)


func _exit_tree() -> void:
	if AudioManager.interrupted.is_connected(_on_interrupted):
		AudioManager.interrupted.disconnect(_on_interrupted)
	if AudioManager.finished.is_connected(_on_audio_finished):
		AudioManager.finished.disconnect(_on_audio_finished)
	AudioManager.player.pitch_scale = 1.0


# ------------------------------------------------------------ fluxo
func _start_attempt(from_t: float) -> void:
	var snap: Dictionary = {}
	if practice and not checkpoints.is_empty():
		snap = checkpoints[checkpoints.size() - 1]
		from_t = float(snap["t"])
	player.reset(map, from_t, snap)
	if not (map_dict.get("notes", []) as Array).is_empty():
		score = ScoreManager.new() if not practice else score
		notes_ctl.setup(map_dict["notes"], int(map_dict.get("lanes", 3)), score, GameSettings.windows())
		notes_ctl.on_judge = _on_judge
		notes_ctl.skip_before(from_t)
	run_t0 = from_t
	loop_base = 0.0
	cp_idx = 0
	var cps: Array = map_dict.get("checkpoints", [])
	while cp_idx < cps.size() and float(cps[cp_idx]) <= from_t:
		cp_idx += 1
	state = "ready"
	timer = 0.9
	AudioManager.stop()
	queue_redraw()


func _begin_audio() -> void:
	AudioManager.play(stream, float(map_dict["audio"].get("start", 0.0)))
	AudioManager.player.pitch_scale = speed_scale
	if run_t0 > 0.0:
		AudioManager.seek(run_t0)
	state = "playing"


func _process(delta: float) -> void:
	jtime = maxf(jtime - delta, 0.0)
	_update_particles(delta)
	if state == "ready":
		timer -= delta
		if timer <= 0.0:
			_begin_audio()
	elif state == "dead":
		timer -= delta
		if timer <= 0.0:
			if is_endless:
				_finish(false)
			else:
				_start_attempt(restart_t)
	elif state == "playing":
		var t: float = AudioManager.get_time() + loop_base
		cur_time = t
		var r: int = player.step_to(t)
		lanes_active = player.form() == RD.FORM_LANES
		if lanes_active:
			notes_ctl.update(t)
		if practice:
			var cps: Array = map_dict.get("checkpoints", [])
			while cp_idx < cps.size() and t >= float(cps[cp_idx]):
				if not lanes_active:
					checkpoints.append(player.snapshot())
				cp_idx += 1
		best_progress = maxf(best_progress, minf(player.x() / map.end_x, 1.0))
		if r == 1:
			_die()
		elif r == 2 or t >= float(map_dict["end_t"]):
			_finish(true)
	queue_redraw()


func _die() -> void:
	if assist_left > 0 and not practice:
		assist_left -= 1
		# assistencia: perdoa uma queda por tentativa (nao conta recorde)
		player.reset(map, player.time(), {})
		return
	state = "dead"
	deaths += 1
	attempts += 1
	timer = 0.75
	AudioManager.stop()
	AudioManager.play_sfx("death")
	if GameSettings.alt_feedback:
		Input.vibrate_handheld(60)
	_burst()
	if opts.has("replay"):
		timer = 0.2


func _finish(completed: bool) -> void:
	if state == "done":
		return
	state = "done"
	attempts += 1 if completed else 0
	rec.stop()
	var tt: float = cur_time if cur_time > 0.0 else float(map_dict["end_t"])
	var res: Dictionary = score.to_result(tt)
	var has_notes := not (map_dict.get("notes", []) as Array).is_empty()
	if not has_notes:
		res["accuracy"] = snappedf(best_progress * 100.0, 0.1)
	res["completed"] = completed
	res["progress"] = best_progress
	res["deaths"] = deaths
	res["attempts"] = attempts
	res["mode"] = String(map_dict.get("mode", ""))
	res["level_id"] = String(map_dict["id"])
	res["level_name"] = String(map_dict.get("name", ""))
	res["practice"] = practice
	res["preview"] = preview or bool(map_dict.get("is_preview", false))
	res["status"] = String(map_dict.get("status", ""))
	if is_endless:
		res["score"] = int(player.x() * 10.0) + score.score
		res["rank"] = "-"
	elif not has_notes:
		res["score"] = int(10000.0 * best_progress / float(maxi(attempts, 1)))
		res["rank"] = ScoreManager.rank_by_attempts(attempts, completed)
	else:
		res["score"] += int(5000.0 * best_progress / float(maxi(attempts, 1)))
	if completed and not practice:
		AudioManager.play_sfx("win")
	if not practice and not res["preview"] and not opts.has("replay"):
		var rr := SaveManager.record_result(res["level_id"], res["mode"], res, practice)
		res["new_record"] = rr["new_record"]
		res["achievements"] = rr["achievements"]
		if rec.inputs.size() > 0 and completed:
			res["replay_path"] = rec.save()
	GameManager.finish_level(res, args)


# ------------------------------------------------------------ pausa / controles
func _pause() -> void:
	if state == "playing":
		AudioManager.pause()
		state = "paused"
		pause_ov.visible = true
	elif state == "ready":
		state = "paused"
		pause_ov.visible = true


func _resume() -> void:
	pause_ov.visible = false
	if state == "paused":
		AudioManager.resume()
		state = "playing" if AudioManager.is_playing() or AudioManager.player.playing else "ready"
		if state == "ready":
			timer = 0.5


func _restart_pressed() -> void:
	pause_ov.visible = false
	deaths = 0
	_start_attempt(restart_t)


func _exit() -> void:
	AudioManager.stop()
	rec.stop()
	GameManager.goto("menu")


func _on_interrupted() -> void:
	if state == "playing":
		_pause()


func _on_audio_finished() -> void:
	if state == "playing" and is_endless:
		loop_base += stream.get_length() - float(map_dict["audio"].get("start", 0.0))
		AudioManager.play(stream, float(map_dict["audio"].get("start", 0.0)))
		AudioManager.player.pitch_scale = speed_scale


func _clear_cps() -> void:
	checkpoints.clear()


func _set_speed(sp: float) -> void:
	speed_scale = sp


func _place_checkpoint() -> void:
	if not lanes_active:
		checkpoints.append(player.snapshot())
		GameManager.toast("Checkpoint colocado em %.1fs" % player.time())


func _row_at(y: float) -> int:
	var ppb := size.y / 11.0
	var floor_y := size.y * 0.88
	return clampi(int((floor_y - y) / ppb / 3.0), 0, 2)


func _input(event: InputEvent) -> void:
	if state != "playing" and state != "ready":
		return
	if event is InputEventKey and not event.echo and (event.keycode == KEY_SPACE or event.keycode == KEY_UP):
		_set_hold(event.pressed)
	elif event is InputEventScreenTouch:
		if event.pressed and event.position.x > size.x - 120.0 and event.position.y < 100.0:
			return
		if lanes_active and state == "playing":
			var t: float = AudioManager.get_time() + loop_base
			if event.pressed:
				notes_ctl.press(_row_at(event.position.y), t, event.index)
				rec.add_input(player.time(), 0)
			else:
				notes_ctl.release(event.index, t)
		else:
			if event.pressed:
				touches[event.index] = true
			else:
				touches.erase(event.index)
			_set_hold(not touches.is_empty())
	elif event is InputEventScreenDrag and lanes_active:
		notes_ctl.move(event.index, _row_at(event.position.y))


var _last_hold := 0

func _set_hold(v: bool) -> void:
	var h := 1 if v else 0
	if h != _last_hold:
		_last_hold = h
		if player.replay == null:
			player.set_hold(h)
			rec.add_input(player.time(), h)


func _on_judge(note: Dictionary, j: String) -> void:
	jtext = j.to_upper()
	jtime = 0.5
	AudioManager.play_sfx(j)
	if j == "miss" and GameSettings.alt_feedback:
		Input.vibrate_handheld(25)


# ------------------------------------------------------------ efeitos
func _burst() -> void:
	if GameSettings.reduce_particles or not GameSettings.particles:
		return
	var n := [6, 14, 26][GameSettings.effects_quality]
	var ppb := size.y / 11.0
	var pos := Vector2(size.x * 0.28 + 0.4 * ppb, size.y * 0.88 - (float(player.state[0]) + 0.4) * ppb)
	for i in range(n):
		var a := randf() * TAU
		particles.append({"p": pos, "v": Vector2(cos(a), sin(a)) * randf_range(120.0, 520.0), "life": 0.7})


func _update_particles(delta: float) -> void:
	for p in particles:
		p["p"] += p["v"] * delta
		p["v"].y += 900.0 * delta
		p["life"] -= delta
	particles = particles.filter(func(p): return p["life"] > 0.0)


# ------------------------------------------------------------ desenho
func _draw() -> void:
	if map == null:
		return
	var ppb := size.y / 11.0
	var floor_y := size.y * 0.88
	var px_screen := size.x * 0.28
	var t := cur_time
	var pulse := clock.pulse(t) * (0.0 if GameSettings.reduce_flashes else 1.0)
	var acc := UI.accent()
	draw_rect(Rect2(Vector2.ZERO, size), Color(0.03 + 0.04 * pulse, 0.04, 0.09 + 0.05 * pulse), true)
	var cam_x: float = player.x() - px_screen / ppb
	var left_blocks := px_screen / ppb
	# grade de fundo (sensacao de velocidade)
	var gx: float = fposmod(cam_x, 4.0)
	for k in range(int(size.x / ppb / 4.0) + 3):
		var sx := (float(k) * 4.0 - gx) * ppb
		draw_line(Vector2(sx, 0), Vector2(sx, floor_y), Color(1, 1, 1, 0.04), 1.0)
	# chao e teto
	draw_rect(Rect2(0, floor_y, size.x, size.y - floor_y), Color(0.06, 0.08, 0.14), true)
	draw_line(Vector2(0, floor_y), Vector2(size.x, floor_y), acc, 3.0)
	var has_ceil: bool = map.ceil_at[mini(player.sim_i, map.ceil_at.size() - 1)] >= 0.0
	if has_ceil:
		var cy := floor_y - 9.0 * ppb
		draw_rect(Rect2(0, 0, size.x, cy), Color(0.06, 0.08, 0.14), true)
		draw_line(Vector2(0, cy), Vector2(size.x, cy), acc, 3.0)
	obstacles.draw(self, cam_x, size.x / ppb, left_blocks, px_screen - left_blocks * ppb, floor_y, ppb, acc, GameSettings.high_contrast)
	if lanes_active:
		_draw_lanes(cam_x, px_screen, floor_y, ppb, t)
	if state != "dead":
		player.draw(self, cam_x, px_screen - left_blocks * ppb, floor_y, ppb, acc)
	for p in particles:
		var a: float = clampf(float(p["life"]) / 0.7, 0.0, 1.0)
		draw_circle(p["p"], 5.0, Color(acc.r, acc.g, acc.b, a))
	_draw_hud(t)


func _draw_lanes(cam_x: float, px_screen: float, floor_y: float, ppb: float, t: float) -> void:
	for r in range(3):
		var y: float = floor_y - (1.5 + 3.0 * float(r)) * ppb
		draw_line(Vector2(0, y), Vector2(size.x, y), Color(1, 0.85, 0.2, 0.25), 2.0)
	draw_line(Vector2(px_screen, 0), Vector2(px_screen, floor_y), Color(1, 1, 1, 0.5), 3.0)
	var font := ThemeDB.fallback_font
	var i := notes_ctl.next_idx
	while i < notes_ctl.notes.size():
		var n: Dictionary = notes_ctl.notes[i]
		var dt := float(n["t"]) - t
		if dt > 3.0:
			break
		if n["state"] != "done":
			var x: float = px_screen + (map.x_at(float(n["t"])) - map.x_at(t)) * ppb
			var y2: float = floor_y - (1.5 + 3.0 * float(n["lane"])) * ppb
			var col := UI.GOLD if n["kind"] == "special" else (UI.MAGENTA if n["kind"] == "double" else UI.accent())
			if n["kind"] == "hold":
				var w: float = (map.x_at(float(n["t"]) + float(n["dur"])) - map.x_at(float(n["t"]))) * ppb
				draw_rect(Rect2(x, y2 - 0.35 * ppb, w, 0.7 * ppb), Color(col.r, col.g, col.b, 0.5), true)
			draw_circle(Vector2(x, y2), 0.5 * ppb, col)
			draw_arc(Vector2(x, y2), 0.5 * ppb, 0.0, TAU, 20, Color.WHITE, 2.0)
		i += 1
	draw_string(font, Vector2(size.x * 0.5 - 140, 70), "TRECHO DE NOTAS: toque na linha certa", HORIZONTAL_ALIGNMENT_CENTER, 280, 22, UI.GOLD)


func _draw_hud(t: float) -> void:
	var font := ThemeDB.fallback_font
	var prog: float = clampf(player.x() / maxf(map.end_x, 1.0), 0.0, 1.0)
	draw_rect(Rect2(24, 24, size.x - 160, 14), Color(1, 1, 1, 0.12), true)
	draw_rect(Rect2(24, 24, (size.x - 160) * prog, 14), UI.accent(), true)
	draw_string(font, Vector2(24, 70), "%d%%" % int(prog * 100.0), HORIZONTAL_ALIGNMENT_LEFT, -1, 26, Color.WHITE)
	var info := ""
	if is_endless:
		info = "ENDLESS  dist %d  %s" % [int(player.x()), String(map_dict.get("tier_by_bar", ["beginner"])[clampi(int(clock.bar_at(t)), 0, (map_dict.get("tier_by_bar", ["beginner"]) as Array).size() - 1)]).to_upper()]
	else:
		info = "Tentativa %d" % (attempts + 1)
	if practice:
		info += "   PRATICA %d%%" % int(speed_scale * 100.0)
	if preview or bool(map_dict.get("is_preview", false)):
		info += "   PREVIA (nao oficial)"
	draw_string(font, Vector2(24, size.y - 18), info, HORIZONTAL_ALIGNMENT_LEFT, -1, 24, Color(0.8, 0.9, 1.0))
	if not (map_dict.get("notes", []) as Array).is_empty():
		draw_string(font, Vector2(size.x - 360, 80), "Pontos %d   Combo %d   x%d" % [score.score, score.combo, score.multiplier(t)], HORIZONTAL_ALIGNMENT_RIGHT, 340, 24, Color.WHITE)
	if jtime > 0.0:
		var col := {"PERFECT": UI.GOLD, "GREAT": Color(0.4, 1, 0.6), "GOOD": Color(0.5, 0.8, 1), "MISS": Color(1, 0.3, 0.3)}.get(jtext, Color.WHITE)
		draw_string(font, Vector2(size.x * 0.5 - 150, size.y * 0.3), jtext, HORIZONTAL_ALIGNMENT_CENTER, 300, 54, col)
	if state == "ready":
		draw_string(font, Vector2(size.x * 0.5 - 200, size.y * 0.45), "PRONTO", HORIZONTAL_ALIGNMENT_CENTER, 400, 72, Color.WHITE)
		draw_string(font, Vector2(size.x * 0.5 - 300, size.y * 0.45 + 50), "toque/segure para agir", HORIZONTAL_ALIGNMENT_CENTER, 600, 26, Color(0.8, 0.9, 1.0))
	if state == "dead":
		draw_string(font, Vector2(size.x * 0.5 - 200, size.y * 0.45), "%d%%" % int(best_progress * 100.0), HORIZONTAL_ALIGNMENT_CENTER, 400, 64, Color(1, 0.4, 0.4))
