class_name PlayerController
extends RefCounted
## Jogador: estado fisico (PhysicsModel), avanco guiado pelo relogio de audio, snapshots (checkpoints) e replay.

var map: RhythmMap
var state: Array = []
var sim_i := 0
var hold := 0
var replay: ReplayManager = null     # se definido, as entradas vem do replay
var _rp := 0
var trail: Array = []


func reset(m: RhythmMap, from_t: float = 0.0, snap: Dictionary = {}) -> void:
	map = m
	trail.clear()
	if snap.is_empty():
		state = PhysicsModel.initial_state(m)
		sim_i = int(floor(from_t / PhysicsModel.DT))
		if from_t > 0.0:
			state = [0.0, 0.0, int(m.form_event_at(from_t).get("gs", 1)), 1, 0.0, 0]
	else:
		state = (snap["state"] as Array).duplicate()
		sim_i = int(snap["i"])
	hold = 0
	_rp = 0


func snapshot() -> Dictionary:
	return {"state": state.duplicate(), "i": sim_i, "t": float(sim_i) * PhysicsModel.DT}


func set_hold(v: int) -> void:
	hold = v


func time() -> float:
	return float(sim_i) * PhysicsModel.DT


func x() -> float:
	return map.xs[sim_i]


func form() -> int:
	return map.form_at[sim_i]


## Avanca a simulacao ate o instante de audio t. Retorna 0 = ok, 1 = morreu, 2 = concluiu.
func step_to(t: float, max_steps: int = 480) -> int:
	var target: int = int(floor(t / PhysicsModel.DT))
	var n := 0
	while sim_i < target and n < max_steps:
		if map.xs[sim_i] >= map.end_x:
			return 2
		if replay != null:
			var st_t: float = float(sim_i) * PhysicsModel.DT
			while _rp < replay.inputs.size() and float(replay.inputs[_rp][0]) <= st_t + 1e-9:
				hold = int(replay.inputs[_rp][1])
				_rp += 1
		var st: Variant = PhysicsModel.advance(map, sim_i, state, hold)
		if st == null:
			return 1
		state = st
		sim_i += 1
		n += 1
		if sim_i % 6 == 0:
			trail.append(Vector2(map.xs[sim_i], float(state[0])))
			if trail.size() > 24:
				trail.pop_front()
	if map.xs[mini(sim_i, map.xs.size() - 1)] >= map.end_x:
		return 2
	return 0


## Desenha o jogador na tela. wx->tela: sx = ox + (wx - cam_x) * ppb ; sy = floor_y - wy * ppb
func draw(ci: CanvasItem, cam_x: float, ox: float, floor_y: float, ppb: float, color: Color) -> void:
	var f := form()
	var wx: float = map.xs[sim_i]
	var wy: float = float(state[0])
	var gs: int = int(state[2])
	var px: float = ox + (wx - cam_x) * ppb
	var py: float = floor_y - (wy + 0.8) * ppb
	var s: float = 0.8 * ppb
	var r := Rect2(px, py, s, s)
	for k in range(trail.size()):
		var tp: Vector2 = trail[k]
		var a: float = float(k) / float(maxi(trail.size(), 1)) * 0.35
		ci.draw_rect(Rect2(ox + (tp.x - cam_x) * ppb, floor_y - (tp.y + 0.8) * ppb, s, s), Color(color.r, color.g, color.b, a), false, 2.0)
	match f:
		RD.FORM_CUBE, RD.FORM_ROBOT:
			ci.draw_rect(r, color, true)
			ci.draw_rect(r, Color.WHITE, false, 3.0)
			ci.draw_rect(Rect2(px + s * 0.55, py + s * 0.25, s * 0.2, s * 0.2), Color.BLACK, true)
			if f == RD.FORM_ROBOT:
				ci.draw_line(Vector2(px + s * 0.2, py + s), Vector2(px + s * 0.1, py + s * 1.2), Color.WHITE, 3.0)
		RD.FORM_SHIP:
			ci.draw_colored_polygon(PackedVector2Array([Vector2(px, py + s), Vector2(px + s * 1.1, py + s * 0.55), Vector2(px, py)]), color)
			ci.draw_arc(Vector2(px + s * 0.3, py + s * 0.45), s * 0.22, PI, TAU, 8, Color.WHITE, 2.0)
		RD.FORM_BALL:
			ci.draw_circle(Vector2(px + s / 2.0, py + s / 2.0), s / 2.0, color)
			ci.draw_arc(Vector2(px + s / 2.0, py + s / 2.0), s / 2.0, 0.0, TAU, 20, Color.WHITE, 3.0)
		RD.FORM_SPIDER:
			var c := Vector2(px + s / 2.0, py + s / 2.0)
			ci.draw_colored_polygon(PackedVector2Array([c + Vector2(0, -s / 2.0), c + Vector2(s / 2.0, 0), c + Vector2(0, s / 2.0), c + Vector2(-s / 2.0, 0)]), color)
			ci.draw_line(c, c + Vector2(-s * 0.7, s * 0.5 * gs), Color.WHITE, 2.0)
			ci.draw_line(c, c + Vector2(s * 0.7, s * 0.5 * gs), Color.WHITE, 2.0)
		RD.FORM_WAVE:
			var up: float = -1.0 if float(state[1]) >= 0.0 else 1.0
			var c2 := Vector2(px + s / 2.0, py + s / 2.0)
			ci.draw_colored_polygon(PackedVector2Array([c2 + Vector2(-s * 0.5, -s * 0.4 * up * -1.0), c2 + Vector2(s * 0.6, s * 0.45 * up), c2 + Vector2(-s * 0.5, s * 0.4 * up * -1.0 + s * 0.1)]), color)
		_:
			ci.draw_circle(Vector2(px + s / 2.0, py + s / 2.0), s / 2.0, color)
