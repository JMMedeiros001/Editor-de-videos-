extends Control
## Magic Rhythm: notas em 3 a 6 pistas (tap, hold, double, slide, fast, special). Retrato.
## O toque e julgado pelo tempo REAL do relogio de audio (NoteController), nao pela animacao.
## NAO executado no Godot neste ambiente.

var args: Dictionary = {}
var map_dict: Dictionary
var stream: AudioStream
var opts: Dictionary = {}
var lanes := 4
var score := ScoreManager.new()
var ctl := NoteController.new()
var clock: RhythmClock
var rec := ReplayManager.new()
var state := "ready"
var timer := 1.2
var practice := false
var preview := false
var cur_t := 0.0
var jtext := ""
var jtime := 0.0
var jlane := 0
var flashes: Array = []
var scroll := 760.0
var pause_ov: Control
var speed_scale := 1.0
var start_t := 0.0
var finger_started: Dictionary = {}


func _ready() -> void:
	map_dict = args["map"]
	stream = args["stream"]
	opts = args.get("opts", {})
	practice = bool(opts.get("practice", false))
	preview = bool(opts.get("preview", false)) or bool(map_dict.get("is_preview", false))
	lanes = clampi(int(map_dict.get("lanes", 4)), 3, 6)
	clock = RhythmClock.new(float(map_dict["audio"]["bpm"]), float(map_dict["audio"]["offset"]))
	var d := LevelValidator.diff_of(map_dict)
	scroll = float(d["notes"]["scroll"])
	start_t = float(opts.get("start_t", 0.0))
	speed_scale = float(opts.get("speed", 1.0))
	mouse_filter = Control.MOUSE_FILTER_STOP
	var pb := Button.new()
	pb.text = "II"
	pb.custom_minimum_size = Vector2(88, 72)
	pb.set_anchors_preset(Control.PRESET_TOP_RIGHT)
	pb.position = Vector2(-100, 12)
	pb.pressed.connect(_pause)
	add_child(pb)
	pause_ov = PauseMenu.build(self, practice, {"resume": _resume, "restart": _restart, "exit": _exit, "speed": _set_speed,
			"checkpoint": _mark_start, "clear_cp": _clear_start})
	AudioManager.interrupted.connect(_pause)
	if not practice and not preview:
		rec.start(String(map_dict["id"]), int(map_dict.get("seed", 0)))
	_start()


func _exit_tree() -> void:
	if AudioManager.interrupted.is_connected(_pause):
		AudioManager.interrupted.disconnect(_pause)
	AudioManager.player.pitch_scale = 1.0


func _start() -> void:
	score = ScoreManager.new()
	ctl.setup(map_dict["notes"], lanes, score, GameSettings.windows())
	ctl.on_judge = _on_judge
	ctl.skip_before(start_t)
	state = "ready"
	timer = 1.2
	AudioManager.stop()


func _process(delta: float) -> void:
	jtime = maxf(jtime - delta, 0.0)
	for f in flashes:
		f["life"] -= delta
	flashes = flashes.filter(func(f): return f["life"] > 0.0)
	if state == "ready":
		timer -= delta
		cur_t = start_t - timer
		if timer <= 0.0:
			AudioManager.play(stream, float(map_dict["audio"].get("start", 0.0)))
			AudioManager.player.pitch_scale = speed_scale
			if start_t > 0.0:
				AudioManager.seek(start_t)
			state = "playing"
	elif state == "playing":
		cur_t = AudioManager.get_time()
		ctl.update(cur_t)
		if cur_t >= float(map_dict["end_t"]):
			_finish()
	queue_redraw()


func _finish() -> void:
	if state == "done":
		return
	state = "done"
	rec.stop()
	var res: Dictionary = score.to_result(cur_t)
	res["completed"] = true
	res["progress"] = 1.0
	res["deaths"] = 0
	res["mode"] = "magic_rhythm"
	res["level_id"] = String(map_dict["id"])
	res["level_name"] = String(map_dict.get("name", ""))
	res["practice"] = practice
	res["preview"] = preview
	res["status"] = String(map_dict.get("status", ""))
	if not practice and not preview:
		var rr := SaveManager.record_result(res["level_id"], "magic_rhythm", res, false)
		res["new_record"] = rr["new_record"]
		res["achievements"] = rr["achievements"]
		res["replay_path"] = rec.save()
	GameManager.finish_level(res, args)


func _pause() -> void:
	if state == "playing" or state == "ready":
		AudioManager.pause()
		state = "paused"
		pause_ov.visible = true


func _resume() -> void:
	pause_ov.visible = false
	if state == "paused":
		AudioManager.resume()
		state = "playing"


func _restart() -> void:
	pause_ov.visible = false
	_start()


func _exit() -> void:
	AudioManager.stop()
	GameManager.goto("menu")


func _set_speed(s: float) -> void:
	speed_scale = s


func _mark_start() -> void:
	start_t = cur_t
	GameManager.toast("Inicio do treino em %.1fs" % cur_t)


func _clear_start() -> void:
	start_t = 0.0


func _lane_at(x: float) -> int:
	return clampi(int(x / (size.x / float(lanes))), 0, lanes - 1)


func _input(event: InputEvent) -> void:
	if state != "playing":
		return
	if event is InputEventScreenTouch:
		if event.pressed and event.position.x > size.x - 120.0 and event.position.y < 100.0:
			return
		var t := AudioManager.get_time()
		if event.pressed:
			var lane := _lane_at(event.position.x)
			var ok := ctl.press(lane, t, event.index)
			rec.add_input(t, [lane, 1])
			if not ok:
				flashes.append({"lane": lane, "life": 0.15, "col": Color(1, 1, 1, 0.25)})
		else:
			ctl.release(event.index, t)
			rec.add_input(t, [-1, 0])
	elif event is InputEventScreenDrag:
		ctl.move(event.index, _lane_at(event.position.x))


func _on_judge(note: Dictionary, j: String) -> void:
	jtext = j.to_upper()
	jtime = 0.5
	jlane = int(note["lane"])
	rec.add_result(cur_t, jlane, j)
	AudioManager.play_sfx(j)
	var col := {"perfect": UI.GOLD, "great": Color(0.4, 1, 0.6), "good": Color(0.5, 0.8, 1), "miss": Color(1, 0.3, 0.3)}[j]
	flashes.append({"lane": jlane, "life": 0.25, "col": Color(col.r, col.g, col.b, 0.45)})
	if j == "miss" and GameSettings.alt_feedback:
		Input.vibrate_handheld(25)


func _lane_w() -> float:
	return size.x / float(lanes)


func _note_y(t_note: float, hit_y: float, ppx: float) -> float:
	return hit_y - (t_note - cur_t) * ppx


func _draw() -> void:
	var hit_y := size.y * 0.82
	var ppx := scroll * size.y / 1280.0
	var lw := _lane_w()
	var acc := UI.accent()
	var pulse := clock.pulse(cur_t) * (0.0 if GameSettings.reduce_flashes else 1.0)
	draw_rect(Rect2(Vector2.ZERO, size), Color(0.03 + 0.03 * pulse, 0.04, 0.09 + 0.04 * pulse), true)
	for i in range(lanes + 1):
		draw_line(Vector2(float(i) * lw, 0), Vector2(float(i) * lw, size.y), Color(1, 1, 1, 0.14), 2.0)
	for f in flashes:
		draw_rect(Rect2(float(f["lane"]) * lw, 0, lw, size.y), f["col"], true)
	draw_line(Vector2(0, hit_y), Vector2(size.x, hit_y), acc, 4.0)
	# batidas (grade)
	var b0 := int(floor(clock.beat_at(cur_t - 0.2)))
	for b in range(b0, b0 + 12):
		var y := _note_y(clock.time_of_beat(float(b)), hit_y, ppx)
		if y > -4.0 and y < size.y:
			draw_line(Vector2(0, y), Vector2(size.x, y), Color(1, 1, 1, 0.12 if b % 4 != 0 else 0.3), 1.0)
	var i := ctl.next_idx
	while i < ctl.notes.size():
		var n: Dictionary = ctl.notes[i]
		var y_head: float = _note_y(float(n["t"]), hit_y, ppx)
		if y_head < -200.0:
			break
		if n["state"] != "done" or n["kind"] == "hold" or n["kind"] == "slide":
			_draw_note(n, y_head, hit_y, ppx, lw)
		i += 1
	var font := ThemeDB.fallback_font
	draw_string(font, Vector2(24, 60), "%d" % score.score, HORIZONTAL_ALIGNMENT_LEFT, -1, 44, Color.WHITE)
	draw_string(font, Vector2(24, 100), "%.1f%%   x%d" % [score.accuracy(), score.multiplier(cur_t)], HORIZONTAL_ALIGNMENT_LEFT, -1, 24, Color(0.8, 0.9, 1.0))
	if score.combo > 1:
		draw_string(font, Vector2(0, size.y * 0.35), "%d" % score.combo, HORIZONTAL_ALIGNMENT_CENTER, size.x, 72, Color(1, 1, 1, 0.85))
	var prog: float = clampf(cur_t / float(map_dict["end_t"]), 0.0, 1.0)
	draw_rect(Rect2(0, size.y - 10, size.x * prog, 10), acc, true)
	if jtime > 0.0:
		var col2 := {"PERFECT": UI.GOLD, "GREAT": Color(0.4, 1, 0.6), "GOOD": Color(0.5, 0.8, 1), "MISS": Color(1, 0.3, 0.3)}.get(jtext, Color.WHITE)
		draw_string(font, Vector2(0, hit_y - 80), jtext, HORIZONTAL_ALIGNMENT_CENTER, size.x, 40, col2)
	if state == "ready":
		draw_string(font, Vector2(0, size.y * 0.4), "PRONTO", HORIZONTAL_ALIGNMENT_CENTER, size.x, 64, Color.WHITE)
	if preview:
		draw_string(font, Vector2(0, size.y - 24), "PREVIA (nao oficial)", HORIZONTAL_ALIGNMENT_CENTER, size.x, 22, Color(0.5, 0.8, 1))
	if practice:
		draw_string(font, Vector2(0, size.y - 50), "PRATICA %d%%" % int(speed_scale * 100.0), HORIZONTAL_ALIGNMENT_CENTER, size.x, 22, UI.GOLD)


func _draw_note(n: Dictionary, y_head: float, hit_y: float, ppx: float, lw: float) -> void:
	var lane := int(n["lane"])
	var x := float(lane) * lw
	var col := UI.accent()
	match String(n["kind"]):
		"special": col = UI.GOLD
		"double": col = UI.MAGENTA
		"fast": col = Color(0.5, 1.0, 0.6)
	var h := 0.11 * size.y
	if n["kind"] == "hold":
		var y_tail := _note_y(float(n["t"]) + float(n["dur"]), hit_y, ppx)
		var top := y_tail
		var bottom := y_head
		if n["state"] == "holding":
			bottom = hit_y
		draw_rect(Rect2(x + lw * 0.2, top, lw * 0.6, maxf(bottom - top, 4.0)), Color(col.r, col.g, col.b, 0.45), true)
	elif n["kind"] == "slide":
		var lt := int(n["lane_to"])
		var y_tail2 := _note_y(float(n["t"]) + float(n["dur"]), hit_y, ppx)
		var p0 := Vector2(x + lw * 0.5, y_head)
		var p1 := Vector2(float(lt) * lw + lw * 0.5, y_tail2)
		draw_line(p0, p1, Color(col.r, col.g, col.b, 0.6), lw * 0.35)
	var r := Rect2(x + lw * 0.08, y_head - h, lw * 0.84, h)
	draw_rect(r, col if n["state"] != "holding" else Color(1, 1, 1), true)
	draw_rect(r, Color.WHITE, false, 3.0)
	if n["kind"] == "double":
		# linha entre as duas notas do acorde
		for m in ctl.notes:
			if m["kind"] == "double" and absf(float(m["t"]) - float(n["t"])) < 0.005 and int(m["lane"]) > lane:
				draw_line(Vector2(x + lw * 0.5, y_head - h * 0.5), Vector2(float(m["lane"]) * lw + lw * 0.5, y_head - h * 0.5), UI.MAGENTA, 4.0)
				break
