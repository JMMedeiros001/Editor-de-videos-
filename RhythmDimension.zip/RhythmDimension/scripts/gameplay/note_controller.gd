class_name NoteController
extends RefCounted
## Julgamento de notas pelo TEMPO REAL do toque (relogio de audio), nunca pela animacao.
## Tipos: tap/fast/special (um toque), hold (manter ate o fim), double (duas notas simultaneas, cada uma julgada),
## slide (acompanhar a trajetoria entre pistas adjacentes).

var notes: Array = []          # cada nota: dict do mapa + estado
var lanes := 4
var score: ScoreManager
var win: Dictionary = {}
var on_judge: Callable = Callable()   # (note: Dictionary, judgement: String)
var finger_lane: Dictionary = {}      # id do dedo -> pista atual (para slides)
var next_idx := 0                     # indice da primeira nota ainda pendente (otimizacao)

const MISS_EXTRA := 0.02


func setup(note_list: Array, lanes_n: int, sc: ScoreManager, windows: Dictionary) -> void:
	notes.clear()
	for n in note_list:
		var c: Dictionary = (n as Dictionary).duplicate()
		c["state"] = "pending"       # pending | holding | done
		c["head"] = ""
		c["ticks"] = 0
		c["ticks_ok"] = 0
		c["finger"] = -1
		notes.append(c)
	lanes = lanes_n
	score = sc
	win = windows
	next_idx = 0
	finger_lane.clear()


func _judge_name(dt: float) -> String:
	var a := absf(dt)
	if a <= float(win["perfect"]): return "perfect"
	if a <= float(win["great"]): return "great"
	if a <= float(win["good"]): return "good"
	return ""


func _emit(n: Dictionary, j: String, now: float) -> void:
	if j == "miss":
		score.missed()
	else:
		score.hit(j, now, n["kind"] == "special")
	if on_judge.is_valid():
		on_judge.call(n, j)


func press(lane: int, t: float, finger: int = 0) -> bool:
	finger_lane[finger] = lane
	var best := -1
	var best_dt := 1e9
	var i := next_idx
	while i < notes.size():
		var n: Dictionary = notes[i]
		if float(n["t"]) > t + float(win["good"]):
			break
		if n["state"] == "pending" and int(n["lane"]) == lane:
			var dt: float = t - float(n["t"])
			if absf(dt) <= float(win["good"]) and absf(dt) < best_dt:
				best = i
				best_dt = absf(dt)
		i += 1
	if best < 0:
		return false
	var nt: Dictionary = notes[best]
	var j := _judge_name(t - float(nt["t"]))
	if nt["kind"] == "hold" or nt["kind"] == "slide":
		nt["state"] = "holding"
		nt["head"] = j
		nt["finger"] = finger
	else:
		nt["state"] = "done"
		_emit(nt, j, t)
	_advance()
	return true


func move(finger: int, lane: int) -> void:
	finger_lane[finger] = lane


func release(finger: int, t: float) -> void:
	for n in notes:
		if n["state"] == "holding" and int(n["finger"]) == finger:
			var end_t: float = float(n["t"]) + float(n["dur"])
			if t < end_t - 0.15:
				n["state"] = "done"
				_emit(n, "miss", t)        # soltou cedo
			# se soltou perto do fim, update() conclui
	finger_lane.erase(finger)


func update(t: float) -> void:
	var i := next_idx
	while i < notes.size():
		var n: Dictionary = notes[i]
		if float(n["t"]) > t + 1.0:
			break
		if n["state"] == "pending" and t > float(n["t"]) + float(win["good"]) + MISS_EXTRA:
			n["state"] = "done"
			_emit(n, "miss", t)
		elif n["state"] == "holding":
			var end_t: float = float(n["t"]) + float(n["dur"])
			if n["kind"] == "slide":
				var prog: float = clampf((t - float(n["t"])) / maxf(float(n["dur"]), 0.001), 0.0, 1.0)
				var want: int = int(round(float(n["lane"]) + (float(n["lane_to"]) - float(n["lane"])) * prog))
				n["ticks"] += 1
				if int(finger_lane.get(int(n["finger"]), -9)) == want:
					n["ticks_ok"] += 1
			if t >= end_t:
				n["state"] = "done"
				var ok := true
				if n["kind"] == "slide":
					ok = int(n["ticks"]) > 0 and float(n["ticks_ok"]) / float(n["ticks"]) >= 0.7
				_emit(n, String(n["head"]) if ok else "miss", t)
		i += 1
	_advance()


func _advance() -> void:
	while next_idx < notes.size() and notes[next_idx]["state"] == "done":
		next_idx += 1


func finished() -> bool:
	return next_idx >= notes.size()


## Marca como concluidas as notas anteriores a t (reinicio a partir de checkpoint/trecho).
func skip_before(t: float) -> void:
	for n in notes:
		if float(n["t"]) + float(n.get("dur", 0.0)) < t:
			n["state"] = "done"
	_advance()
