class_name ObstacleController
extends RefCounted
## Desenho dos obstaculos/portais visiveis (culling por busca binaria em x).

var map: RhythmMap
var objs: Array = []
var ox := PackedFloat64Array()


func setup(m: RhythmMap) -> void:
	map = m
	objs = m.m.get("objects", [])
	ox.clear()
	for o in objs:
		ox.append(float(o["x"]))


func _first(x: float) -> int:
	var lo := 0
	var hi := ox.size()
	while lo < hi:
		var mid := (lo + hi) >> 1
		if ox[mid] < x:
			lo = mid + 1
		else:
			hi = mid
	return lo


func draw(ci: CanvasItem, cam_x: float, view_w_blocks: float, left_blocks: float, ox_px: float, floor_y: float, ppb: float, accent: Color, contrast: bool) -> void:
	var i := _first(cam_x - left_blocks - 12.0)
	var x_max := cam_x + view_w_blocks + 2.0
	var block_col := Color(0.12, 0.14, 0.2) if not contrast else Color(0.0, 0.0, 0.0)
	var edge := accent if not contrast else Color.WHITE
	while i < objs.size() and ox[i] <= x_max:
		var o: Dictionary = objs[i]
		var x: float = float(o["x"])
		var y: float = float(o.get("y", 0))
		var sx: float = ox_px + (x - cam_x) * ppb
		if o["type"] == "block":
			var w: float = float(o.get("w", 1)) * ppb
			var h: float = float(o.get("h", 1)) * ppb
			var r := Rect2(sx, floor_y - (y * ppb) - h, w, h)
			ci.draw_rect(r, block_col, true)
			ci.draw_rect(r, edge, false, 2.0)
		else:
			var flip: bool = bool(o.get("flip", false))
			var cx: float = sx + ppb * 0.5
			var base_y: float = floor_y - y * ppb if not flip else floor_y - (y + 1.0) * ppb
			var hh: float = ppb * 0.62
			var hw: float = ppb * 0.42
			var pts: PackedVector2Array
			if not flip:
				pts = PackedVector2Array([Vector2(cx - hw, base_y), Vector2(cx + hw, base_y), Vector2(cx, base_y - hh)])
			else:
				pts = PackedVector2Array([Vector2(cx - hw, base_y), Vector2(cx + hw, base_y), Vector2(cx, base_y + hh)])
			ci.draw_colored_polygon(pts, Color(1.0, 0.25, 0.35) if not contrast else Color(1, 1, 0))
			ci.draw_polyline(PackedVector2Array([pts[0], pts[1], pts[2], pts[0]]), Color.WHITE, 2.0)
		i += 1
	# portais (mudanca de forma/gravidade/velocidade)
	for e in map.fe:
		if bool(e.get("portal", false)):
			var px: float = ox_px + (map.x_at(float(e["t"])) - cam_x) * ppb
			if px > -40.0 and px < ox_px + view_w_blocks * ppb + 40.0:
				var col := Color(0.4, 1.0, 0.6) if e["form"] == "cube" else Color(0.9, 0.5, 1.0)
				if e["form"] == "lanes":
					col = Color(1.0, 0.85, 0.2)
				ci.draw_rect(Rect2(px, floor_y - 9.0 * ppb, ppb * 0.35, 9.0 * ppb), Color(col.r, col.g, col.b, 0.55), true)
	for e2 in map.m["speed_events"]:
		if bool(e2.get("portal", false)):
			var sx2: float = ox_px + (map.x_at(float(e2["t"])) - cam_x) * ppb
			ci.draw_rect(Rect2(sx2, floor_y - 9.0 * ppb, ppb * 0.2, 9.0 * ppb), Color(1.0, 0.6, 0.1, 0.5), true)
