extends Control
## Configuracoes: audio (musica, efeitos, offset, latencia), gameplay, graficos, acessibilidade + calibracao de offset.
var args: Dictionary = {}
var cal := {"on": false, "clicks": [], "taps": [], "t0": 0.0, "n": 0}
var cal_lab: Label


func _ready() -> void:
	var box := UI.screen(self, "Configuracoes", func(): _back())
	var G := GameSettings
	box.add_child(UI.label("Audio", 30, UI.accent()))
	UI.slider(box, "Musica", 0.0, 1.0, 0.05, G.music_volume, _set_music)
	UI.slider(box, "Efeitos", 0.0, 1.0, 0.05, G.sfx_volume, _set_sfx)
	UI.slider(box, "Offset de audio (ms)", -200.0, 200.0, 5.0, G.audio_offset_ms, func(v: float): G.audio_offset_ms = v)
	UI.slider(box, "Latencia extra (ms)", 0.0, 300.0, 5.0, G.latency_ms, func(v: float): G.latency_ms = v)
	box.add_child(UI.button("Calibrar offset (toque no ritmo)", _calibrate, 66.0))
	cal_lab = UI.label("", 20, UI.GOLD)
	box.add_child(cal_lab)
	box.add_child(UI.label("Gameplay", 30, UI.accent()))
	UI.slider(box, "Sensibilidade (janela de acerto)", 0.8, 1.4, 0.05, G.sensitivity, func(v: float): G.sensitivity = v)
	UI.slider(box, "Pistas padrao (Magic Rhythm)", 3.0, 6.0, 1.0, float(G.lanes), func(v: float): G.lanes = int(v))
	UI.toggle(box, "Assistencia (perdoa 1 queda por tentativa)", G.assists, func(v: bool): G.assists = v)
	box.add_child(UI.label("Graficos", 30, UI.accent()))
	UI.toggle(box, "Particulas", G.particles, func(v: bool): G.particles = v)
	UI.toggle(box, "Brilho", G.glow, func(v: bool): G.glow = v)
	UI.options(box, "Qualidade dos efeitos", ["Baixa", "Media", "Alta"], G.effects_quality, func(i: int): G.effects_quality = i)
	box.add_child(UI.label("Acessibilidade", 30, UI.accent()))
	UI.toggle(box, "Reduzir flashes", G.reduce_flashes, func(v: bool): G.reduce_flashes = v)
	UI.toggle(box, "Reduzir particulas", G.reduce_particles, func(v: bool): G.reduce_particles = v)
	UI.toggle(box, "Alto contraste", G.high_contrast, func(v: bool): G.high_contrast = v)
	UI.toggle(box, "Feedback alternativo (vibracao)", G.alt_feedback, func(v: bool): G.alt_feedback = v)


func _set_music(v: float) -> void:
	GameSettings.music_volume = v
	AudioManager.apply_volumes()


func _set_sfx(v: float) -> void:
	GameSettings.sfx_volume = v
	AudioManager.apply_volumes()


func _back() -> void:
	GameSettings.save_settings()
	GameManager.goto("menu")


# ---- calibracao: 8 cliques a 100 BPM; mede o atraso medio entre clique e toque
func _calibrate() -> void:
	cal = {"on": true, "clicks": [], "taps": [], "t0": Time.get_ticks_msec() / 1000.0, "n": 0}
	cal_lab.text = "Toque na tela junto de cada clique (8 cliques)..."
	set_process(true)


func _process(_d: float) -> void:
	if not cal["on"]:
		return
	var now: float = Time.get_ticks_msec() / 1000.0 - float(cal["t0"])
	var n: int = int(cal["n"])
	if n < 8 and now >= 1.0 + float(n) * 0.6:
		cal["clicks"].append(1.0 + float(n) * 0.6)
		AudioManager.play_sfx("ui")
		cal["n"] = n + 1
	elif n >= 8 and now > 1.0 + 8.0 * 0.6 + 0.5:
		cal["on"] = false
		var diffs: Array = []
		for tp in cal["taps"]:
			var best := 9.0
			for c in cal["clicks"]:
				if absf(float(tp) - float(c)) < absf(best):
					best = float(tp) - float(c)
			if absf(best) < 0.3:
				diffs.append(best)
		if diffs.size() >= 4:
			var s := 0.0
			for d in diffs:
				s += float(d)
			var avg_ms: float = s / float(diffs.size()) * 1000.0
			GameSettings.audio_offset_ms = clampf(-avg_ms, -200.0, 200.0)
			cal_lab.text = "Atraso medio: %d ms. Offset ajustado para %d ms." % [int(avg_ms), int(GameSettings.audio_offset_ms)]
		else:
			cal_lab.text = "Toques insuficientes; tente novamente."


func _input(event: InputEvent) -> void:
	if cal["on"] and event is InputEventScreenTouch and event.pressed:
		cal["taps"].append(Time.get_ticks_msec() / 1000.0 - float(cal["t0"]))
