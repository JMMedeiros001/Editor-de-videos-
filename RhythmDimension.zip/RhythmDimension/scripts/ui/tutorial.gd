extends Control
## Tutorial em paginas.
var args: Dictionary = {}
var page := 0
var lab: Label
const PAGES := [
	"GEOMETRY RUN\nSeu personagem corre sozinho. Toque/segure para pular ou controlar a forma. Cubo: pula. Nave: segure para subir. Bola: toque inverte a gravidade. Robo: segure para pular mais alto. Aranha: toque teleporta entre piso e teto. Onda: segure sobe, solte desce. Espinhos e laterais de blocos matam; o topo dos blocos e seguro.",
	"MAGIC RHYTHM\nToque nas notas quando cruzarem a linha. Nota longa: mantenha ate o fim. Dupla: toque duas pistas juntas. Deslizante: arraste acompanhando o caminho. Perfect/Great/Good/Miss valem pontos e combo (multiplicador sobe a cada 25).",
	"MUSIC DASH\nCorrida de plataforma que alterna com trechos de notas (3 linhas). Nos trechos de notas, toque na altura certa da tela.",
	"IMPORTAR MUSICAS\nMinhas musicas > Importar. O jogo analisa o ritmo no proprio aparelho (nada e enviado). O BPM e aproximado: ajuste se a sincronia ficar estranha. Depois: Criar fase > escolha modo, dificuldade, estilo e trecho.",
	"VALIDACAO\nToda fase gerada passa por testes automaticos (estrutura, colisao, tempo, simulacao fisica). So fases READY podem ser jogadas oficialmente. A previa permite testar um trecho validado enquanto a fase e gerada.",
	"CALIBRACAO\nEm Configuracoes > Calibrar offset, toque no ritmo do metronomo para compensar a latencia do seu aparelho/fones.",
]


func _ready() -> void:
	var box := UI.screen(self, "Tutorial", func(): _done())
	lab = UI.label("", 26)
	box.add_child(lab)
	var hb := HBoxContainer.new()
	var prev := UI.button("< Anterior", _prev, 64.0)
	var nxt := UI.button("Proxima >", _next, 64.0)
	prev.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	nxt.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	hb.add_child(prev)
	hb.add_child(nxt)
	box.add_child(hb)
	_show()


func _prev() -> void:
	page = maxi(page - 1, 0)
	_show()


func _next() -> void:
	page = mini(page + 1, PAGES.size() - 1)
	_show()


func _show() -> void:
	lab.text = "(%d/%d)\n\n%s" % [page + 1, PAGES.size(), PAGES[page]]


func _done() -> void:
	GameSettings.onboarding_done = true
	GameSettings.save_settings()
	GameManager.goto("menu")
