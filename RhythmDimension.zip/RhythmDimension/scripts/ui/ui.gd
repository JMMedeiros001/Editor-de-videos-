class_name UI
extends RefCounted
## Utilidades de interface (tema neon escuro, botoes grandes para toque).

const BG := Color(0.03, 0.04, 0.08)
const PANEL := Color(0.08, 0.10, 0.17)
const CYAN := Color(0.0, 0.9, 1.0)
const MAGENTA := Color(1.0, 0.2, 0.7)
const GOLD := Color(1.0, 0.82, 0.2)


static func accent() -> Color:
	return Color(GameSettings.accent)


static func make_theme() -> Theme:
	var th := Theme.new()
	for st in ["normal", "hover", "pressed", "focus", "disabled"]:
		var sb := StyleBoxFlat.new()
		sb.bg_color = PANEL if st != "pressed" else Color(0.0, 0.35, 0.45)
		sb.border_color = accent() if st != "disabled" else Color(0.3, 0.3, 0.35)
		sb.set_border_width_all(2)
		sb.set_corner_radius_all(10)
		sb.content_margin_left = 16
		sb.content_margin_right = 16
		sb.content_margin_top = 12
		sb.content_margin_bottom = 12
		th.set_stylebox(st, "Button", sb)
	th.set_font_size("font_size", "Button", 26)
	th.set_font_size("font_size", "Label", 24)
	th.set_color("font_color", "Label", Color(0.9, 0.95, 1.0))
	th.set_color("font_color", "Button", Color(0.9, 0.95, 1.0))
	th.set_color("font_disabled_color", "Button", Color(0.5, 0.5, 0.55))
	return th


static func label(text: String, size: int = 24, color: Color = Color(0.9, 0.95, 1.0), align: int = HORIZONTAL_ALIGNMENT_LEFT) -> Label:
	var l := Label.new()
	l.text = text
	l.horizontal_alignment = align
	l.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	l.add_theme_font_size_override("font_size", size)
	l.add_theme_color_override("font_color", color)
	return l


static func button(text: String, cb: Callable, min_h: float = 64.0) -> Button:
	var b := Button.new()
	b.text = text
	b.custom_minimum_size = Vector2(0, min_h)
	b.pressed.connect(cb)
	return b


## Tela padrao: titulo + area rolavel + botao Voltar. Retorna o VBox de conteudo.
static func screen(root: Control, title: String, back: Callable) -> VBoxContainer:
	var margin := MarginContainer.new()
	margin.set_anchors_preset(Control.PRESET_FULL_RECT)
	for s in ["left", "right", "top", "bottom"]:
		margin.add_theme_constant_override("margin_" + s, 24)
	root.add_child(margin)
	var outer := VBoxContainer.new()
	outer.add_theme_constant_override("separation", 12)
	margin.add_child(outer)
	outer.add_child(label(title, 38, accent()))
	var sc := ScrollContainer.new()
	sc.size_flags_vertical = Control.SIZE_EXPAND_FILL
	sc.horizontal_scroll_mode = ScrollContainer.SCROLL_MODE_DISABLED
	outer.add_child(sc)
	var inner := VBoxContainer.new()
	inner.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	inner.add_theme_constant_override("separation", 10)
	sc.add_child(inner)
	if back.is_valid():
		outer.add_child(button("< Voltar", back, 56.0))
	return inner


static func slider(parent: Control, text: String, vmin: float, vmax: float, step: float, value: float, cb: Callable) -> HSlider:
	var box := VBoxContainer.new()
	var lab := label("%s: %s" % [text, str(snappedf(value, step))], 22)
	box.add_child(lab)
	var s := HSlider.new()
	s.min_value = vmin
	s.max_value = vmax
	s.step = step
	s.value = value
	s.custom_minimum_size = Vector2(0, 44)
	s.value_changed.connect(func(v: float):
		lab.text = "%s: %s" % [text, str(snappedf(v, step))]
		cb.call(v))
	box.add_child(s)
	parent.add_child(box)
	return s


static func toggle(parent: Control, text: String, value: bool, cb: Callable) -> CheckButton:
	var c := CheckButton.new()
	c.text = text
	c.button_pressed = value
	c.custom_minimum_size = Vector2(0, 56)
	c.toggled.connect(cb)
	parent.add_child(c)
	return c


static func options(parent: Control, text: String, items: Array, selected: int, cb: Callable) -> OptionButton:
	var box := HBoxContainer.new()
	box.add_child(label(text + ": ", 22))
	var ob := OptionButton.new()
	ob.custom_minimum_size = Vector2(0, 56)
	ob.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	for it in items:
		ob.add_item(String(it))
	ob.select(selected)
	ob.item_selected.connect(cb)
	box.add_child(ob)
	parent.add_child(box)
	return ob


static func status_color(status: String) -> Color:
	match status:
		"READY": return Color(0.3, 1.0, 0.5)
		"FAILED": return Color(1.0, 0.3, 0.3)
		"UNVERIFIED": return Color(1.0, 0.8, 0.2)
		"PREVIEW": return Color(0.5, 0.8, 1.0)
	return Color(0.7, 0.7, 0.8)
