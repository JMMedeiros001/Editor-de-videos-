extends Control
## Raiz da interface: tema escuro/neon, troca de telas e avisos (toast). Todas as telas sao construidas por codigo.

var current: Control = null
var toast_label: Label
var toast_timer := 0.0


func _ready() -> void:
	GameManager.main = self
	theme = UI.make_theme()
	var bg := ColorRect.new()
	bg.color = Color(0.03, 0.04, 0.08)
	bg.set_anchors_preset(Control.PRESET_FULL_RECT)
	bg.mouse_filter = Control.MOUSE_FILTER_IGNORE
	add_child(bg)
	toast_label = Label.new()
	toast_label.set_anchors_preset(Control.PRESET_CENTER_BOTTOM)
	toast_label.position = Vector2(-300, -120)
	toast_label.custom_minimum_size = Vector2(600, 0)
	toast_label.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	toast_label.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	toast_label.add_theme_color_override("font_color", Color(1, 0.9, 0.4))
	toast_label.z_index = 100
	toast_label.visible = false
	add_child(toast_label)
	if SaveManager.recovered_from_backup:
		toast("Progresso recuperado do backup.")
	GameManager.goto("menu")


func show_screen(path: String, args: Dictionary) -> void:
	if current != null:
		current.queue_free()
		current = null
	var scr: Script = load(path)
	var s: Control = scr.new()
	s.set("args", args)
	s.set_anchors_preset(Control.PRESET_FULL_RECT)
	add_child(s)
	current = s


func toast(msg: String) -> void:
	toast_label.text = msg
	toast_label.visible = true
	toast_timer = 3.5


func _process(delta: float) -> void:
	if toast_timer > 0.0:
		toast_timer -= delta
		if toast_timer <= 0.0:
			toast_label.visible = false


func _notification(what: int) -> void:
	if what == NOTIFICATION_WM_GO_BACK_REQUEST and current != null and current.has_method("on_back"):
		current.on_back()
