extends Control
## Configuracao da fase a partir de uma musica: modo, dificuldade, estilo, trecho, pistas, seed -> gerar.
var args: Dictionary = {}
var song: Dictionary
var an: Dictionary
var cfg := {"mode": "geometry_run", "difficulty": "normal", "style": "balanced", "lanes": 4, "seed": 1, "trim_on": false}
var trim_a := 0.0
var trim_b := 0.0
var custom := {"speed": "normal", "min_gap_s": 0.6, "density": 0.7}
var custom_box: VBoxContainer
var lanes_row: Control


func _ready() -> void:
	song = SaveManager.get_song(String(args.get("song_id", "")))
	an = MySongs.load_analysis(String(song.get("id", "")))
	if song.is_empty() or an.is_empty():
		var b0 := UI.screen(self, "Criar fase", func(): GameManager.goto("songs"))
		b0.add_child(UI.label("Esta musica ainda nao foi analisada. Volte em Minhas musicas e aguarde a analise.", 24))
		return
	cfg["seed"] = randi() % 1000000
	trim_b = float(song["duration"])
	var box := UI.screen(self, "Criar fase", func(): GameManager.goto("songs"))
	box.add_child(UI.label("%s\n%ds  BPM ~%s  confianca %d%%" % [song["name"], int(float(song["duration"])), str(song["bpm"]), int(float(song.get("confidence", 0)) * 100)], 22, UI.GOLD))
	if float(song.get("confidence", 0)) < 0.35:
		box.add_child(UI.label("Aviso: ritmo pouco claro. A sincronizacao pode ficar imprecisa; ajuste o BPM em Minhas musicas.", 20, Color(1, 0.6, 0.3)))
	UI.options(box, "Modo", ["Geometry Run", "Magic Rhythm", "Music Dash"], 0, func(i: int):
		cfg["mode"] = ["geometry_run", "magic_rhythm", "music_dash"][i]
		lanes_row.visible = i == 1)
	UI.options(box, "Dificuldade", ["Beginner", "Normal", "Hard", "Expert", "Insane", "Custom"], 1, func(i: int):
		cfg["difficulty"] = ["beginner", "normal", "hard", "expert", "insane", "custom"][i]
		custom_box.visible = i == 5)
	UI.options(box, "Estilo", ["Equilibrado", "Mais obstaculos", "Mais notas", "Mais velocidade", "Mais precisao", "Mais variacoes", "Aleatorio controlado"], 0,
			func(i: int): cfg["style"] = RD.STYLES[i])
	var lr := VBoxContainer.new()
	UI.options(lr, "Pistas (Magic Rhythm)", ["3", "4", "5", "6"], 1, func(i: int): cfg["lanes"] = 3 + i)
	lr.visible = false
	lanes_row = lr
	box.add_child(lr)
	custom_box = VBoxContainer.new()
	custom_box.visible = false
	UI.options(custom_box, "Velocidade", ["slow", "normal", "fast", "faster"], 1, func(i: int): custom["speed"] = ["slow", "normal", "fast", "faster"][i])
	UI.slider(custom_box, "Espacamento minimo (s)", 0.3, 1.2, 0.05, 0.6, func(v: float): custom["min_gap_s"] = v)
	UI.slider(custom_box, "Densidade", 0.2, 1.0, 0.05, 0.7, func(v: float): custom["density"] = v)
	box.add_child(custom_box)
	UI.toggle(box, "Usar apenas um trecho da musica", false, func(v: bool): cfg["trim_on"] = v)
	UI.slider(box, "Inicio do trecho (s)", 0.0, maxf(float(song["duration"]) - 20.0, 1.0), 1.0, 0.0, func(v: float): trim_a = v)
	UI.slider(box, "Fim do trecho (s)", 20.0, float(song["duration"]), 1.0, float(song["duration"]), func(v: float): trim_b = v)
	var seed_row := HBoxContainer.new()
	seed_row.add_child(UI.label("Seed: ", 22))
	var le := LineEdit.new()
	le.text = str(cfg["seed"])
	le.custom_minimum_size = Vector2(220, 56)
	le.text_changed.connect(func(tx: String): cfg["seed"] = int(tx))
	seed_row.add_child(le)
	box.add_child(seed_row)
	box.add_child(UI.button("GERAR FASE", _generate, 84.0))


func _generate() -> void:
	var c: Dictionary = {"mode": cfg["mode"], "difficulty": cfg["difficulty"], "style": cfg["style"], "seed": int(cfg["seed"]), "lanes": int(cfg["lanes"]),
			"name": String(song["name"]), "song_id": String(song["id"])}
	if cfg["difficulty"] == "custom":
		c["custom"] = custom.duplicate()
	if bool(cfg["trim_on"]):
		if trim_b - trim_a < 20.0:
			GameManager.toast("O trecho precisa ter ao menos 20 segundos.")
			return
		c["trim"] = [trim_a, trim_b]
	GameManager.goto("loading", {"cfg": c, "analysis": an, "song": song})
