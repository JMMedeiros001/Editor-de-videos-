extends Control
## Resultados: pontuacao, precisao, maior combo, Perfect/Great/Good/Miss, tempo, classificacao.
var args: Dictionary = {}


func _ready() -> void:
	var r: Dictionary = args["result"]
	var box := UI.screen(self, "Resultados", Callable())
	var done: bool = bool(r.get("completed", false))
	box.add_child(UI.label(String(r.get("level_name", "")) + ("  (PRATICA)" if r.get("practice", false) else "") + ("  (PREVIA)" if r.get("preview", false) else ""), 26, UI.GOLD))
	box.add_child(UI.label("Classificacao: %s" % r.get("rank", "-"), 64, UI.accent(), HORIZONTAL_ALIGNMENT_CENTER))
	box.add_child(UI.label("FASE CONCLUIDA" if done else "Nao concluida (%d%%)" % int(float(r.get("progress", 0.0)) * 100.0), 28, Color(0.4, 1, 0.6) if done else Color(1, 0.5, 0.4), HORIZONTAL_ALIGNMENT_CENTER))
	var lines := ["Pontuacao: %d" % int(r.get("score", 0)), "Precisao: %s%%" % str(r.get("accuracy", 0)), "Maior combo: %d" % int(r.get("max_combo", 0)),
			"Perfect: %d   Great: %d   Good: %d   Miss: %d" % [int(r.get("perfect", 0)), int(r.get("great", 0)), int(r.get("good", 0)), int(r.get("miss", 0))],
			"Tempo: %.1fs" % float(r.get("time", 0.0))]
	if r.has("attempts"):
		lines.append("Tentativas: %d   Quedas: %d" % [int(r["attempts"]), int(r.get("deaths", 0))])
	for l in lines:
		box.add_child(UI.label(l, 26))
	if r.get("new_record", false):
		box.add_child(UI.label("NOVO RECORDE!", 34, UI.GOLD, HORIZONTAL_ALIGNMENT_CENTER))
	for a in r.get("achievements", []):
		box.add_child(UI.label("Conquista: " + String(a), 24, UI.GOLD))
	if r.get("practice", false):
		box.add_child(UI.label("Modo pratica: recordes nao foram alterados.", 20, Color(0.7, 0.8, 0.9)))
	var pa: Dictionary = args["play_args"]
	box.add_child(UI.button("Tentar novamente", func(): GameManager.start_level(pa["map"], pa.get("opts", {})), 76.0))
	if r.has("replay_path"):
		box.add_child(UI.button("Assistir replay", func(): _replay(String(r["replay_path"]), pa), 70.0))
	box.add_child(UI.button("Menu", func(): GameManager.goto("menu"), 70.0))


func _replay(path: String, pa: Dictionary) -> void:
	var rp := ReplayManager.load_replay(path)
	if rp == null:
		GameManager.toast("Replay nao encontrado.")
		return
	if String(pa["map"].get("mode", "")) == "magic_rhythm":
		GameManager.toast("Replay de notas: somente os julgamentos foram gravados (sem reproducao visual).")
		return
	var o: Dictionary = (pa.get("opts", {}) as Dictionary).duplicate()
	o["replay"] = rp
	GameManager.start_level(pa["map"], o)
