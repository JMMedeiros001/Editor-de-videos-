extends Control
## Carregamento/geracao com progresso REAL (etapas executadas de verdade), previa validada e acoes finais.
## Botoes: TESTAR FASE (previa segura, mesmo durante a geracao), JOGAR (somente READY), EDITAR, SALVAR, REGERAR.
var args: Dictionary = {}
var job: GenerationJob
var cfg: Dictionary
var an: Dictionary
var song: Dictionary
var prog: ProgressBar
var stage_lab: Label
var status_lab: Label
var log_lab: Label
var test_btn: Button
var actions: VBoxContainer
var report_lab: Label
var finished := false


func _ready() -> void:
	cfg = args["cfg"]
	an = args["analysis"]
	song = args.get("song", {})
	var box := UI.screen(self, "Preparando fase", Callable())
	box.add_child(UI.label("Musica: %s" % song.get("name", "-"), 24))
	box.add_child(UI.label("Modo: %s   Dificuldade: %s   Estilo: %s   Seed: %s" % [str(cfg["mode"]).replace("_", " "), str(cfg["difficulty"]).to_upper(), cfg.get("style", "balanced"), str(cfg.get("seed", 1))], 20, Color(0.7, 0.8, 0.95)))
	stage_lab = UI.label("Iniciando...", 24, UI.GOLD)
	box.add_child(stage_lab)
	prog = ProgressBar.new()
	prog.custom_minimum_size = Vector2(0, 32)
	box.add_child(prog)
	status_lab = UI.label("Status: GENERATING", 26)
	box.add_child(status_lab)
	log_lab = UI.label("", 18, Color(0.65, 0.7, 0.8))
	box.add_child(log_lab)
	test_btn = UI.button("TESTAR FASE (previa)", _test_preview, 76.0)
	test_btn.visible = false
	box.add_child(test_btn)
	report_lab = UI.label("", 20)
	box.add_child(report_lab)
	actions = VBoxContainer.new()
	box.add_child(actions)
	job = GenerationJob.new()
	job.start(an, cfg)


func _process(_d: float) -> void:
	if job == null or finished:
		return
	stage_lab.text = "[%d/%d] %s" % [job.step, job.steps_total, job.stage]
	prog.value = job.progress * 100.0
	status_lab.text = "Status: " + job.status
	status_lab.add_theme_color_override("font_color", UI.status_color(job.status))
	log_lab.text = "\n".join(job.log)
	if job.preview_ready and not test_btn.visible and not job.done:
		test_btn.visible = true
	if job.poll():
		finished = true
		_finish()


func _test_preview() -> void:
	if job.preview_map.is_empty():
		return
	var pm: Dictionary = job.preview_map.duplicate(true)
	_prep(pm)
	GameManager.start_level(pm, {"preview": true})


func _prep(m: Dictionary) -> void:
	m["song_id"] = cfg.get("song_id", "")
	if cfg.get("endless", false) or cfg["mode"] == "endless":
		m["audio"]["file"] = "res://assets/music/endless_loop.ogg"


func _finish() -> void:
	var m: Dictionary = job.map
	_prep(m)
	var rep: Dictionary = job.report
	test_btn.visible = false
	var st: String = String(rep["status"])
	status_lab.text = "Status: %s   (%s)" % [st, rep["result"]]
	status_lab.add_theme_color_override("font_color", UI.status_color(st))
	var c: Dictionary = rep["counts"]
	var txt := "Testes: %d aprovados, %d avisos, %d falhas, %d nao verificados   |   Dificuldade estimada (heuristica): %s\n" % [c["pass"], c["warn"], c["fail"], c["unverified"], str(rep["difficulty_estimate"])]
	txt += "Correcoes automaticas aplicadas: %d\n" % job.history.size()
	for t in rep["tests"]:
		if t["status"] != "pass":
			txt += "- [%s] %s: %s\n" % [str(t["status"]).to_upper(), t["name"], t["detail"]]
	if st == "READY":
		txt += "\nFase validada tecnicamente. Isso NAO garante que seja divertida: teste e ajuste no editor."
	else:
		txt += "\nFase BLOQUEADA para jogo oficial. Voce pode testar a previa, editar manualmente ou regerar."
	report_lab.text = txt
	for ch in actions.get_children():
		ch.queue_free()
	if not job.preview_map.is_empty():
		actions.add_child(UI.button("TESTAR (previa)", _test_preview, 70.0))
	var play := UI.button("JOGAR", func(): GameManager.start_level(m, {}), 76.0)
	play.disabled = st != "READY"
	actions.add_child(play)
	actions.add_child(UI.button("EDITAR", func(): GameManager.goto("editor", {"map": m}), 70.0))
	actions.add_child(UI.button("SALVAR na biblioteca", func(): _save(m), 70.0))
	actions.add_child(UI.button("REGERAR (nova seed)", _regen, 70.0))
	actions.add_child(UI.button("< Voltar", func(): GameManager.goto("songs" if not cfg.get("endless", false) else "play"), 60.0))


func _save(m: Dictionary) -> void:
	m["name"] = "%s - %s %s" % [m.get("name", "Fase"), str(m["mode"]).replace("_", " "), str(m["difficulty"])]
	SaveManager.save_level(m)
	SaveManager.award("primeira_criada")
	GameManager.toast("Fase salva (%s)." % m["status"])


func _regen() -> void:
	var c: Dictionary = cfg.duplicate(true)
	c["seed"] = randi() % 1000000
	GameManager.goto("loading", {"cfg": c, "analysis": an, "song": song, "endless": args.get("endless", false)})
