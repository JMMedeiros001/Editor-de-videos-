extends Control
## Jogar: fases oficiais (com recordes), Endless e Free Play (suas musicas).
var args: Dictionary = {}


func _ready() -> void:
	var box := UI.screen(self, "Jogar", func(): GameManager.goto("menu"))
	box.add_child(UI.label("Fases oficiais", 28, UI.GOLD))
	for e in GameManager.official_levels():
		var rec: Dictionary = SaveManager.data["records"].get(e["id"], {})
		var txt := "%s  [%s - %s]" % [e["name"], String(e["mode"]).replace("_", " "), String(e["difficulty"]).to_upper()]
		if not rec.is_empty():
			txt += "\nRecorde %d  %s  (%d%%)" % [int(rec["best_score"]), rec["best_rank"], int(float(rec["best_progress"]) * 100.0)]
		var row := VBoxContainer.new()
		row.add_child(UI.label(txt, 24))
		var hb := HBoxContainer.new()
		var play := UI.button("Jogar", func(): _play(e, false), 64.0)
		play.size_flags_horizontal = Control.SIZE_EXPAND_FILL
		var prac := UI.button("Pratica", func(): _play(e, true), 64.0)
		prac.size_flags_horizontal = Control.SIZE_EXPAND_FILL
		hb.add_child(play)
		hb.add_child(prac)
		row.add_child(hb)
		box.add_child(row)
	box.add_child(UI.label("Outros modos", 28, UI.GOLD))
	box.add_child(UI.button("Endless Rhythm (dificuldade progressiva)", _endless, 72.0))
	box.add_child(UI.button("Free Play: usar minhas musicas", func(): GameManager.goto("songs"), 72.0))


func _play(e: Dictionary, practice: bool) -> void:
	var m := GameManager.load_official(e)
	if m.is_empty():
		GameManager.toast("Nao foi possivel carregar a fase.")
		return
	if m.get("status", "") != "READY":
		GameManager.toast("Fase nao validada: bloqueada para jogo oficial.")
		return
	GameManager.start_level(m, {"practice": practice})


func _endless() -> void:
	GameManager.goto("loading", {"cfg": {"mode": "endless", "difficulty": "beginner", "style": "balanced", "seed": randi() % 100000, "name": "Endless Rhythm"},
			"analysis": LevelGenerator.synthetic_analysis(128.0, 100, true), "song": {"name": "Trilha do Endless", "id": ""}, "endless": true})
