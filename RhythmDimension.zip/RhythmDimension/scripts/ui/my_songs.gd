class_name MySongs
extends Control
## Minhas musicas: importar (seletor de arquivos do sistema), validar, previa, analise (BPM ajustavel), criar fase.
## As musicas permanecem no dispositivo. A biblioteca guarda a referencia (caminho) e, opcionalmente, uma copia local privada.
var args: Dictionary = {}
var list_box: VBoxContainer
var job: AnalysisJob = null
var job_song := ""
var prog: ProgressBar
var stage_lab: Label
var dialog: FileDialog
var preview_id := ""
var relink_id := ""


func _ready() -> void:
	relink_id = String(args.get("relink", ""))
	var box := UI.screen(self, "Minhas musicas", func(): _back())
	box.add_child(UI.button("+ Importar musica (MP3, WAV, OGG)", _import, 76.0))
	box.add_child(UI.label("FLAC nao e suportado pelo Godot 4: converta para OGG, MP3 ou WAV.", 18, Color(0.7, 0.75, 0.85)))
	stage_lab = UI.label("", 20, UI.GOLD)
	prog = ProgressBar.new()
	prog.custom_minimum_size = Vector2(0, 24)
	prog.visible = false
	box.add_child(stage_lab)
	box.add_child(prog)
	list_box = VBoxContainer.new()
	list_box.add_theme_constant_override("separation", 14)
	box.add_child(list_box)
	if relink_id != "":
		GameManager.toast("Arquivo nao encontrado: selecione a musica novamente.")
		_import()
	_refresh()


func _back() -> void:
	AudioManager.stop()
	GameManager.goto("menu")


func _import() -> void:
	dialog = FileDialog.new()
	dialog.file_mode = FileDialog.FILE_MODE_OPEN_FILE
	dialog.access = FileDialog.ACCESS_FILESYSTEM
	dialog.use_native_dialog = true      # seletor nativo (SAF no Android, sem pedir acesso amplo ao armazenamento)
	dialog.filters = PackedStringArray(["*.mp3, *.wav, *.ogg ; Audio"])
	dialog.title = "Escolha uma musica"
	dialog.file_selected.connect(_on_file)
	add_child(dialog)
	dialog.popup_centered_ratio(0.9)


func _on_file(path: String) -> void:
	var chk := MusicImporter.validate_file(path)
	if not chk["ok"]:
		GameManager.toast(String(chk["error"]))
		return
	var st := MusicImporter.load_stream(path)
	if not st["ok"]:
		GameManager.toast(String(st["error"]))
		return
	var id := relink_id if relink_id != "" else "song_%d" % (Time.get_ticks_usec() % 100000000)
	var local := MusicImporter.cache_copy(path, id)
	var info := {"id": id, "name": path.get_file().get_basename(), "duration": snappedf(float(st["duration"]), 0.1), "format": String(chk["ext"]),
			"path": path, "local": local, "bpm": 0.0, "offset": 0.0, "confidence": 0.0, "analyzed": false}
	if relink_id != "":
		SaveManager.update_song(id, {"path": path, "local": local})
		relink_id = ""
	else:
		SaveManager.add_song(info)
		SaveManager.award("primeira_musica")
	_analyze(id, st["stream"], path)
	_refresh()


func _analyze(id: String, stream: AudioStream, path: String) -> void:
	job = AnalysisJob.new()
	job_song = id
	job.start_stream(stream, path)
	prog.visible = true
	set_process(true)


func _process(_d: float) -> void:
	if job == null:
		return
	stage_lab.text = job.stage
	prog.value = job.progress * 100.0
	if job.poll():
		var r := job.result
		job = null
		prog.visible = false
		stage_lab.text = ""
		if r.get("needs_capture", false):
			_capture_fallback()
		elif r.get("ok", false):
			_save_analysis(job_song, r)
		else:
			GameManager.toast("Falha na analise: " + String(r.get("error", "?")))
		_refresh()


func _capture_fallback() -> void:
	var song := SaveManager.get_song(job_song)
	var st := MusicImporter.load_stream(String(song.get("local", "")) if String(song.get("local", "")) != "" else String(song["path"]))
	if not st["ok"]:
		return
	stage_lab.text = "Analisando por captura em tempo real (dura o tempo da musica)"
	prog.visible = true
	var cap: Dictionary = await AudioManager.capture_pcm(st["stream"], func(p: float): prog.value = p * 70.0)
	if not cap["ok"]:
		GameManager.toast("Nao foi possivel decodificar este arquivo. Converta para OGG ou WAV.")
		prog.visible = false
		return
	job = AnalysisJob.new()
	job.start_samples(cap["samples"], float(cap["sr"]))
	set_process(true)


func _save_analysis(id: String, r: Dictionary) -> void:
	DirAccess.make_dir_recursive_absolute("user://analysis")
	RD.write_json("user://analysis/%s.json" % id, r)
	SaveManager.update_song(id, {"bpm": r["bpm"], "offset": r["offset"], "confidence": r["confidence"], "analyzed": true})


static func load_analysis(id: String) -> Dictionary:
	var d: Variant = RD.read_json("user://analysis/%s.json" % id)
	if not (d is Dictionary):
		return {}
	var song := SaveManager.get_song(id)
	if not song.is_empty():
		d["bpm"] = float(song.get("bpm", d["bpm"]))
		d["offset"] = float(song.get("offset", d["offset"]))
	return d


func _refresh() -> void:
	for c in list_box.get_children():
		c.queue_free()
	for s in SaveManager.data["songs"]:
		var box := VBoxContainer.new()
		var conf: float = float(s.get("confidence", 0.0))
		var txt := "%s\n%ds  %s" % [s["name"], int(float(s["duration"])), String(s["format"]).to_upper()]
		if bool(s.get("analyzed", false)):
			txt += "  BPM ~%s (confianca %d%%)" % [str(s["bpm"]), int(conf * 100.0)]
			if conf < 0.35:
				txt += "\nAviso: ritmo pouco claro. Ajuste o BPM manualmente."
		else:
			txt += "  (nao analisada)"
		box.add_child(UI.label(txt, 22))
		var hb := HBoxContainer.new()
		for it in [["Previa", func(): _preview(s)], ["Criar fase", func(): GameManager.goto("setup", {"song_id": s["id"]})],
				["Ajustar BPM", func(): _adjust(s)], ["Excluir", func(): _delete(String(s["id"]))]]:
			var b := UI.button(it[0], it[1], 58.0)
			b.size_flags_horizontal = Control.SIZE_EXPAND_FILL
			b.add_theme_font_size_override("font_size", 20)
			hb.add_child(b)
		box.add_child(hb)
		list_box.add_child(box)
	if (SaveManager.data["songs"] as Array).is_empty():
		list_box.add_child(UI.label("Nenhuma musica ainda. Importe uma para gerar fases.", 22))


func _preview(s: Dictionary) -> void:
	if preview_id == String(s["id"]):
		AudioManager.stop()
		preview_id = ""
		return
	var st := GameManager.stream_for_map({"song_id": s["id"], "audio": {}})
	if not st["ok"]:
		GameManager.toast(String(st["error"]))
		return
	AudioManager.play(st["stream"], 0.0)
	preview_id = String(s["id"])


func _delete(id: String) -> void:
	SaveManager.remove_song(id)
	_refresh()


func _adjust(s: Dictionary) -> void:
	var win := ConfirmationDialog.new()
	win.title = "Ajustar BPM e offset"
	var v := VBoxContainer.new()
	var an := load_analysis(String(s["id"]))
	var st := {"bpm": float(s.get("bpm", 120.0)), "off": float(s.get("offset", 0.0))}   # dicionario: lambdas capturam por valor
	var lab := UI.label("", 22)
	v.add_child(lab)
	var alts: String = str(an.get("bpm_alternatives", []))
	var upd := func():
		lab.text = "BPM %.2f   offset %.3fs   (alternativas: %s)" % [st["bpm"], st["off"], alts]
	upd.call()
	var row := HBoxContainer.new()
	for it in [["-1", -1.0], ["+1", 1.0], ["/2", 0.5], ["x2", 2.0]]:
		var b := Button.new()
		b.text = it[0]
		b.custom_minimum_size = Vector2(90, 56)
		var mult: float = it[1]
		b.pressed.connect(func():
			if mult == 0.5 or mult == 2.0:
				st["bpm"] = float(st["bpm"]) * mult
			else:
				st["bpm"] = float(st["bpm"]) + mult
			upd.call())
		row.add_child(b)
	v.add_child(row)
	var row2 := HBoxContainer.new()
	for it in [["offset -10ms", -0.01], ["offset +10ms", 0.01]]:
		var b2 := Button.new()
		b2.text = it[0]
		b2.custom_minimum_size = Vector2(160, 56)
		var dv: float = it[1]
		b2.pressed.connect(func():
			st["off"] = maxf(float(st["off"]) + dv, 0.0)
			upd.call())
		row2.add_child(b2)
	v.add_child(row2)
	win.add_child(v)
	win.confirmed.connect(func():
		SaveManager.update_song(String(s["id"]), {"bpm": snappedf(float(st["bpm"]), 0.01), "offset": snappedf(float(st["off"]), 0.001)})
		_refresh())
	add_child(win)
	win.popup_centered(Vector2i(640, 320))
