extends Control
## Estatisticas (gerais e por modo).
var args: Dictionary = {}


func _ready() -> void:
	var box := UI.screen(self, "Estatisticas", func(): GameManager.goto("menu"))
	var st: Dictionary = SaveManager.data["stats"]
	var total: int = int(st["perfect"]) + int(st["great"]) + int(st["good"]) + int(st["miss"])
	box.add_child(UI.label("Partidas: %d\nTempo jogado: %d min\nMaior combo: %d\nPerfect: %d  Great: %d  Good: %d  Miss: %d" % [int(st["games"]), int(float(st["time"]) / 60.0), int(st["best_combo"]),
			int(st["perfect"]), int(st["great"]), int(st["good"]), int(st["miss"])], 26))
	if total > 0:
		box.add_child(UI.label("Precisao geral: %.1f%%" % (100.0 * (st["perfect"] + st["great"] * 0.8 + st["good"] * 0.4) / float(total)), 26, UI.GOLD))
	box.add_child(UI.label("Por modo", 30, UI.accent()))
	var bm: Dictionary = st["by_mode"]
	if bm.is_empty():
		box.add_child(UI.label("Jogue uma fase para ver estatisticas por modo.", 22))
	for k in bm.keys():
		box.add_child(UI.label("%s: %d partidas, melhor pontuacao %d, melhor precisao %s%%, %d min" % [String(k).replace("_", " "), int(bm[k]["games"]), int(bm[k]["best_score"]), str(snappedf(float(bm[k]["best_acc"]), 0.1)), int(float(bm[k]["time"]) / 60.0)], 22))
	box.add_child(UI.label("Nivel %d  (%d XP)   Musicas: %d   Fases salvas: %d" % [SaveManager.level_from_xp(), int(SaveManager.data["xp"]), (SaveManager.data["songs"] as Array).size(), (SaveManager.data["levels"] as Array).size()], 22, UI.GOLD))
