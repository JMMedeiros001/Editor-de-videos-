extends Control
## Personalizacao: formas, cores de destaque e temas. Desbloqueios por progresso (nenhum modo principal exige compra).
var args: Dictionary = {}
const SHAPES := ["cube", "ship", "ball", "robot", "spider", "wave"]
const THEMES := ["neon", "cyberpunk", "espaco", "digital", "minimalista", "cosmico"]
const COLORS := ["#00e5ff", "#ff2fb3", "#ffd23f", "#6cff6c", "#b388ff", "#ff7043"]


func _ready() -> void:
	var box := UI.screen(self, "Personalizacao", func(): GameManager.goto("menu"))
	var unlocked: Array = SaveManager.data["unlocked"]
	for c in COLORS:
		SaveManager.unlock(c)           # cores livres
	for s in ["cube", "ball", "robot"]:
		SaveManager.unlock(s)           # formas basicas livres
	for t in ["neon", "digital", "minimalista"]:
		SaveManager.unlock(t)
	box.add_child(UI.label("Forma do jogador (tema atual: %s)" % GameSettings.theme, 24, UI.GOLD))
	var hb := HFlowContainer.new()
	for s in SHAPES:
		var ok: bool = (SaveManager.data["unlocked"] as Array).has(s)
		var b := UI.button(s if ok else s + " (bloqueada)", func(): _set("shape", s), 60.0)
		b.disabled = not ok
		hb.add_child(b)
	box.add_child(hb)
	box.add_child(UI.label("Tema", 24, UI.GOLD))
	var ht := HFlowContainer.new()
	for t in THEMES:
		var ok2: bool = (SaveManager.data["unlocked"] as Array).has(t)
		var b2 := UI.button(t if ok2 else t + " (bloqueado)", func(): _set("theme", t), 60.0)
		b2.disabled = not ok2
		ht.add_child(b2)
	box.add_child(ht)
	box.add_child(UI.label("Cor de destaque", 24, UI.GOLD))
	var hc := HFlowContainer.new()
	for c2 in COLORS:
		var b3 := Button.new()
		b3.text = "   "
		b3.custom_minimum_size = Vector2(90, 60)
		b3.add_theme_color_override("font_color", Color(c2))
		var sb := StyleBoxFlat.new()
		sb.bg_color = Color(c2)
		sb.set_corner_radius_all(10)
		b3.add_theme_stylebox_override("normal", sb)
		b3.pressed.connect(func(): _set("accent", c2))
		hc.add_child(b3)
	box.add_child(hc)


func _set(key: String, value: String) -> void:
	GameSettings.set(key, value)
	GameSettings.save_settings()
	GameManager.toast("%s: %s" % [key, value])
	GameManager.main.theme = UI.make_theme()
