extends Control
## Desafios: conquistas com progresso real (derivado dos dados salvos).
var args: Dictionary = {}


func _ready() -> void:
	var box := UI.screen(self, "Desafios", func(): GameManager.goto("menu"))
	var st: Dictionary = SaveManager.data["stats"]
	box.add_child(UI.label("Maior combo: %d   Partidas: %d   Perfects: %d" % [int(st["best_combo"]), int(st["games"]), int(st["perfect"])], 22, UI.GOLD))
	for a in SaveManager.achievements_list():
		var col := Color(0.4, 1, 0.6) if a["done"] else Color(0.7, 0.75, 0.85)
		box.add_child(UI.label(("[OK] " if a["done"] else "[  ] ") + String(a["name"]), 26, col))
	box.add_child(UI.label("Desbloqueios: concluir 5 fases diferentes libera a forma Nave e o tema Cyberpunk.", 20, Color(0.7, 0.8, 0.9)))
