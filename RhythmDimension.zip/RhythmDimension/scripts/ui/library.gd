extends Control
## Biblioteca: fases salvas (jogar somente se READY, praticar, editar, excluir) e replays.
var args: Dictionary = {}
var box: VBoxContainer


func _ready() -> void:
	box = UI.screen(self, "Biblioteca", func(): GameManager.goto("menu"))
	_refresh()


func _refresh() -> void:
	for c in box.get_children():
		c.queue_free()
	var lv: Array = SaveManager.data["levels"]
	if lv.is_empty():
		box.add_child(UI.label("Nenhuma fase salva. Crie uma em Minhas musicas > Criar fase.", 24))
	for e in lv:
		var rec: Dictionary = SaveManager.data["records"].get(e["id"], {})
		var t := "%s\n[%s - %s]  status: %s" % [e["name"], String(e["mode"]).replace("_", " "), String(e["difficulty"]).to_upper(), e["status"]]
		if not rec.is_empty():
			t += "   recorde %d %s" % [int(rec["best_score"]), rec["best_rank"]]
		var l := UI.label(t, 22, UI.status_color(String(e["status"])))
		box.add_child(l)
		var hb := HBoxContainer.new()
		var ready: bool = e["status"] == "READY"
		var b1 := UI.button("Jogar", func(): _play(e, false), 58.0)
		b1.disabled = not ready
		var b2 := UI.button("Pratica", func(): _play(e, true), 58.0)
		b2.disabled = not ready
		var b3 := UI.button("Editar", func(): GameManager.goto("editor", {"map": SaveManager.load_level(String(e["id"]))}), 58.0)
		var b4 := UI.button("Excluir", func(): _del(String(e["id"])), 58.0)
		for b in [b1, b2, b3, b4]:
			b.size_flags_horizontal = Control.SIZE_EXPAND_FILL
			b.add_theme_font_size_override("font_size", 20)
			hb.add_child(b)
		box.add_child(hb)
	var dir := DirAccess.open("user://replays")
	if dir != null:
		box.add_child(UI.label("Replays: %d gravados (assistir pela tela de resultados)" % dir.get_files().size(), 20, Color(0.7, 0.8, 0.9)))


func _play(e: Dictionary, practice: bool) -> void:
	var m := SaveManager.load_level(String(e["id"]))
	if m.is_empty():
		GameManager.toast("Arquivo da fase nao encontrado.")
		return
	if m.get("status", "") != "READY":
		GameManager.toast("Fase nao validada (READY): bloqueada.")
		return
	GameManager.start_level(m, {"practice": practice})


func _del(id: String) -> void:
	SaveManager.delete_level(id)
	_refresh()
