extends Control
## Menu principal: todos os botoes abrem telas reais.
var args: Dictionary = {}


func _ready() -> void:
	var box := UI.screen(self, "RHYTHM DIMENSION", Callable())
	box.add_child(UI.label("Nivel %d  -  %d XP" % [SaveManager.level_from_xp(), int(SaveManager.data["xp"])], 22, UI.GOLD))
	var items := [["Jogar", "play"], ["Minhas musicas", "songs"], ["Biblioteca", "library"], ["Editor de fases", "editor"], ["Desafios", "challenges"],
			["Personalizacao", "customize"], ["Estatisticas", "stats"], ["Configuracoes", "settings"], ["Tutorial", "tutorial"]]
	for it in items:
		box.add_child(UI.button(it[0], func(): GameManager.goto(it[1]), 78.0))
	if not GameSettings.onboarding_done:
		GameManager.toast("Primeira vez? Abra o Tutorial e calibre o offset em Configuracoes.")
