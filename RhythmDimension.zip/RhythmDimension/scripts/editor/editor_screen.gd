extends Control
## Editor de fases: linha do tempo com envelope da musica (energia por compasso), grade de batidas e onsets;
## ferramentas para obstaculos, plataformas, portais, notas e velocidade; testar sem sair; validar; salvar/duplicar/renomear.
var args: Dictionary = {}
var ctl := EditorController.new()
var tv: TimelineView
var tool_name := "spike"
var tool_y := 0
var kind := "tap"
var form_sel := "ship"
var snap_on := true
var info: Label
var name_edit: LineEdit
var an: Dictionary = {}
var val_thread: Thread = null
var val_result: Dictionary = {}
var val_prog := 0.0
var val_done := false
var box: VBoxContainer
var playhead := 0.0


class TimelineView extends Control:
	var ed
	var scroll_t := 0.0
	var zoom := 90.0           # px por segundo
	var drag_start := Vector2.ZERO
	var dragging := false

	func _draw() -> void:
		var m: Dictionary = ed.ctl.map
		if m.is_empty():
			return
		var tlm: RhythmMap = ed.ctl.tl()
		var end_t: float = float(m["end_t"])
		var h := size.y
		draw_rect(Rect2(Vector2.ZERO, size), Color(0.05, 0.06, 0.1), true)
		var an: Dictionary = ed.an
		if not an.is_empty():
			var bl: float = float(an["bar_len"])
			var off: float = float(an["offset"]) - float(m["audio"].get("start", 0.0))
			var be: Array = an["bar_energy"]
			for k in range(be.size()):
				var t0: float = off + float(k) * bl
				var x0 := (t0 - scroll_t) * zoom
				if x0 > size.x or x0 + bl * zoom < 0.0:
					continue
				var eh: float = float(be[k]) * (h - 60.0) * 0.5
				draw_rect(Rect2(x0, h - eh, bl * zoom - 1.0, eh), Color(0.15, 0.3, 0.45, 0.6), true)
			var bpm: float = float(m["audio"]["bpm"])
			var beat := 60.0 / bpm
			var b := int(floor((scroll_t - off) / beat))
			while off + float(b) * beat < scroll_t + size.x / zoom:
				var xb := (off + float(b) * beat - scroll_t) * zoom
				draw_line(Vector2(xb, 30), Vector2(xb, h), Color(1, 1, 1, 0.16 if b % 4 != 0 else 0.35), 1.0)
				b += 1
			for o in an["onsets"]:
				var xo := (float(o["t"]) - float(m["audio"].get("start", 0.0)) - scroll_t) * zoom
				if xo > 0.0 and xo < size.x:
					draw_line(Vector2(xo, 30), Vector2(xo, 40), Color(1, 0.8, 0.3, 0.7), 2.0)
		# regua e playhead
		draw_rect(Rect2(0, 0, size.x, 30), Color(0.1, 0.12, 0.2), true)
		for s in range(int(scroll_t), int(scroll_t + size.x / zoom) + 1):
			var xs := (float(s) - scroll_t) * zoom
			draw_string(ThemeDB.fallback_font, Vector2(xs + 2, 20), "%ds" % s, HORIZONTAL_ALIGNMENT_LEFT, -1, 14, Color(0.7, 0.8, 0.9))
		var xe := (end_t - scroll_t) * zoom
		draw_line(Vector2(xe, 0), Vector2(xe, h), Color(1, 0.3, 0.3), 2.0)
		var xp := (ed.playhead - scroll_t) * zoom
		draw_line(Vector2(xp, 0), Vector2(xp, h), Color(0.4, 1, 0.6), 3.0)
		# itens
		var lanes := int(m.get("lanes", 0))
		var is_notes := m.get("mode", "") == "magic_rhythm"
		var row_h := (h - 60.0) / (float(maxi(lanes, 1)) if is_notes else 9.0)
		for o in m["objects"]:
			var ot: float = tlm.t_at(float(o["x"]))
			var ox := (ot - scroll_t) * zoom
			if ox < -40.0 or ox > size.x + 40.0:
				continue
			var oy: float = h - 20.0 - (float(o.get("y", 0)) + 0.5) * row_h
			if o["type"] == "block":
				draw_rect(Rect2(ox, oy - float(o.get("h", 1)) * row_h * 0.5, maxf(float(o.get("w", 1)) / tlm.speed_at(ot) * zoom, 8.0), float(o.get("h", 1)) * row_h), Color(0.3, 0.4, 0.8, 0.8), true)
			else:
				var up: float = -1.0 if not bool(o.get("flip", false)) else 1.0
				draw_colored_polygon(PackedVector2Array([Vector2(ox - 7, oy - 7 * up * -1), Vector2(ox + 7, oy - 7 * up * -1), Vector2(ox, oy + 9 * up * -1)]), Color(1, 0.3, 0.4))
		for n in m["notes"]:
			var nx := (float(n["t"]) - scroll_t) * zoom
			if nx < -40.0 or nx > size.x + 40.0:
				continue
			var ny: float = h - 20.0 - (float(n["lane"]) + 0.5) * row_h
			var wdt: float = maxf(float(n.get("dur", 0.0)) * zoom, 10.0)
			draw_rect(Rect2(nx, ny - row_h * 0.35, wdt, row_h * 0.7), UI.GOLD if n["kind"] == "special" else UI.accent(), true)
		for e in m["form_events"]:
			var fx := (float(e["t"]) - scroll_t) * zoom
			if fx > 0.0 and fx < size.x:
				draw_line(Vector2(fx, 30), Vector2(fx, h), Color(0.9, 0.5, 1.0), 2.0)
				draw_string(ThemeDB.fallback_font, Vector2(fx + 3, 50), String(e["form"]), HORIZONTAL_ALIGNMENT_LEFT, -1, 14, Color(0.9, 0.7, 1.0))
		for e2 in m["speed_events"]:
			var sx := (float(e2["t"]) - scroll_t) * zoom
			if sx > 0.0 and sx < size.x and float(e2["t"]) > 0.0:
				draw_line(Vector2(sx, 30), Vector2(sx, h), Color(1, 0.6, 0.1), 2.0)

	func _gui_input(event: InputEvent) -> void:
		if event is InputEventScreenTouch or (event is InputEventMouseButton and event.button_index == MOUSE_BUTTON_LEFT):
			if event.pressed:
				drag_start = event.position
				dragging = true
			elif dragging:
				dragging = false
				if event.position.distance_to(drag_start) < 14.0:
					ed.on_tap(scroll_t + event.position.x / zoom, event.position, size)
		elif (event is InputEventScreenDrag or event is InputEventMouseMotion) and dragging and event is InputEventScreenDrag:
			scroll_t = maxf(scroll_t - event.relative.x / zoom, 0.0)
			queue_redraw()


func _ready() -> void:
	if not args.has("map"):
		_chooser()
		return
	ctl.load_map(args["map"])
	_build_ui()


func _chooser() -> void:
	var b := UI.screen(self, "Editor de fases", func(): GameManager.goto("menu"))
	b.add_child(UI.label("Abrir fase salva", 26, UI.GOLD))
	for e in SaveManager.data["levels"]:
		b.add_child(UI.button("%s  [%s]" % [e["name"], e["status"]], func(): GameManager.goto("editor", {"map": SaveManager.load_level(String(e["id"]))}), 64.0))
	b.add_child(UI.label("Copiar fase oficial para editar", 26, UI.GOLD))
	for e in GameManager.official_levels():
		b.add_child(UI.button(String(e["name"]), _open_copy.bind(e), 64.0))
	b.add_child(UI.label("Nova fase em branco (escolha a musica)", 26, UI.GOLD))
	for s in SaveManager.data["songs"]:
		if bool(s.get("analyzed", false)):
			b.add_child(UI.button(String(s["name"]) + " - Geometry Run", func(): _blank(s, "geometry_run"), 60.0))
			b.add_child(UI.button(String(s["name"]) + " - Magic Rhythm", func(): _blank(s, "magic_rhythm"), 60.0))


func _open_copy(e: Dictionary) -> void:
	var m := GameManager.load_official(e)
	var c := EditorController.new()
	c.load_map(m)
	GameManager.goto("editor", {"map": c.duplicate_as_new(String(e["name"]) + " (copia)")})


func _set_tool(tname: String) -> void:
	tool_name = tname
	_info()


func _undo() -> void:
	ctl.undo()
	tv.queue_redraw()


func _zoom(f: float) -> void:
	tv.zoom = clampf(tv.zoom * f, 20.0, 400.0)
	tv.queue_redraw()


func _blank(s: Dictionary, mode: String) -> void:
	var a := MySongs.load_analysis(String(s["id"]))
	GameManager.goto("editor", {"map": EditorController.blank_from_analysis(a, s, mode, "normal")})


func _build_ui() -> void:
	var m: Dictionary = ctl.map
	an = MySongs.load_analysis(String(m.get("song_id", ""))) if String(m.get("song_id", "")) != "" else {}
	var margin := MarginContainer.new()
	margin.set_anchors_preset(Control.PRESET_FULL_RECT)
	for s in ["left", "right", "top", "bottom"]:
		margin.add_theme_constant_override("margin_" + s, 12)
	add_child(margin)
	box = VBoxContainer.new()
	box.add_theme_constant_override("separation", 8)
	margin.add_child(box)
	var top := HBoxContainer.new()
	name_edit = LineEdit.new()
	name_edit.text = String(m.get("name", "Fase"))
	name_edit.custom_minimum_size = Vector2(320, 52)
	top.add_child(name_edit)
	top.add_child(_btn("Salvar", _save))
	top.add_child(_btn("Duplicar", _duplicate))
	top.add_child(_btn("Desfazer", _undo))
	top.add_child(_btn("Sair", func(): GameManager.goto("menu")))
	box.add_child(top)
	var tools := HFlowContainer.new()
	var geo := String(m.get("mode", "")) != "magic_rhythm"
	var items: Array = []
	if geo:
		items = [["Espinho", "spike"], ["Espinho teto", "spike_flip"], ["Bloco 1x1", "block1"], ["Bloco 2x2", "block2"], ["Plataforma 4x1", "plat"], ["Portal forma", "form"], ["Portal vel.", "speed"], ["Excluir", "delete"]]
	else:
		items = [["Tap", "n_tap"], ["Hold", "n_hold"], ["Slide", "n_slide"], ["Double", "n_double"], ["Special", "n_special"], ["Excluir", "delete"]]
	for it in items:
		tools.add_child(_btn(it[0], _set_tool.bind(it[1])))
	box.add_child(tools)
	if geo:
		var fo := HBoxContainer.new()
		fo.add_child(UI.label("Forma do portal: ", 20))
		var ob := OptionButton.new()
		for f in ["ship", "ball", "robot", "spider", "wave", "cube", "lanes"]:
			ob.add_item(f)
		ob.item_selected.connect(func(i: int): form_sel = ["ship", "ball", "robot", "spider", "wave", "cube", "lanes"][i])
		fo.add_child(ob)
		box.add_child(fo)
	UI.toggle(box, "Alinhar a grade de batidas", true, func(v: bool): snap_on = v)
	tv = TimelineView.new()
	tv.ed = self
	tv.custom_minimum_size = Vector2(0, 360)
	tv.size_flags_vertical = Control.SIZE_EXPAND_FILL
	tv.clip_contents = true
	box.add_child(tv)
	info = UI.label("", 20, UI.GOLD)
	box.add_child(info)
	var bot := HBoxContainer.new()
	bot.add_child(_btn("Zoom +", _zoom.bind(1.4)))
	bot.add_child(_btn("Zoom -", _zoom.bind(1.0 / 1.4)))
	bot.add_child(_btn("Testar daqui", _test))
	bot.add_child(_btn("Validar", _validate))
	box.add_child(bot)
	_info()


func _btn(text: String, cb: Callable) -> Button:
	var b := UI.button(text, cb, 52.0)
	b.add_theme_font_size_override("font_size", 20)
	return b


func _info() -> void:
	var m: Dictionary = ctl.map
	info.text = "Ferramenta: %s   |   status: %s   |   objetos %d, notas %d   (toque na regua para mover o cursor; arraste para rolar)" % [tool_name, m.get("status", "UNVERIFIED"),
			(m["objects"] as Array).size(), (m["notes"] as Array).size()]
	info.add_theme_color_override("font_color", UI.status_color(String(m.get("status", "UNVERIFIED"))))


func _snap(t: float) -> float:
	if not snap_on or an.is_empty():
		return t
	var beat: float = 60.0 / float(ctl.map["audio"]["bpm"])
	var off: float = float(an["offset"]) - float(ctl.map["audio"].get("start", 0.0))
	return off + roundf((t - off) / (beat / 4.0)) * (beat / 4.0)


func on_tap(t: float, pos: Vector2, view: Vector2) -> void:
	if pos.y < 30.0:
		playhead = maxf(t, 0.0)
		tv.queue_redraw()
		return
	var m: Dictionary = ctl.map
	var h := view.y
	var geo := String(m.get("mode", "")) != "magic_rhythm"
	var lanes := int(m.get("lanes", 4))
	var row_h := (h - 60.0) / (9.0 if geo else float(maxi(lanes, 1)))
	var row := clampi(int((h - 20.0 - pos.y) / row_h), 0, (8 if geo else lanes - 1))
	var ts := _snap(t)
	if tool_name == "delete":
		ctl.delete_near(t, float(row), 0.25)
	elif geo:
		match tool_name:
			"spike": ctl.add_object("spike", ts, row)
			"spike_flip": ctl.add_object("spike", ts, 8, 1, 1, true)
			"block1": ctl.add_object("block", ts, row, 1, 1)
			"block2": ctl.add_object("block", ts, row, 2, 2)
			"plat": ctl.add_object("block", ts, row, 4, 1)
			"form": ctl.add_form_event(ts, form_sel)
			"speed": ctl.add_speed_event(ts, RD.physics()["speeds"]["fast"])
	else:
		var k := tool_name.replace("n_", "")
		if k == "double":
			ctl.add_note(ts, row, "double")
			ctl.add_note(ts, (row + 2) % lanes, "double")
		else:
			ctl.add_note(ts, row, k, 0.6 if k == "hold" or k == "slide" else 0.0)
	tv.queue_redraw()
	_info()


func _save() -> void:
	ctl.map["name"] = name_edit.text
	SaveManager.save_level(ctl.map)
	GameManager.toast("Fase salva (status %s). Edicoes exigem nova validacao." % ctl.map.get("status", "UNVERIFIED"))


func _duplicate() -> void:
	var c := ctl.duplicate_as_new(name_edit.text + " (copia)")
	SaveManager.save_level(c)
	GameManager.toast("Copia salva na biblioteca.")


func _test() -> void:
	var m: Dictionary = ctl.map.duplicate(true)
	m["is_preview"] = true
	GameManager.start_level(m, {"preview": true, "start_t": maxf(playhead - 2.0, 0.0)})


func _validate() -> void:
	if val_thread != null:
		return
	val_done = false
	val_prog = 0.0
	info.text = "Validando..."
	var snapshot: Dictionary = ctl.map.duplicate(true)
	val_thread = Thread.new()
	val_thread.start(_run_validation.bind(snapshot))
	set_process(true)


func _run_validation(m: Dictionary) -> void:
	val_result = LevelValidator.validate(m, 1200, func(p: float): val_prog = p)
	val_done = true


func _process(_d: float) -> void:
	if val_thread != null:
		if val_done:
			val_thread.wait_to_finish()
			val_thread = null
			var r := val_result
			ctl.map["status"] = r["status"]
			ctl.map["validation"] = {"result": r["result"], "counts": r["counts"], "levels": r["levels"], "difficulty_estimate": r["difficulty_estimate"], "validator": "godot (level_validator.gd)"}
			var txt := "%s (%s)\n" % [r["status"], r["result"]]
			for t in r["tests"]:
				if t["status"] != "pass":
					txt += "- [%s] %s: %s\n" % [str(t["status"]).to_upper(), t["name"], t["detail"]]
			var dlg := AcceptDialog.new()
			dlg.dialog_text = txt
			dlg.title = "Resultado da validacao"
			add_child(dlg)
			dlg.popup_centered(Vector2i(760, 480))
			_info()
		else:
			info.text = "Validando... %d%%" % int(val_prog * 100.0)
