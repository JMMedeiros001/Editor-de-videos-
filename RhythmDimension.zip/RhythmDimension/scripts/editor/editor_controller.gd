class_name EditorController
extends RefCounted
## Operacoes de edicao sobre o mapa (dicionario). Qualquer edicao invalida a validacao (status UNVERIFIED).

var map: Dictionary = {}
var undo_stack: Array = []


func load_map(m: Dictionary) -> void:
	map = m.duplicate(true)
	for k in ["objects", "notes", "form_events", "speed_events", "instances"]:
		if not map.has(k):
			map[k] = []
	if (map["form_events"] as Array).is_empty():
		map["form_events"] = [{"t": 0.0, "form": "cube", "gs": 1, "ceiling": false}]
	undo_stack.clear()


static func blank_from_analysis(an: Dictionary, song: Dictionary, mode: String, diff_name: String) -> Dictionary:
	var m: Dictionary = LevelGenerator.generate(an, mode, diff_name, "balanced", 1, {}, 4, [], String(song.get("name", "Nova fase")), "")
	m["objects"] = []
	m["notes"] = []
	m["instances"] = []
	m["form_events"] = [{"t": 0.0, "form": "cube", "gs": 1, "ceiling": false}]
	m["speed_events"] = [{"t": 0.0, "speed": RD.speed_value(RD.difficulty(diff_name))}]
	m["checkpoints"] = []
	m["id"] = "user_%d" % (Time.get_ticks_usec() % 100000000)
	m["song_id"] = song.get("id", "")
	m["seed"] = 0
	invalidate_static(m)
	return m


static func invalidate_static(m: Dictionary) -> void:
	m["status"] = "UNVERIFIED"
	m.erase("validation")


func _push() -> void:
	undo_stack.append(map.duplicate(true))
	if undo_stack.size() > 40:
		undo_stack.pop_front()
	invalidate_static(map)


func undo() -> bool:
	if undo_stack.is_empty():
		return false
	map = undo_stack.pop_back()
	return true


func tl() -> RhythmMap:
	return RhythmMap.from_dict(map)


func add_object(typ: String, t: float, y: int, w: int = 1, h: int = 1, flip: bool = false) -> void:
	_push()
	var x: float = tl().x_at(t)
	var o := {"type": typ, "x": snappedf(x, 0.001), "y": y}
	if typ == "block":
		o["w"] = w
		o["h"] = h
	if flip:
		o["flip"] = true
	(map["objects"] as Array).append(o)
	(map["objects"] as Array).sort_custom(func(a, b): return float(a["x"]) < float(b["x"]))


func add_note(t: float, lane: int, kind: String, dur: float = 0.0, lane_to: int = -1) -> void:
	_push()
	var n := {"t": snappedf(t, 0.0001), "lane": lane, "kind": kind, "dur": snappedf(dur, 0.0001)}
	if kind == "slide":
		n["lane_to"] = lane_to if lane_to >= 0 else clampi(lane + 1, 0, int(map.get("lanes", 4)) - 1)
		if n["dur"] < 0.25:
			n["dur"] = 0.5
	if kind == "hold" and n["dur"] < 0.2:
		n["dur"] = 0.5
	(map["notes"] as Array).append(n)
	(map["notes"] as Array).sort_custom(func(a, b): return float(a["t"]) < float(b["t"]) or (float(a["t"]) == float(b["t"]) and int(a["lane"]) < int(b["lane"])))


func add_form_event(t: float, form: String, gs: int = 1) -> void:
	_push()
	var ceil_on: bool = form != "cube" and form != "robot" and form != "lanes"
	(map["form_events"] as Array).append({"t": snappedf(t, 0.0001), "form": form, "gs": gs, "ceiling": ceil_on, "portal": true})
	(map["form_events"] as Array).sort_custom(func(a, b): return float(a["t"]) < float(b["t"]))


func add_speed_event(t: float, speed: float) -> void:
	_push()
	(map["speed_events"] as Array).append({"t": snappedf(t, 0.0001), "speed": speed, "portal": true})
	(map["speed_events"] as Array).sort_custom(func(a, b): return float(a["t"]) < float(b["t"]))


## Remove o item mais proximo de (t, y) dentro da tolerancia. Retorna o que removeu ("" se nada).
func delete_near(t: float, y: float, tol_t: float) -> String:
	var m := tl()
	var best := -1
	var best_d := 1e9
	var objs: Array = map["objects"]
	for i in range(objs.size()):
		var ot: float = m.t_at(float(objs[i]["x"]))
		var d := absf(ot - t) + absf(float(objs[i].get("y", 0)) - y) * 0.02
		if d < best_d and absf(ot - t) <= tol_t:
			best_d = d
			best = i
	if best >= 0:
		_push()
		(map["objects"] as Array).remove_at(best)
		return "objeto"
	var notes: Array = map["notes"]
	for i in range(notes.size()):
		var d2 := absf(float(notes[i]["t"]) - t)
		if d2 < best_d and d2 <= tol_t:
			best_d = d2
			best = i
	if best >= 0 and notes.size() > 0:
		_push()
		(map["notes"] as Array).remove_at(best)
		return "nota"
	var fe: Array = map["form_events"]
	for i in range(1, fe.size()):
		if absf(float(fe[i]["t"]) - t) <= tol_t:
			_push()
			(map["form_events"] as Array).remove_at(i)
			return "portal"
	return ""


func shift_all_after(t: float, dt: float) -> void:
	_push()
	for n in map["notes"]:
		if float(n["t"]) >= t:
			n["t"] = snappedf(float(n["t"]) + dt, 0.0001)


func duplicate_as_new(new_name: String) -> Dictionary:
	var c: Dictionary = map.duplicate(true)
	c["id"] = "user_%d" % (Time.get_ticks_usec() % 100000000)
	c["name"] = new_name
	invalidate_static(c)
	return c
