extends Node
## Audio (autoload AudioManager): reproducao, pausa, retomada, reinicio, volume e RELOGIO REAL do audio.
## O jogo sincroniza por get_time() (posicao de reproducao + tempo desde a ultima mixagem - latencia), nunca por FPS.

signal finished
signal interrupted
signal resumed

var player: AudioStreamPlayer
var sfx_player: AudioStreamPlayer
var start_pos := 0.0            # inicio do trecho (trim) em segundos do arquivo
var _last := 0.0
var _playing := false
var _paused := false
var _sfx: Dictionary = {}


func _ready() -> void:
	process_mode = Node.PROCESS_MODE_ALWAYS
	_ensure_bus("Music")
	_ensure_bus("SFX")
	player = AudioStreamPlayer.new()
	player.bus = "Music"
	add_child(player)
	player.finished.connect(_on_player_finished)
	sfx_player = AudioStreamPlayer.new()
	sfx_player.bus = "SFX"
	add_child(sfx_player)
	GameSettings.changed.connect(apply_volumes)
	apply_volumes()


func _on_player_finished() -> void:
	_playing = false
	finished.emit()


func _ensure_bus(bname: String) -> void:
	if AudioServer.get_bus_index(bname) < 0:
		AudioServer.add_bus()
		var idx := AudioServer.get_bus_count() - 1
		AudioServer.set_bus_name(idx, bname)
		AudioServer.set_bus_send(idx, "Master")


func apply_volumes() -> void:
	AudioServer.set_bus_volume_db(AudioServer.get_bus_index("Music"), linear_to_db(maxf(GameSettings.music_volume, 0.0001)))
	AudioServer.set_bus_volume_db(AudioServer.get_bus_index("SFX"), linear_to_db(maxf(GameSettings.sfx_volume, 0.0001)))


func play(stream: AudioStream, from_pos: float = 0.0) -> void:
	player.stream = stream
	start_pos = from_pos
	_last = 0.0
	player.stream_paused = false
	_paused = false
	player.play(from_pos)
	_playing = true


func stop() -> void:
	player.stop()
	_playing = false
	_paused = false


func restart() -> void:
	seek(0.0)


## t = tempo relativo ao inicio do trecho
func seek(t: float) -> void:
	_last = t
	player.stream_paused = false
	_paused = false
	player.play(start_pos + t)
	_playing = true


func pause() -> void:
	if _playing:
		player.stream_paused = true
		_paused = true


func resume() -> void:
	player.stream_paused = false
	_paused = false


func is_playing() -> bool:
	return _playing and not _paused


## Relogio de audio, monotonico, em segundos relativos ao inicio do trecho.
func get_time() -> float:
	if not _playing:
		return _last
	var pos := player.get_playback_position()
	if not _paused:
		pos += AudioServer.get_time_since_last_mix() - AudioServer.get_output_latency()
	var t := pos - start_pos + (GameSettings.audio_offset_ms + GameSettings.latency_ms) / 1000.0
	if t < _last and _last - t < 0.08:
		t = _last        # evita saltos para tras por jitter de mixagem
	_last = t
	return t


func play_sfx(name: String) -> void:
	# SFX sintetizados em tempo real (sem arquivos): tom curto
	var freq := {"perfect": 1320.0, "great": 990.0, "good": 740.0, "miss": 160.0, "death": 110.0, "ui": 660.0, "win": 880.0}.get(name, 660.0)
	var gen := AudioStreamGenerator.new()
	gen.mix_rate = 22050.0
	gen.buffer_length = 0.12
	sfx_player.stream = gen
	sfx_player.play()
	var pb: AudioStreamGeneratorPlayback = sfx_player.get_stream_playback()
	var n := int(gen.mix_rate * 0.09)
	for k in range(n):
		var env := 1.0 - float(k) / float(n)
		var v := sin(TAU * freq * float(k) / gen.mix_rate) * 0.35 * env
		pb.push_frame(Vector2(v, v))


func _notification(what: int) -> void:
	# interrupcoes: ligacao, segundo plano, perda de foco
	if what == NOTIFICATION_APPLICATION_PAUSED or what == NOTIFICATION_APPLICATION_FOCUS_OUT or what == NOTIFICATION_WM_WINDOW_FOCUS_OUT:
		if _playing and not _paused:
			pause()
			interrupted.emit()
	elif what == NOTIFICATION_APPLICATION_RESUMED or what == NOTIFICATION_APPLICATION_FOCUS_IN:
		resumed.emit()    # o modo de jogo decide: mostra tela de pausa e deixa o jogador retomar


## Fallback de analise: toca o audio mudo e captura o PCM em tempo real (demora a duracao da musica).
func capture_pcm(stream: AudioStream, progress: Callable) -> Dictionary:
	_ensure_bus("Analysis")
	var bi := AudioServer.get_bus_index("Analysis")
	AudioServer.set_bus_volume_db(bi, -80.0)
	var cap := AudioEffectCapture.new()
	AudioServer.add_bus_effect(bi, cap)
	var p := AudioStreamPlayer.new()
	p.bus = "Analysis"
	p.stream = stream
	add_child(p)
	p.play()
	var rate := AudioServer.get_mix_rate()
	var factor := maxi(1, int(round(rate / 11025.0)))
	var out := PackedFloat32Array()
	var carry := 0.0
	var cc := 0
	var dur := stream.get_length()
	while p.playing:
		var n := cap.get_frames_available()
		if n > 0:
			for fr in cap.get_buffer(n):
				carry += (fr.x + fr.y) * 0.5
				cc += 1
				if cc == factor:
					out.append(carry / float(factor))
					carry = 0.0
					cc = 0
		if progress.is_valid():
			progress.call(minf(p.get_playback_position() / maxf(dur, 0.1), 1.0))
		await get_tree().process_frame
	p.queue_free()
	AudioServer.remove_bus_effect(bi, AudioServer.get_bus_effect_count(bi) - 1)
	return {"ok": out.size() > 0, "samples": out, "sr": rate / float(factor)}
