class_name MusicImporter
extends RefCounted
## Importacao e decodificacao de musicas do usuario. Nada e enviado para servidores.
## Formatos: WAV (leitor proprio), OGG e MP3 (decodificadores do Godot). FLAC NAO e suportado nativamente pelo Godot 4.
## ATENCAO: nao testado no Godot/Android. Riscos conhecidos documentados em documentation/LIMITATIONS.md.

const SUPPORTED := ["wav", "ogg", "mp3"]
const TARGET_SR := 11025.0


static func ext_of(path: String) -> String:
	return path.get_extension().to_lower()


static func validate_file(path: String) -> Dictionary:
	var ext := ext_of(path)
	if ext == "flac":
		return {"ok": false, "error": "FLAC nao e suportado nativamente pelo Godot 4. Converta para OGG, MP3 ou WAV."}
	if not SUPPORTED.has(ext):
		return {"ok": false, "error": "Formato nao suportado: ." + ext + " (use MP3, WAV ou OGG)."}
	if not FileAccess.file_exists(path):
		return {"ok": false, "error": "Arquivo nao encontrado ou sem acesso. Selecione-o novamente."}
	var f := FileAccess.open(path, FileAccess.READ)
	if f == null:
		return {"ok": false, "error": "Nao foi possivel abrir o arquivo (permissao)."}
	var size := f.get_length()
	if size < 2048:
		return {"ok": false, "error": "Arquivo vazio ou pequeno demais."}
	if size > 120 * 1024 * 1024:
		return {"ok": false, "error": "Arquivo grande demais (limite 120 MB)."}
	return {"ok": true, "ext": ext, "size": size}


## Copia opcional para o armazenamento privado do app (somente local; nunca enviado a servidor).
static func cache_copy(path: String, song_id: String) -> String:
	DirAccess.make_dir_recursive_absolute("user://music")
	var dst := "user://music/%s.%s" % [song_id, ext_of(path)]
	if FileAccess.file_exists(dst):
		return dst
	var src := FileAccess.open(path, FileAccess.READ)
	if src == null:
		return ""
	var out := FileAccess.open(dst, FileAccess.WRITE)
	if out == null:
		return ""
	out.store_buffer(src.get_buffer(src.get_length()))
	return dst


static func _parse_wav(bytes: PackedByteArray) -> Dictionary:
	if bytes.size() < 44 or bytes.slice(0, 4).get_string_from_ascii() != "RIFF" or bytes.slice(8, 12).get_string_from_ascii() != "WAVE":
		return {"ok": false, "error": "WAV invalido (cabecalho RIFF/WAVE)"}
	var pos := 12
	var fmt_ok := false
	var channels := 2
	var rate := 44100
	var bits := 16
	var data_off := -1
	var data_len := 0
	while pos + 8 <= bytes.size():
		var cid := bytes.slice(pos, pos + 4).get_string_from_ascii()
		var clen := bytes.decode_u32(pos + 4)
		if cid == "fmt ":
			var fmt_tag := bytes.decode_u16(pos + 8)
			channels = bytes.decode_u16(pos + 10)
			rate = bytes.decode_u32(pos + 12)
			bits = bytes.decode_u16(pos + 22)
			fmt_ok = (fmt_tag == 1 or fmt_tag == 0xFFFE) and (bits == 16 or bits == 8)
		elif cid == "data":
			data_off = pos + 8
			data_len = mini(clen, bytes.size() - data_off)
			break
		pos += 8 + clen + (clen & 1)
	if not fmt_ok or data_off < 0:
		return {"ok": false, "error": "WAV nao suportado (use PCM 8/16 bits)"}
	return {"ok": true, "channels": channels, "rate": rate, "bits": bits, "off": data_off, "len": data_len}


static func load_stream(path: String) -> Dictionary:
	var ext := ext_of(path)
	if path.begins_with("res://"):
		var st: Variant = load(path)
		if st == null:
			return {"ok": false, "error": "recurso nao encontrado: " + path}
		return {"ok": true, "stream": st, "duration": (st as AudioStream).get_length(), "ext": ext}
	var chk := validate_file(path)
	if not chk["ok"]:
		return chk
	var f := FileAccess.open(path, FileAccess.READ)
	var bytes := f.get_buffer(f.get_length())
	if ext == "mp3":
		var s := AudioStreamMP3.new()
		s.data = bytes
		if s.get_length() <= 0.0:
			return {"ok": false, "error": "MP3 invalido ou corrompido"}
		return {"ok": true, "stream": s, "duration": s.get_length(), "ext": ext}
	if ext == "ogg":
		var s2 := AudioStreamOggVorbis.load_from_buffer(bytes)
		if s2 == null or s2.get_length() <= 0.0:
			return {"ok": false, "error": "OGG invalido ou corrompido"}
		return {"ok": true, "stream": s2, "duration": s2.get_length(), "ext": ext}
	var w := _parse_wav(bytes)
	if not w["ok"]:
		return w
	var s3 := AudioStreamWAV.new()
	s3.format = AudioStreamWAV.FORMAT_16_BITS if int(w["bits"]) == 16 else AudioStreamWAV.FORMAT_8_BITS
	s3.mix_rate = int(w["rate"])
	s3.stereo = int(w["channels"]) == 2
	s3.data = bytes.slice(int(w["off"]), int(w["off"]) + int(w["len"]))
	return {"ok": true, "stream": s3, "duration": s3.get_length(), "ext": ext}


## Decodifica para PCM mono decimado (~11025 Hz). WAV: direto. MP3/OGG: via AudioStreamPlayback.mix_audio quando
## existir nesta versao do Godot; senao retorna needs_capture=true (use AudioManager.capture_pcm, em tempo real).
static func decode_pcm(stream: AudioStream, path: String, progress: Callable = Callable()) -> Dictionary:
	if stream is AudioStreamWAV:
		var w: AudioStreamWAV = stream
		var data: PackedByteArray = w.data
		var ch := 2 if w.stereo else 1
		var bps := 2 if w.format == AudioStreamWAV.FORMAT_16_BITS else 1
		var frames := data.size() / (ch * bps)
		var factor := maxi(1, int(round(float(w.mix_rate) / TARGET_SR)))
		var out := PackedFloat32Array()
		out.resize(frames / factor)
		var idx := 0
		for oi in range(out.size()):
			var acc := 0.0
			for k in range(factor):
				var fr := idx + k
				var v := 0.0
				for c in range(ch):
					var off := (fr * ch + c) * bps
					v += (float(data.decode_s16(off)) / 32768.0) if bps == 2 else ((float(data[off]) - 128.0) / 128.0)
				acc += v / float(ch)
			out[oi] = acc / float(factor)
			idx += factor
			if progress.is_valid() and oi % 20000 == 0:
				progress.call(float(oi) / float(out.size()))
		return {"ok": true, "samples": out, "sr": float(w.mix_rate) / float(factor)}
	var pb: AudioStreamPlayback = stream.instantiate_playback()
	if pb == null or not pb.has_method("mix_audio"):
		return {"ok": false, "needs_capture": true, "error": "decodificacao direta indisponivel nesta versao do Godot"}
	pb.start(0.0)
	var rate := 44100.0
	var factor2 := maxi(1, int(round(rate / TARGET_SR)))
	var out2 := PackedFloat32Array()
	var carry := 0.0
	var cc := 0
	var total_est := stream.get_length() * rate
	var done := 0.0
	while true:
		var buf: PackedVector2Array = pb.mix_audio(1.0, 4096)
		if buf.is_empty():
			break
		for fr2 in buf:
			carry += (fr2.x + fr2.y) * 0.5
			cc += 1
			if cc == factor2:
				out2.append(carry / float(factor2))
				carry = 0.0
				cc = 0
		done += buf.size()
		if progress.is_valid():
			progress.call(minf(done / maxf(total_est, 1.0), 1.0))
	return {"ok": true, "samples": out2, "sr": rate / float(factor2)}
