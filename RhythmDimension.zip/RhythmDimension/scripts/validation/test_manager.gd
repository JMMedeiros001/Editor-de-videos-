class_name TestManager
extends RefCounted
## Ciclo: GERAR -> VALIDAR -> ENCONTRAR ERROS -> CORRIGIR (so o trecho responsavel) -> VALIDAR DE NOVO -> COMPARAR -> APROVAR/REJEITAR.
## PORTA de tools/rdtools/fixer.py. Limite de tentativas; correcoes que nao melhoram sao descartadas; nada e escondido.


static func _score(rep: Dictionary) -> Array:
	var fails := 0
	var unv := 0
	var sev := 0.0
	var tf := 1e9
	for t in rep["tests"]:
		if t["status"] == "fail":
			fails += 1
			sev += float(t["severity"]) if t.has("severity") else float(maxi((t["refs"] as Array).size(), 1))
		elif t["status"] == "unverified":
			unv += 1
		if t.has("t_fail"):
			tf = minf(tf, float(t["t_fail"]))
	return [fails + unv, unv, snappedf(sev, 0.001), -tf]


static func _less(a: Array, b: Array) -> bool:
	for i in range(a.size()):
		if float(a[i]) < float(b[i]):
			return true
		if float(a[i]) > float(b[i]):
			return false
	return false


static func _drop_instance(m: Dictionary, k: int) -> void:
	m["objects"] = (m["objects"] as Array).filter(func(o): return not (o.has("inst") and int(o["inst"]) == k))
	m["form_events"] = (m["form_events"] as Array).filter(func(e): return not (e.has("inst") and int(e["inst"]) == k))
	m["instances"] = (m["instances"] as Array).filter(func(i): return int(i["k"]) != k)


static func _drop_last_hazard(m: Dictionary, k: int) -> bool:
	var objs: Array = (m["objects"] as Array).filter(func(o): return o.has("inst") and int(o["inst"]) == k)
	if objs.size() <= 1:
		return false
	var last: Dictionary = objs[0]
	for o in objs:
		if float(o["x"]) > float(last["x"]):
			last = o
	(m["objects"] as Array).erase(last)
	return true


static func _swap_simple(m: Dictionary, k: int) -> bool:
	var inst: Dictionary = {}
	for i in m["instances"]:
		if int(i["k"]) == k:
			inst = i
	if inst.is_empty() or inst["pattern"] == "Pattern_Jump_01":
		return false
	var objs: Array = (m["objects"] as Array).filter(func(o): return o.has("inst") and int(o["inst"]) == k)
	if objs.is_empty():
		return false
	var x0 := 1e18
	for o in objs:
		x0 = minf(x0, float(o["x"]))
	var t0: float = float(inst["t0"])
	var bar: int = int(inst.get("bar", 0))
	var anchor: float = float(inst.get("anchor", 0))
	_drop_instance(m, k)
	m["objects"].append({"type": "spike", "x": snappedf(x0, 0.001), "y": 0, "inst": k})
	m["instances"].append({"k": k, "pattern": "Pattern_Jump_01", "kind": "static", "form": "cube", "t0": t0, "t1": t0 + 0.6, "bar": bar, "tier": 1, "anchor": anchor, "fixed": true})
	(m["instances"] as Array).sort_custom(func(a, b): return float(a["t0"]) < float(b["t0"]))
	return true


static func _remove_notes(m: Dictionary, idxs: Array) -> void:
	var keep: Array = []
	var notes: Array = m["notes"]
	for i in range(notes.size()):
		if not idxs.has(i):
			keep.append(notes[i])
	m["notes"] = keep


static func _fix_density(m: Dictionary, win_idx: int) -> bool:
	var notes: Array = m["notes"]
	if win_idx >= notes.size():
		return false
	var t0: float = float(notes[win_idx]["t"])
	var cand: Array = []
	for i in range(notes.size()):
		if float(notes[i]["t"]) >= t0 - 1.0 and float(notes[i]["t"]) <= t0 and (notes[i]["kind"] == "tap" or notes[i]["kind"] == "fast"):
			cand.append(i)
	if cand.is_empty():
		for i in range(notes.size()):
			if float(notes[i]["t"]) >= t0 - 1.0 and float(notes[i]["t"]) <= t0:
				cand.append(i)
	if cand.is_empty():
		return false
	var best := int(cand[0])
	var best_d := 1e9
	for i in cand:
		var dmin := 1e9
		for j in range(notes.size()):
			if j != i:
				dmin = minf(dmin, absf(float(notes[i]["t"]) - float(notes[j]["t"])))
		if dmin < best_d:
			best_d = dmin
			best = int(i)
	_remove_notes(m, [best])
	return true


## Retorna {map, report, history}. O mapa original NAO e alterado.
static func fix_and_validate(m_in: Dictionary, max_iter: int = 14, beam: int = 1200, progress: Callable = Callable()) -> Dictionary:
	var m: Dictionary = m_in.duplicate(true)
	var d: Dictionary = LevelValidator.diff_of(m)
	var hist: Array = []
	var rep: Dictionary = LevelValidator.validate(m, beam)
	var attempts: Dictionary = {}
	var rej_row := 0
	var it := 0
	var order := {"estrutura": 0, "colisao": 1, "notas": 2, "tempo": 3, "progressao": 4, "dificuldade": 5, "gameplay": 6}
	while rep["status"] != "READY" and it < max_iter:
		it += 1
		var bad: Array = (rep["tests"] as Array).filter(func(t): return t["status"] == "fail" or t["status"] == "unverified")
		if bad.is_empty():
			break
		var base_score: Array = _score(rep)
		var cand: Dictionary = m.duplicate(true)
		var action := ""
		bad.sort_custom(func(a, b): return int(order.get(a["category"], 9)) < int(order.get(b["category"], 9)))
		var tgt: Dictionary = bad[0]
		var tid: String = tgt["id"]
		var refs: Array = tgt["refs"]
		if ["S3", "S6", "C1", "C3", "C4"].has(tid) and not refs.is_empty():
			var keep: Array = []
			for i in range((cand["objects"] as Array).size()):
				if not refs.has(i):
					keep.append(cand["objects"][i])
			cand["objects"] = keep
			action = "remover objetos invalidos %s" % str(refs.slice(0, 6))
		elif ["S7", "N3", "N5", "N7"].has(tid) and not refs.is_empty():
			_remove_notes(cand, refs)
			action = "remover notas invalidas %s" % str(refs.slice(0, 6))
		elif tid == "N4":
			if _fix_density(cand, int(refs[0])):
				action = "remover nota mais fraca da janela de alta densidade"
		elif tid == "N6":
			_remove_notes(cand, refs)
			action = "remover nota inalcancavel com 2 dedos (indice %s)" % str(refs)
		elif ["T3", "T5", "G1", "T1", "T2", "T4"].has(tid):
			var tl: RhythmMap = RhythmMap.from_dict(cand)
			var tf: float = float(tgt["t_fail"]) if tgt.has("t_fail") else -1.0
			var ik := -1
			if tid == "T4" and not (cand["instances"] as Array).is_empty():
				var li: Dictionary = cand["instances"][0]
				for i in cand["instances"]:
					if float(i["t1"]) > float(li["t1"]):
						li = i
				ik = int(li["k"])
			elif tid == "T3" and not refs.is_empty():
				var o: Dictionary = cand["objects"][int(refs[0])]
				tf = tl.t_at(float(o["x"]))
			if ik < 0 and tf >= 0.0:
				var bestd := 1e9
				for i in cand["instances"]:
					if float(i["t0"]) - 1.3 <= tf and tf <= float(i["t1"]) + 0.9:
						var dd := absf((float(i["t0"]) + float(i["t1"])) / 2.0 - tf)
						if dd < bestd:
							bestd = dd
							ik = int(i["k"])
			if ik < 0 and not refs.is_empty() and cand["objects"].size() > int(refs[0]) and cand["objects"][int(refs[0])].has("inst"):
				ik = int(cand["objects"][int(refs[0])]["inst"])
			if ik >= 0:
				var key := "inst_%d" % ik
				var n_try: int = int(attempts.get(key, 0))
				attempts[key] = n_try + 1
				var inst: Dictionary = {}
				for i in cand["instances"]:
					if int(i["k"]) == ik:
						inst = i
				if not inst.is_empty():
					var pat := String(inst["pattern"])
					var t0i := float(inst["t0"])
					if n_try == 0 and inst["kind"] == "static" and _swap_simple(cand, ik):
						action = "substituir %s por Pattern_Jump_01 (t=%.2fs)" % [pat, t0i]
					elif n_try <= 1 and inst["kind"] == "static" and _drop_last_hazard(cand, ik):
						action = "remover ultimo perigo de %s" % pat
					else:
						_drop_instance(cand, ik)
						action = "remover instancia %s (t=%.2fs) preservando o restante" % [pat, t0i]
		elif tid == "P1" or tid == "P2":
			cand["form_events"].append({"t": snappedf(float(cand["end_t"]) - 0.5, 0.001), "form": "cube", "gs": 1, "ceiling": false})
			action = "inserir portal final para forma normal"
		if action == "":
			hist.append({"iter": it, "test": tid, "action": "", "accepted": false, "note": "sem estrategia de correcao automatica; oferecer edicao manual"})
			break
		var rep2: Dictionary = LevelValidator.validate(cand, beam)
		var s2: Array = _score(rep2)
		var accepted: bool = _less(s2, base_score) or (float(s2[0]) <= float(base_score[0]) and rep2["status"] == "READY")
		rej_row = 0 if accepted else rej_row + 1
		hist.append({"iter": it, "test": tid, "refs": refs.slice(0, 6), "action": action, "before": {"fails": base_score[0], "unverified": base_score[1]},
				"after": {"fails": s2[0], "unverified": s2[1]}, "accepted": accepted})
		if accepted:
			m = cand
			rep = rep2
		elif rej_row >= 3:
			hist.append({"iter": it, "test": tid, "action": "", "accepted": false,
					"note": "3 correcoes seguidas rejeitadas (nao melhoram os testes); oferecer edicao manual ou gerar alternativa"})
			break
		if progress.is_valid():
			progress.call(float(it) / float(max_iter))
	m["validation_history"] = hist
	m["status"] = rep["status"]
	m["validation"] = {"result": rep["result"], "counts": rep["counts"], "levels": rep["levels"], "difficulty_estimate": rep["difficulty_estimate"],
			"iterations": it, "limit": max_iter, "validator": "godot (level_validator.gd)"}
	return {"map": m, "report": rep, "history": hist}
