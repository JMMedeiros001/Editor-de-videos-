class_name LevelValidator
extends RefCounted
## Validador de fases. PORTA de tools/rdtools/validator.py (testado la, inclusive com injecao de falhas).
## status por teste: pass | warn | fail | unverified. Resultado: Aprovada | Aprovada com avisos | Reprovada | Nao verificada.
## A simulacao (G1) so e executada de verdade no Godot; no Python foi validada por 73 testes.

const FORMS := ["cube", "ship", "ball", "robot", "spider", "wave", "lanes"]
const NOTE_KINDS := ["tap", "hold", "double", "slide", "fast", "special"]
const OBJ_TYPES := ["spike", "block"]


static func _t(id: String, cat: String, tname: String, status: String, detail: String = "", refs: Array = [], executed: String = "real") -> Dictionary:
	return {"id": id, "category": cat, "name": tname, "status": status, "detail": detail, "refs": refs, "executed": executed}


static func diff_of(m: Dictionary) -> Dictionary:
	var name: String = String(m.get("difficulty", "normal"))
	if name == "custom":
		return RD.difficulty("custom", m.get("custom", {}))
	return RD.difficulty(name)


static func diff_at(m: Dictionary, d: Dictionary, t: float) -> Dictionary:
	if not m.has("tier_by_bar"):
		return d
	var tb: Array = m["tier_by_bar"]
	var bar_len: float = 240.0 / float(m["audio"]["bpm"])
	var k: int = clampi(int(floor((t - float(m["audio"]["offset"])) / bar_len)), 0, tb.size() - 1)
	return RD.difficulty(String(tb[k]))


# ------------------------------------------------------------------ estrutura
static func _structure(m: Dictionary, out: Array) -> void:
	var miss: Array = []
	for k in ["format", "id", "mode", "difficulty", "audio", "end_t", "speed_events"]:
		if not m.has(k):
			miss.append(k)
	out.append(_t("S1", "estrutura", "campos obrigatorios", "fail" if not miss.is_empty() else "pass", "faltando: %s" % str(miss) if not miss.is_empty() else ""))
	if not miss.is_empty():
		return
	var a: Dictionary = m["audio"]
	var ok: bool = float(a.get("duration", 0)) > 5.0 and float(a.get("bpm", 0)) > 30.0 and float(m["end_t"]) >= 8.0 and float(m["end_t"]) <= float(a.get("duration", 0)) + 0.01
	out.append(_t("S2", "estrutura", "duracao/BPM/fim dentro da musica", "pass" if ok else "fail", "end_t=%s dur=%s bpm=%s" % [str(m["end_t"]), str(a.get("duration")), str(a.get("bpm"))]))
	var bad: Array = []
	var objs: Array = m.get("objects", [])
	for i in range(objs.size()):
		var o: Dictionary = objs[i]
		var x := float(o.get("x", -1)); var y := float(o.get("y", 0)); var w := float(o.get("w", 1)); var h := float(o.get("h", 1))
		if not OBJ_TYPES.has(o.get("type", "")) or x < 0.0 or w <= 0.0 or h <= 0.0 or y < 0.0 or is_nan(x) or is_inf(x):
			bad.append(i)
	out.append(_t("S3", "estrutura", "objetos validos (tipo, numeros, x>=0, tamanhos)", "fail" if not bad.is_empty() else "pass", "indices: %s" % str(bad.slice(0, 10)), bad))
	var ev_bad: Array = []
	var last := -1.0
	var fe: Array = m.get("form_events", [])
	for i in range(fe.size()):
		var e: Dictionary = fe[i]
		if not FORMS.has(e.get("form", "")) or not [1, -1].has(int(e.get("gs", 1))) or float(e["t"]) < 0.0 or float(e["t"]) > float(m["end_t"]) or float(e["t"]) < last - 1e-9:
			ev_bad.append(i)
		last = float(e["t"])
	out.append(_t("S4", "estrutura", "eventos de forma/portal (tempo, forma, gravidade)", "fail" if not ev_bad.is_empty() else "pass", "indices: %s" % str(ev_bad), ev_bad))
	var sp_bad: Array = []
	var sev: Array = m["speed_events"]
	for i in range(sev.size()):
		var e2: Dictionary = sev[i]
		if float(e2["speed"]) < 4.0 or float(e2["speed"]) > 25.0 or float(e2["t"]) < 0.0 or float(e2["t"]) > float(m["end_t"]):
			sp_bad.append(i)
	out.append(_t("S5", "estrutura", "eventos de velocidade", "fail" if not sp_bad.is_empty() else "pass", "", sp_bad))
	var seen: Dictionary = {}
	var dup: Array = []
	for i in range(objs.size()):
		var o2: Dictionary = objs[i]
		var key := "%s|%.2f|%s|%s" % [o2["type"], float(o2["x"]), str(o2.get("y", 0)), str(o2.get("flip", false))]
		if seen.has(key):
			dup.append(i)
		seen[key] = true
	out.append(_t("S6", "estrutura", "objetos duplicados", "fail" if not dup.is_empty() else "pass", "", dup))
	var lanes: int = int(m.get("lanes", 0))
	var nb: Array = []
	var notes: Array = m.get("notes", [])
	for i in range(notes.size()):
		var n: Dictionary = notes[i]
		var okn: bool = NOTE_KINDS.has(n.get("kind", "")) and int(n.get("lane", -1)) >= 0 and int(n.get("lane", -1)) < maxi(lanes, 1) and float(n.get("dur", 0)) >= 0.0 and float(n["t"]) >= 0.0 and float(n["t"]) <= float(m["end_t"])
		if n.get("kind", "") == "slide":
			var lt: int = int(n.get("lane_to", -99))
			okn = okn and n.has("lane_to") and absi(lt - int(n["lane"])) == 1 and lt >= 0 and lt < lanes and float(n["dur"]) >= 0.2
		if n.get("kind", "") == "hold":
			okn = okn and float(n["dur"]) >= 0.15
		if not okn:
			nb.append(i)
	out.append(_t("S7", "estrutura", "notas validas (tipo, pista, duracao, adjacencia do slide)", "fail" if not nb.is_empty() else "pass", "indices: %s" % str(nb.slice(0, 10)), nb))
	if ["magic_rhythm", "music_dash"].has(m.get("mode", "")) and notes.is_empty():
		out.append(_t("S8", "estrutura", "fase de notas tem notas", "fail", "nenhuma nota"))


# ------------------------------------------------------------------ colisao
static func _collision(m: Dictionary, out: Array, tl: RhythmMap) -> void:
	var objs: Array = m.get("objects", [])
	var ceil_y: float = float(RD.physics()["ceiling_y"])
	var solids: Array = []
	var spikes: Array = []
	for i in range(objs.size()):
		var o: Dictionary = objs[i]
		if o["type"] == "block":
			solids.append([i, float(o["x"]), float(o.get("y", 0)), float(o["x"]) + float(o.get("w", 1)), float(o.get("y", 0)) + float(o.get("h", 1))])
		else:
			spikes.append([i, float(o["x"]), float(o.get("y", 0))])
	solids.sort_custom(func(a, b): return a[1] < b[1])
	var inside: Array = []
	for sp in spikes:
		for sd in solids:
			if sd[1] > sp[1] + 1.0:
				break
			if sp[1] + 1.0 > sd[1] + 1e-6 and sp[1] < sd[3] - 1e-6 and sp[2] + 1.0 > sd[2] + 1e-6 and sp[2] < sd[4] - 1e-6:
				inside.append(sp[0])
				break
	out.append(_t("C1", "colisao", "espinho dentro de bloco (hitbox impossivel)", "fail" if not inside.is_empty() else "pass", "", inside))
	var ov: Array = []
	for a in range(solids.size()):
		for b in range(a + 1, solids.size()):
			if solids[b][1] >= solids[a][3]:
				break
			if minf(solids[a][3], solids[b][3]) - maxf(solids[a][1], solids[b][1]) > 0.01 and minf(solids[a][4], solids[b][4]) - maxf(solids[a][2], solids[b][2]) > 0.01:
				ov.append(solids[b][0])
	out.append(_t("C2", "colisao", "blocos sobrepostos", "warn" if not ov.is_empty() else "pass", "indices: %s" % str(ov.slice(0, 10)), ov))
	var oob: Array = []
	for i in range(objs.size()):
		var o2: Dictionary = objs[i]
		var top: float = float(o2.get("y", 0)) + (float(o2.get("h", 1)) if o2["type"] == "block" else 1.0)
		if top > ceil_y + 1e-6 or float(o2.get("y", 0)) < 0.0:
			oob.append(i)
	out.append(_t("C3", "colisao", "objetos dentro da area jogavel", "fail" if not oob.is_empty() else "pass", "", oob))
	var fe: Array = tl.fe
	var lane_iv: Array = []
	for k in range(fe.size()):
		if fe[k]["form"] == "lanes":
			var t_end: float = float(fe[k + 1]["t"]) if k + 1 < fe.size() else float(m["end_t"])
			lane_iv.append([float(fe[k]["t"]), t_end])
	var bad: Array = []
	for i in range(objs.size()):
		var tt: float = tl.t_at(float(objs[i]["x"]))
		for iv in lane_iv:
			if iv[0] - 0.05 <= tt and tt <= iv[1] + 0.05:
				bad.append(i)
				break
	out.append(_t("C4", "colisao", "perigos dentro de trecho de notas (Music Dash)", "fail" if not bad.is_empty() else "pass", "", bad))


# ------------------------------------------------------------------ tempo
static func _hazard_groups(m: Dictionary, tl: RhythmMap) -> Array:
	var fe: Array = tl.fe
	var items: Array = []
	var objs: Array = m.get("objects", [])
	for i in range(objs.size()):
		var o: Dictionary = objs[i]
		var t0: float = tl.t_at(float(o["x"]))
		var t1: float = tl.t_at(float(o["x"]) + float(o.get("w", 1)))
		var f := "cube"
		for e in fe:
			if float(e["t"]) <= t0:
				f = String(e["form"])
			else:
				break
		items.append([t0, t1, i, f])
	items.sort_custom(func(a, b): return a[0] < b[0])
	var groups: Array = []
	for it in items:
		if not groups.is_empty() and it[0] - groups[groups.size() - 1]["t1"] < 0.25 and it[3] == groups[groups.size() - 1]["form"]:
			groups[groups.size() - 1]["t1"] = maxf(groups[groups.size() - 1]["t1"], it[1])
			groups[groups.size() - 1]["refs"].append(it[2])
		else:
			groups.append({"t0": it[0], "t1": it[1], "form": it[3], "refs": [it[2]]})
	return groups


static func _timing(m: Dictionary, out: Array, d: Dictionary, tl: RhythmMap) -> void:
	var objs: Array = m.get("objects", [])
	if objs.is_empty():
		return
	var first := 1e9
	var last_end := 0.0
	var late: Array = []
	for i in range(objs.size()):
		var t0: float = tl.t_at(float(objs[i]["x"]))
		first = minf(first, t0)
		last_end = maxf(last_end, tl.t_at(float(objs[i]["x"]) + float(objs[i].get("w", 1))))
		if t0 > float(m["end_t"]) + 0.01:
			late.append(i)
	out.append(_t("T1", "tempo", "primeiro perigo respeita a entrada (lead-in)", "pass" if first >= float(d["lead_in_s"]) - 0.3 else "fail", "primeiro em %.2fs (min %.2fs)" % [first, float(d["lead_in_s"]) - 0.3]))
	out.append(_t("T2", "tempo", "objetos fora da musica (apos o fim)", "fail" if not late.is_empty() else "pass", "", late))
	var groups: Array = _hazard_groups(m, tl).filter(func(g): return g["form"] == "cube" or g["form"] == "robot")
	var bad: Array = []
	var warn: Array = []
	for j in range(groups.size() - 1):
		var gap: float = groups[j + 1]["t0"] - groups[j]["t0"]
		var mg: float = float(diff_at(m, d, groups[j + 1]["t0"])["min_gap_s"])
		if gap < mg * 0.7:
			bad.append(groups[j + 1]["refs"][0])
		elif gap < mg * 0.9:
			warn.append(groups[j + 1]["refs"][0])
	out.append(_t("T3", "tempo", "espacamento minimo entre perigos (reacao, por dificuldade)", "fail" if not bad.is_empty() else ("warn" if not warn.is_empty() else "pass"), "min_gap=%.2fs" % float(d["min_gap_s"]), bad if not bad.is_empty() else warn))
	out.append(_t("T4", "tempo", "pista livre ate o fim (finalizacao)", "pass" if float(m["end_t"]) - last_end >= 1.0 else "fail", "folga %.2fs" % (float(m["end_t"]) - last_end)))
	var qb: Array = []
	for e in tl.fe:
		if ["ball", "spider", "robot", "ship", "wave"].has(e["form"]) and float(e["t"]) > 0.0:
			var nxt := 1e9
			for o in objs:
				var tt: float = tl.t_at(float(o["x"]))
				if tt >= float(e["t"]) - 0.01:
					nxt = minf(nxt, tt)
			if nxt < 1e8 and nxt - float(e["t"]) < float(d["reaction_s"]):
				qb.append(snappedf(float(e["t"]), 0.01))
	out.append(_t("T5", "tempo", "tempo de reacao apos portal de forma", "fail" if not qb.is_empty() else "pass", "portais em %s" % str(qb), []))


# ------------------------------------------------------------------ notas
static func finger_check(notes: Array, lanes: int) -> int:
	const TRAVEL := 0.045
	const PRESS := 0.05
	var fingers: Array = [{"pos": lanes / 2, "free": -9.0}, {"pos": lanes / 2, "free": -9.0}]
	var i := 0
	var n := notes.size()
	while i < n:
		var j := i
		while j + 1 < n and absf(float(notes[j + 1]["t"]) - float(notes[i]["t"])) < 0.005:
			j += 1
		var grp: Array = notes.slice(i, j + 1)
		if grp.size() > 2:
			return i
		grp.sort_custom(func(a, b): return int(a["lane"]) < int(b["lane"]))
		var used: Dictionary = {}
		for nt in grp:
			var best := -1
			var bs := 1e9
			for fi in range(2):
				if used.has(fi):
					continue
				var f: Dictionary = fingers[fi]
				var ready: float = float(f["free"]) + minf(TRAVEL * absf(float(f["pos"]) - float(nt["lane"])), 0.14)
				if ready <= float(nt["t"]) + 1e-6:
					var sc: float = absf(float(f["pos"]) - float(nt["lane"]))
					if sc < bs:
						best = fi
						bs = sc
			if best < 0:
				return i
			used[best] = true
			var ff: Dictionary = fingers[best]
			ff["free"] = float(nt["t"]) + maxf(float(nt.get("dur", 0.0)), PRESS)
			ff["pos"] = int(nt["lane_to"]) if nt["kind"] == "slide" else int(nt["lane"])
		i = j + 1
	return -1


static func _notes_tests(m: Dictionary, out: Array, d: Dictionary) -> void:
	var notes: Array = m.get("notes", [])
	if notes.is_empty():
		return
	var nd: Dictionary = d["notes"]
	var lanes: int = int(m["lanes"])
	var ts: Array = []
	for n in notes:
		ts.append(float(n["t"]))
	var sorted_ok := true
	for i in range(1, ts.size()):
		if ts[i] < ts[i - 1]:
			sorted_ok = false
	out.append(_t("N1", "notas", "notas ordenadas e dentro da musica", "pass" if sorted_ok and ts[ts.size() - 1] <= float(m["end_t"]) else "fail"))
	out.append(_t("N2", "notas", "primeira nota respeita a entrada", "pass" if ts[0] >= float(d["lead_in_s"]) - 0.3 else "fail", "primeira em %.2fs" % ts[0]))
	var last: Dictionary = {}
	var badg: Array = []
	for i in range(notes.size()):
		var n2: Dictionary = notes[i]
		var targets: Array = [[int(n2["lane"]), float(n2["t"]) + float(n2.get("dur", 0.0))]]
		if n2["kind"] == "slide":
			targets.append([int(n2["lane_to"]), float(n2["t"]) + float(n2.get("dur", 0.0))])
		for tg in targets:
			if last.has(tg[0]) and float(n2["t"]) - float(last[tg[0]]) < float(nd["lane_gap_s"]) * 0.98:
				badg.append(i)
			last[tg[0]] = tg[1]
	out.append(_t("N3", "notas", "intervalo minimo por pista (tempo de reacao)", "fail" if not badg.is_empty() else "pass", "min %.2fs" % float(nd["lane_gap_s"]), badg))
	var mx := 0
	var wi := 0
	var j2 := 0
	for i in range(ts.size()):
		while ts[i] - ts[j2] > 1.0:
			j2 += 1
		if i - j2 + 1 > mx:
			mx = i - j2 + 1
			wi = i
	var lim: float = float(nd["max_nps"])
	var st := "fail" if float(mx) > lim * 1.15 else ("warn" if float(mx) > lim + 1e-9 else "pass")
	var n4 := _t("N4", "notas", "densidade maxima (notas/s em janela de 1s)", st, "pico=%d limite=%.1f" % [mx, lim], [wi])
	n4["severity"] = maxf(0.0, float(mx) - lim)
	out.append(n4)
	var big: Array = []
	var i3 := 0
	while i3 < notes.size():
		var j3 := i3
		while j3 + 1 < notes.size() and absf(float(notes[j3 + 1]["t"]) - float(notes[i3]["t"])) < 0.005:
			j3 += 1
		if j3 - i3 + 1 > int(nd["max_chord"]):
			for q in range(i3 + int(nd["max_chord"]), j3 + 1):
				big.append(q)
		i3 = j3 + 1
	out.append(_t("N5", "notas", "tamanho maximo de acorde/notas simultaneas", "fail" if not big.is_empty() else "pass", "max %d" % int(nd["max_chord"]), big))
	var fi: int = finger_check(notes, lanes)
	var n6 := _t("N6", "notas", "execucao com 2 dedos (alcance, hold/slide ocupando dedo)", "fail" if fi >= 0 else "pass", "", [fi] if fi >= 0 else [])
	if fi >= 0:
		n6["t_fail"] = float(notes[fi]["t"])
	out.append(n6)
	var dup: Array = []
	for i in range(1, notes.size()):
		if int(notes[i]["lane"]) == int(notes[i - 1]["lane"]) and absf(float(notes[i]["t"]) - float(notes[i - 1]["t"])) < 0.001:
			dup.append(i)
	out.append(_t("N7", "notas", "notas duplicadas/sobrepostas na mesma pista", "fail" if not dup.is_empty() else "pass", "", dup))
	out.append(_t("N8", "notas", "quantidade de pistas valida para a dificuldade", "pass" if lanes >= 3 and lanes <= 6 else "fail", "lanes=%d" % lanes))


# ------------------------------------------------------------------ progressao
static func _progression(m: Dictionary, out: Array, d: Dictionary, tl: RhythmMap) -> void:
	if ["geometry_run", "music_dash", "endless"].has(m.get("mode", "")):
		var fe: Array = tl.fe
		var cur := "cube"
		for e in fe:
			cur = String(e["form"])
		out.append(_t("P1", "progressao", "fase termina em forma normal (portais de saida presentes)", "pass" if cur == "cube" else "fail"))
		var exitless: Array = []
		for k in range(fe.size()):
			if fe[k]["form"] != "cube" and (k + 1 >= fe.size() or fe[k + 1]["form"] == fe[k]["form"]):
				exitless.append(snappedf(float(fe[k]["t"]), 0.01))
		out.append(_t("P2", "progressao", "toda forma especial tem saida (transicoes completas)", "fail" if not exitless.is_empty() else "pass", str(exitless)))
		if m.has("instances") and not (m["instances"] as Array).is_empty():
			var insts: Array = m["instances"]
			var over: Array = []
			for k in range(insts.size() - 1):
				if float(insts[k + 1]["t0"]) < float(insts[k]["t1"]) - 0.01:
					over.append(insts[k + 1]["k"])
			out.append(_t("P3", "progressao", "padroes consecutivos nao se sobrepoem", "fail" if not over.is_empty() else "pass", "", []))
			var toohigh: Array = []
			for i in insts:
				if i["kind"] == "static" and int(i["tier"]) > int(diff_at(m, d, float(i["t0"]))["tier"]):
					toohigh.append(i["k"])
			out.append(_t("D2", "dificuldade", "nenhum padrao acima do nivel da dificuldade (nao subir so por velocidade)", "fail" if not toohigh.is_empty() else "pass", "", []))
	out.append(_t("P4", "progressao", "possibilidade de concluir (ver teste de gameplay)", "pass", "validado pela simulacao G1/G2", [], "real"))


static func estimate_difficulty(m: Dictionary, d: Dictionary, tl: RhythmMap) -> float:
	var active: float = maxf(float(m["end_t"]) - float(d["lead_in_s"]), 1.0)
	if m.get("mode", "") == "magic_rhythm":
		var notes: Array = m.get("notes", [])
		if notes.is_empty():
			return 0.0
		var mean_nps: float = float(notes.size()) / active
		var mx := 1
		var j := 0
		for i in range(notes.size()):
			while float(notes[i]["t"]) - float(notes[j]["t"]) > 1.0:
				j += 1
			mx = maxi(mx, i - j + 1)
		var s: float = 0.5 * minf(mean_nps / 6.0, 1.0) + 0.3 * minf(float(mx) / 9.0, 1.0) + 0.2 * float(int(m["lanes"]) - 3) / 3.0
		return snappedf(10.0 * clampf(s, 0.0, 1.0), 0.01)
	var groups: Array = _hazard_groups(m, tl)
	var cube_groups: int = groups.filter(func(g): return g["form"] == "cube" or g["form"] == "robot").size()
	var forms: int = 0
	for e in tl.fe:
		if e["form"] != "cube" and e["form"] != "lanes":
			forms += 1
	var ev: float = (float(cube_groups) + 3.0 * float(forms) / 2.0 + float((m.get("notes", []) as Array).size()) / 3.0) / active
	var sp_sum := 0.0
	for e in m["speed_events"]:
		sp_sum += float(e["speed"])
	var mean_speed: float = sp_sum / float((m["speed_events"] as Array).size())
	var tiers := 0.0
	var tn := 0
	for i in m.get("instances", []):
		tiers += float(i["tier"])
		tn += 1
	var tier_mean: float = tiers / float(tn) if tn > 0 else 1.0
	var s2: float = 0.45 * minf(ev / 1.1, 1.0) + 0.30 * minf(maxf(mean_speed - 8.4, 0.0) / 7.2, 1.0) + 0.25 * (tier_mean - 1.0) / 4.0
	if m.get("mode", "") == "music_dash" and not (m.get("notes", []) as Array).is_empty():
		s2 += 0.05
	return snappedf(10.0 * clampf(s2, 0.0, 1.0), 0.01)


# ------------------------------------------------------------------ gameplay (simulacao)
static func _gameplay(m: Dictionary, out: Array, map: RhythmMap, beam: int, progress: Callable) -> Dictionary:
	if not ["geometry_run", "music_dash", "endless"].has(m.get("mode", "")):
		return {}
	var r: Dictionary = PhysicsModel.search(map, beam, progress)
	var info := "30Hz de entrada, frontier max=%d%s" % [int(r["max_frontier"]), " (beam truncado, caminho encontrado e real)" if r["truncated"] else ""]
	if r["ok"]:
		out.append(_t("G1", "gameplay", "simulacao fisica: existe trajetoria que conclui a fase", "pass", info, [], "real"))
	elif r["truncated"]:
		var t := _t("G1", "gameplay", "simulacao fisica: existe trajetoria que conclui a fase", "unverified",
				"busca truncada e sem caminho ate t=%.2fs: nao e possivel afirmar impossibilidade" % float(r["t_fail"]), [], "real")
		t["t_fail"] = r["t_fail"]
		out.append(t)
	else:
		var t2 := _t("G1", "gameplay", "simulacao fisica: existe trajetoria que conclui a fase", "fail",
				"nenhuma trajetoria passa de t=%.2fs (busca exaustiva)" % float(r["t_fail"]), [], "real")
		t2["t_fail"] = r["t_fail"]
		out.append(t2)
	return r


## Valida a fase. 'progress' (Callable float) e opcional. Retorna o relatorio completo.
static func validate(m: Dictionary, beam: int = 1200, progress: Callable = Callable(), skip_sim: bool = false) -> Dictionary:
	var d: Dictionary = diff_of(m)
	var tests: Array = []
	_structure(m, tests)
	for t in tests:
		if t["id"] == "S1" and t["status"] == "fail":
			return _final(tests, {}, d, 0.0)
	var map := RhythmMap.from_dict(m)
	_collision(m, tests, map)
	_timing(m, tests, d, map)
	_notes_tests(m, tests, d)
	_progression(m, tests, d, map)
	var est: float = estimate_difficulty(m, d, map)
	var band: Array = d["band"]
	tests.append(_t("D1", "dificuldade", "dificuldade estimada (heuristica) dentro da faixa da dificuldade escolhida",
			"pass" if est >= float(band[0]) and est <= float(band[1]) else "warn", "estimada=%.1f faixa=[%.1f, %.1f]" % [est, float(band[0]), float(band[1])], [], "heuristic"))
	var sim: Dictionary = {}
	if not skip_sim:
		sim = _gameplay(m, tests, map, beam, progress)
	return _final(tests, sim, d, est)


static func _final(tests: Array, sim: Dictionary, d: Dictionary, est: float) -> Dictionary:
	var fails: Array = tests.filter(func(t): return t["status"] == "fail")
	var unv: Array = tests.filter(func(t): return t["status"] == "unverified")
	var warns: Array = tests.filter(func(t): return t["status"] == "warn")
	var result: String
	var status: String
	if not fails.is_empty():
		result = "Reprovada"; status = "FAILED"
	elif not unv.is_empty():
		result = "Nao verificada"; status = "UNVERIFIED"
	elif not warns.is_empty():
		result = "Aprovada com avisos"; status = "READY"
	else:
		result = "Aprovada"; status = "READY"
	var struct_ok := true
	var functional := true
	for t in tests:
		if t["category"] == "estrutura" and t["status"] != "pass":
			struct_ok = false
		if (t["id"] == "G1" or t["id"] == "N6") and t["status"] != "pass":
			functional = false
	var passed: int = tests.filter(func(t): return t["status"] == "pass").size()
	return {"status": status, "result": result, "tests": tests, "sim": sim,
			"levels": {"tecnicamente_valida": struct_ok, "funcional": functional, "testada": unv.is_empty(), "aprovada_para_entrega": status == "READY"},
			"counts": {"total": tests.size(), "pass": passed, "warn": warns.size(), "fail": fails.size(), "unverified": unv.size()},
			"difficulty_estimate": est}
