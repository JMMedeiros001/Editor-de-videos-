extends SceneTree
## Runner de testes DENTRO do Godot (NAO foi executado neste ambiente: nao havia Godot).
## Uso:  godot --headless --path . -s tests/test_runner.gd
## Verifica: carga dos dados, determinismo do RNG/fisica, validacao das fases oficiais (mesmo validador do jogo),
## geracao com seed reprodutivel e invariantes. Imprime PASS/FAIL e sai com codigo != 0 se algo falhar.

var fails := 0
var total := 0


func check(name: String, ok: bool, detail: String = "") -> void:
	total += 1
	if not ok:
		fails += 1
	print(("PASS " if ok else "FAIL ") + name + ((" | " + detail) if (detail != "" and not ok) else ""))


func _initialize() -> void:
	var t0 := Time.get_ticks_msec()
	# --- dados
	check("physics.json carregado", RD.physics().has("forms"))
	check("difficulty.json tem 5 niveis", (RD.difficulty_table()["levels"] as Dictionary).size() == 5)
	check("patterns.json tem padroes", RD.patterns().size() >= 16)
	# --- RNG deterministico (mesma sequencia que tools/rdtools/rng.py: seed 7 -> primeiros valores)
	var a := Rng.new(7)
	var b := Rng.new(7)
	check("Rng determinista", a.next() == b.next() and a.next() == b.next())
	# --- fisica
	var m0 := RhythmMap.from_dict({"speed_events": [{"t": 0, "speed": 10.4}], "form_events": [], "objects": [{"type": "spike", "x": 30, "y": 0}], "end_t": 12.0})
	check("fisica: 1 espinho concluivel", PhysicsModel.search(m0)["ok"])
	var wall := RhythmMap.from_dict({"speed_events": [{"t": 0, "speed": 10.4}], "form_events": [], "objects": [{"type": "block", "x": 30, "y": 0, "w": 1, "h": 3}], "end_t": 12.0})
	var rw := PhysicsModel.search(wall)
	check("fisica: parede de 3 e impossivel", (not rw["ok"]) and (not rw["truncated"]))
	# --- fases oficiais: revalidar com o validador do jogo
	for e in GameManager.official_levels():
		var m := GameManager.load_official(e)
		var r := LevelValidator.validate(m)
		check("oficial %s READY (validador GDScript)" % e["name"], r["status"] == "READY", str(r["result"]))
	# --- geracao reprodutivel (mesma seed => mesmo mapa) com analise sintetica
	var an := LevelGenerator.synthetic_analysis(120.0, 40, true)
	var g1 := LevelGenerator.generate(an, "geometry_run", "normal", "balanced", 5)
	var g2 := LevelGenerator.generate(an, "geometry_run", "normal", "balanced", 5)
	check("geracao reprodutivel", JSON.stringify(g1["objects"]) == JSON.stringify(g2["objects"]))
	var rg := LevelValidator.validate(g1)
	check("fase gerada valida (nenhum READY com falha)", not (rg["status"] == "READY" and int(rg["counts"]["fail"]) > 0))
	var gn := LevelGenerator.generate(an, "magic_rhythm", "normal", "balanced", 3, {}, 4)
	check("notas geradas validas", LevelValidator.validate(gn)["status"] != "FAILED")
	print("\nTOTAL %d  FALHAS %d  (%d ms)" % [total, fails, Time.get_ticks_msec() - t0])
	quit(1 if fails > 0 else 0)
