#!/bin/bash
# Instala tudo e inicia o Editor IA
set -e
sudo apt-get update -y
sudo apt-get install -y ffmpeg
cd server
npm install
npm start
