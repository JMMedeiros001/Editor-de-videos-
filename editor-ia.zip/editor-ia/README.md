# Editor IA — Etapa 1

Upload → remoção de silêncio (timeline editável) → desfazer → exportar MP4.

## Rodar
Requer Node 20.11+ e FFmpeg instalado (`ffmpeg` e `ffprobe` no PATH).

```
cd server
npm install
npm start
```
Abra http://localhost:3000

## Estrutura
- `server/` API + FFmpeg. A timeline fica em `server/data/<id>.json`.
- `app/` interface mobile (HTML simples, servida pelo servidor).

## Status
- Implementado: upload, preview leve (480p), detecção de silêncio, operações CUT ativáveis/desativáveis, desfazer, exportação, transcrição local (Whisper), legendas .srt ajustadas aos cortes.
- Requer para transcrever: `pip install openai-whisper` (comando `whisper` no PATH).
- Ainda não testado com vídeos reais: só a sintaxe do servidor foi verificada.
- Não implementado: legendas queimadas no vídeo, chat/agente, estilos, referência.

## Deploy
Suba o repositório no GitHub e conecte o `server/` a Render, Railway ou Fly.io.
O serviço precisa ter FFmpeg instalado (use um Dockerfile com `apt-get install ffmpeg`).
