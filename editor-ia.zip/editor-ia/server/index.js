import express from "express";
import multer from "multer";
import { execFile } from "node:child_process";
import fs from "node:fs";
import path from "node:path";
import { randomUUID } from "node:crypto";

const ROOT = import.meta.dirname;
const DATA = path.join(ROOT, "data");
fs.mkdirSync(path.join(DATA, "uploads"), { recursive: true });

const app = express();
app.use(express.json());
app.use(express.static(path.join(ROOT, "../app")));
const upload = multer({ dest: path.join(DATA, "uploads") });

const tlFile = (id) => path.join(DATA, `${id}.json`);
const load = (id) => JSON.parse(fs.readFileSync(tlFile(id), "utf8"));
const save = (t) => fs.writeFileSync(tlFile(t.id), JSON.stringify(t, null, 1));
const run = (cmd, args) =>
  new Promise((ok, fail) =>
    execFile(cmd, args, { maxBuffer: 1e8 }, (e, so, se) =>
      e ? fail(new Error(se || e.message)) : ok({ so, se })
    )
  );

// Timeline é a fonte da verdade. Cada operação é reversível (enabled + histórico).
const snapshot = (t) => {
  t.history.push(JSON.stringify(t.ops));
  if (t.history.length > 50) t.history.shift();
};

app.post("/api/projects", upload.single("video"), async (req, res) => {
  try {
    const { so } = await run("ffprobe", [
      "-v", "error", "-show_entries", "format=duration",
      "-of", "default=nw=1:nk=1", req.file.path,
    ]);
    const t = {
      id: randomUUID(), source: req.file.path,
      duration: parseFloat(so), ops: [], history: [],
    };
    save(t);
    res.json(t);
  } catch (e) { res.status(500).json({ error: e.message }); }
});

app.get("/api/projects/:id", (req, res) => res.json(load(req.params.id)));

// CUT automático de silêncios (ffmpeg silencedetect)
app.post("/api/projects/:id/silences", async (req, res) => {
  try {
    const t = load(req.params.id);
    const db = req.body.noiseDb ?? -35;
    const min = req.body.minSilence ?? 0.5;
    const { se } = await run("ffmpeg", [
      "-i", t.source, "-af", `silencedetect=noise=${db}dB:d=${min}`,
      "-f", "null", "-",
    ]);
    const starts = [...se.matchAll(/silence_start: ([\d.]+)/g)].map((m) => +m[1]);
    const ends = [...se.matchAll(/silence_end: ([\d.]+)/g)].map((m) => +m[1]);
    snapshot(t);
    t.ops = t.ops.filter((o) => o.origin !== "silence");
    const PAD = 0.1; // mantém respiro nas bordas
    starts.forEach((s, i) => {
      const e = ends[i] ?? t.duration;
      if (e - s > 2 * PAD + 0.1)
        t.ops.push({
          id: randomUUID(), type: "CUT", origin: "silence",
          start: +(s + PAD).toFixed(2), end: +(e - PAD).toFixed(2), enabled: true,
        });
    });
    save(t);
    res.json(t);
  } catch (e) { res.status(500).json({ error: e.message }); }
});

app.post("/api/projects/:id/ops/:opId/toggle", (req, res) => {
  const t = load(req.params.id);
  const op = t.ops.find((o) => o.id === req.params.opId);
  if (!op) return res.status(404).json({ error: "Operação não encontrada" });
  snapshot(t);
  op.enabled = !op.enabled;
  save(t);
  res.json(t);
});

app.post("/api/projects/:id/undo", (req, res) => {
  const t = load(req.params.id);
  if (!t.history.length) return res.status(400).json({ error: "Nada para desfazer" });
  t.ops = JSON.parse(t.history.pop());
  save(t);
  res.json(t);
});

// Render: o MP4 é só o resultado da timeline
app.post("/api/projects/:id/export", async (req, res) => {
  try {
    const t = load(req.params.id);
    const cuts = t.ops.filter((o) => o.enabled && o.type === "CUT")
      .sort((a, b) => a.start - b.start);
    const keep = [];
    let cur = 0;
    for (const c of cuts) {
      if (c.start > cur) keep.push([cur, c.start]);
      cur = Math.max(cur, c.end);
    }
    if (cur < t.duration) keep.push([cur, t.duration]);
    if (!keep.length) return res.status(400).json({ error: "Nada sobrou para exportar" });

    const parts = keep.map(([a, b], i) =>
      `[0:v]trim=start=${a}:end=${b},setpts=PTS-STARTPTS[v${i}];` +
      `[0:a]atrim=start=${a}:end=${b},asetpts=PTS-STARTPTS[a${i}]`
    );
    const ins = keep.map((_, i) => `[v${i}][a${i}]`).join("");
    const filter = `${parts.join(";")};${ins}concat=n=${keep.length}:v=1:a=1[v][a]`;
    const out = path.join(DATA, `${t.id}.mp4`);
    await run("ffmpeg", [
      "-y", "-i", t.source, "-filter_complex", filter,
      "-map", "[v]", "-map", "[a]", "-c:v", "libx264", "-preset", "veryfast",
      "-c:a", "aac", out,
    ]);
    res.json({ ok: true, download: `/api/projects/${t.id}/download` });
  } catch (e) { res.status(500).json({ error: e.message }); }
});

app.get("/api/projects/:id/download", (req, res) =>
  res.download(path.join(DATA, `${req.params.id}.mp4`)));

// Trechos mantidos = duração total menos CUTs ativos
function keepSegments(t) {
  const cuts = t.ops.filter((o) => o.enabled && o.type === "CUT")
    .sort((a, b) => a.start - b.start);
  const keep = [];
  let cur = 0;
  for (const c of cuts) {
    if (c.start > cur) keep.push([cur, c.start]);
    cur = Math.max(cur, c.end);
  }
  if (cur < t.duration) keep.push([cur, t.duration]);
  return keep;
}

// Preview leve (480p) para o celular; o export usa sempre o original
app.post("/api/projects/:id/proxy", async (req, res) => {
  try {
    const t = load(req.params.id);
    await run("ffmpeg", [
      "-y", "-i", t.source, "-vf", "scale=-2:480", "-c:v", "libx264",
      "-preset", "veryfast", "-crf", "28", "-c:a", "aac",
      path.join(DATA, `${t.id}.proxy.mp4`),
    ]);
    res.json({ ok: true, url: `/api/projects/${t.id}/proxy` });
  } catch (e) { res.status(500).json({ error: e.message }); }
});
app.get("/api/projects/:id/proxy", (req, res) =>
  res.sendFile(path.join(DATA, `${req.params.id}.proxy.mp4`)));

// Transcrição local: exige o Whisper instalado (pip install openai-whisper)
app.post("/api/projects/:id/transcribe", async (req, res) => {
  try {
    const t = load(req.params.id);
    await run("whisper", [
      t.source, "--model", req.body.model || "small", "--language", "pt",
      "--output_format", "json", "--output_dir", DATA,
    ]);
    const j = JSON.parse(
      fs.readFileSync(path.join(DATA, `${path.parse(t.source).name}.json`), "utf8")
    );
    t.transcript = j.segments.map((s) => ({
      start: +s.start.toFixed(2), end: +s.end.toFixed(2), text: s.text.trim(),
    }));
    save(t);
    res.json(t);
  } catch (e) {
    res.status(500).json({ error: "Falha na transcrição (Whisper instalado?): " + e.message });
  }
});

// SRT com tempos ajustados aos cortes ativos
app.get("/api/projects/:id/srt", (req, res) => {
  const t = load(req.params.id);
  if (!t.transcript) return res.status(400).json({ error: "Transcreva primeiro" });
  const ts = (x) => {
    const ms = Math.round(x * 1000);
    const p = (n, l = 2) => String(n).padStart(l, "0");
    return `${p(Math.floor(ms / 3600000))}:${p(Math.floor(ms / 60000) % 60)}:${p(Math.floor(ms / 1000) % 60)},${p(ms % 1000, 3)}`;
  };
  const keep = keepSegments(t);
  const lines = [];
  let offset = 0;
  for (const [a, b] of keep) {
    for (const s of t.transcript) {
      const lo = Math.max(s.start, a), hi = Math.min(s.end, b);
      if (hi - lo > 0.2)
        lines.push(`${lines.length + 1}\n${ts(offset + lo - a)} --> ${ts(offset + hi - a)}\n${s.text}\n`);
    }
    offset += b - a;
  }
  res.type("text/plain").set("Content-Disposition", "attachment; filename=legendas.srt")
    .send(lines.join("\n"));
});
app.post("/api/chat", (_, res) =>
  res.status(501).json({ error: "Não implementado: chat/agente" }));

app.listen(process.env.PORT || 3000, () => console.log("Editor IA rodando"));
